To Run
======
1: open command prompt in jar location
2: in below command replace "E:\cooperators_project\cooperators\conf\QA" with your application.properties location
	java -Debix.configuration.folder="E:\cooperators_project\cooperators\conf\QA" -cp cooperators.jar com.couchBase.test.MoveCaseDatatoOracle	
3.For creating a jar we need to run "mvn package"
4.For running the jar in Linux 
  "root@localhost:/opt/tppdata/Co-operators/conf# /usr/jdk1.7.0_79/bin/java  -Debix.configuration.folder="/opt/tppdata/Co-operators/conf/" -cp utility.jar com.couchBase.test.CoopUtilities"


  
Command to Rename uploaded folders of one week before 100 days
===============================================================
1: open command prompt in jar location
2: in below command replace "E:\cooperators_project\cooperators\conf\QA" with your application.properties location
	java -Debix.configuration.folder="E:\cooperators_project\cooperators\conf\QA" -cp cooperators.jar com.couchBase.test.CoopUtilities renameFolders
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.json.simple.JSONObject;

import edu.emory.mathcs.backport.java.util.Arrays;

public class AuditLogsTest {
	public static String START_DATE = "2019-01-01";
	//public static String END_DATE = "2018-08-10";
	public static String END_DATE = toDay(); 
	
	public static String FILE_PATH = "C:\\Users\\vinaykumare\\Desktop\\auditlog\\audit.log";
	//public static String FILE_PATH = "C:\\Users\\SANTHOSHG\\Desktop\\prod_audit\\2\\auditlog.txt";
	
	//public static String BRANCH = "COOP_QA_";
	//public static String BRANCH = "COOP_PREPROD_";
	//public static String BRANCH = "COOP_PROD";
	//public static String BRANCH = "STAGE";
	public static String BRANCH = "COOP_PERFORMANCE_";
	public static String REPORT_DIR = "C:\\AUDITFULL\\" + BRANCH + "\\Performance Report_";
	public static void main(String[] args) throws ParseException {
		JSONObject eventsDocJSON = getJson();
		List<String> auditLogs = fileRead(FILE_PATH);
		System.out.println("Audit logs Size:" + auditLogs.size());
		//calculateProceedTime(auditLogs);
		
		generateDailyPerfReportCSV(auditLogs, eventsDocJSON);
		
		//filterListByEvents();
		
		//getPerformanceMetrics(auditLogs, eventsDocJSON);
	}
	
	public static void generateDailyPerfReportCSV(List<String> auditLogs, JSONObject eventsDocJSON) throws ParseException {
		List<String> dayAuditLogs;
		String nextDay = START_DATE;
		do {
			dayAuditLogs = filterList(auditLogs, nextDay);
			if (!dayAuditLogs.isEmpty()) {
				//Advisor report
				StringBuilder advisorCSV = getAdvisorPerformaneReport(filterAuditLogs(dayAuditLogs, eventsDocJSON));
				if (advisorCSV.length() > 0) {
					writeFile(advisorCSV, (REPORT_DIR + nextDay));
					System.out.println("GENERATED REPORT DATE : " + nextDay);
				}
			}
			nextDay = getNextDate(nextDay);
			if (START_DATE.equals(END_DATE) || END_DATE.equals(nextDay)){
				break;
			}
		} while (true);
	}
	
	public static List<String> fileRead(String ipFilePath) {
		Set<String> set = null;
		BufferedReader bufferedReader = null;
		try {
			FileReader reader = new FileReader(ipFilePath);
			bufferedReader = new BufferedReader(reader);
	 
			String line;
			set =  new HashSet<String>();
			while ((line = bufferedReader.readLine()) != null) {
				line = line.replace("10350", "1035").replace("1035|", "10350|");
				System.out.println(line);
				set.add(line);
	        }
	        reader.close();
		} catch (IOException e) {
			e.printStackTrace();
	    } finally {
	    	try {
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	    return new ArrayList<String>(set);
	 }
	 
	 public static List<String> filterList(List<String> list, String filterStr) {
		 List<String> res = new ArrayList<String>();
		 for(String line:list) {
			 if(line.startsWith(filterStr)) {
				 res.add(line);
			 }
		 }
		 return res;
	 }

	 public static void writeFile(StringBuilder stringList, String outFilePath) {
		 try {
			 FileWriter writer = new FileWriter(outFilePath + ".csv");
			 writer.write(stringList.toString());
			 writer.close();
		 } catch (IOException e) {
			 e.printStackTrace();
		 }
	 }
	 	
	 public static Map<String, List<String>> filterAuditLogs(List<String> auditLogs, JSONObject eventsDocJSON) {
		 Map<String, List<String>> advisorAuditLogs = new HashMap<String, List<String>>();
		 String[] lineArr;
		 List<String> tempList;
		 StringBuilder lineSB;
		 for (String line : auditLogs) {
			 lineSB = new StringBuilder();
			 lineArr = line.split("\\|");
			 if (lineArr.length != 11) {
				 continue;
			 }
			 try {
				 tempList = advisorAuditLogs.get(lineArr[9]);
				 lineSB.append(lineArr[9])
				 .append(",")
				 .append(lineArr[2])
				 .append(",")
				 .append(lineArr[0].split(" ")[0])
				 .append(",")
				 .append(lineArr[0].split(" ")[1])
				 .append(",")
				 .append(lineArr[10])
				 .append(",")
				 .append(lineArr[5])
				 .append(",")
				 .append(eventsDocJSON.get(lineArr[5]))
				 .append(",")
				 .append(lineArr[8]);
				 /*.append(",")
				 .append(lineArr[1])
				 .append(",")
				 .append(lineArr[3]);*/
				 line = lineSB.toString();
				 if (tempList == null) {
					List<String> newList = new ArrayList<String>();
					newList.add(line);
					advisorAuditLogs.put(lineArr[9], newList);
				} else {
					tempList.add(line);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return advisorAuditLogs;
	}
	 	
 	public static StringBuilder getAdvisorPerformaneReport(Map<String, List<String>> advisorAuditLogs) {
		StringBuilder advisorReportCSV = new StringBuilder();
		for (List<String> logEntryList : advisorAuditLogs.values()) {
			for (String logEntry : logEntryList) {
				advisorReportCSV.append(logEntry);
				advisorReportCSV.append("\n");
			}
		}
		return advisorReportCSV;
	}
	 
 	public static void removeDuplicates(List<String> auditLogs, String outFilePath) {
		StringBuilder advisorReportCSV = new StringBuilder();
		for (String logEntry : auditLogs) {
				advisorReportCSV.append(logEntry);
				advisorReportCSV.append("\n");
			}
		writeFile(advisorReportCSV, outFilePath);
	}
 	
 	
 	public static JSONObject getJson(){
		JSONObject eventsDocJSON = new JSONObject();
		eventsDocJSON.put("10100",  "Eapp Launching Time");
		eventsDocJSON.put("10101",  "Eapp(LWTK) Launching Time");
		eventsDocJSON.put("10102",  "App Setup screen proceed button action time");
		eventsDocJSON.put("10103",  "App Setup databinding time");
		eventsDocJSON.put("10104",  "Edit Partial App Launch time");
		eventsDocJSON.put("10105",  "Locked App for eSign Launch time");
		eventsDocJSON.put("10110",  "Inbox loading time");
		eventsDocJSON.put("10200",  "Plan Selection");
		eventsDocJSON.put("10201",  "Plan Selection Initialization Time");
		eventsDocJSON.put("10202",  "On Base Product Selection");
		eventsDocJSON.put("10203",  "On Base plan Selection");
		eventsDocJSON.put("10210",  "On Base Product Selection (Versatile Term)");
		eventsDocJSON.put("10211",  "On Base Product Selection (Universal Life)");
		eventsDocJSON.put("10300",  "Client");
		eventsDocJSON.put("10301",  "Client Details Section Initialization Time (on Scroll)");
		eventsDocJSON.put("10302",  "Personal Profile Section Initialization Time (on Scroll)");
		eventsDocJSON.put("10303",  "Employment Insurance History Section Initialization Time (on Scroll)");
		eventsDocJSON.put("10304",  "Mortgage LOC Information Section Initialization Time (on Scroll)");
		eventsDocJSON.put("10305",  "CLIENT 2 Client Details Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10306",  "CLIENT 2 Personal Profile Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10307",  "CLIENT 2 Employment Insurance History Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10308",  "CLIENT 2 Mortgage LOC Information Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10309",  "CLIENT 3 Client Details Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10310",  "CLIENT 3 Personal Profile Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10311",  "CLIENT 3 Employment Insurance History Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10312",  "CLIENT 3 Mortgage LOC Information Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10313",  "CLIENT 4 Client Details Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10314",  "CLIENT 4 Personal Profile Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10315",  "CLIENT 4 Employment Insurance History Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10316",  "CLIENT 4 Mortgage LOC Information Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10317",  "CLIENT 5 Client Details Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10318",  "CLIENT 5 Personal Profile Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10319",  "CLIENT 5 Employment Insurance History Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10320",  "CLIENT 5 Mortgage LOC Information Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10321",  "Group1 load first Time");
		eventsDocJSON.put("10322",  "Group2 load first Time");
		eventsDocJSON.put("10323",  "Group3 load first Time");
		eventsDocJSON.put("10324",  "Group4 load first Time");
		eventsDocJSON.put("10325",  "groups loaded at first time");
		eventsDocJSON.put("10326",  "Group1 Databinding Time");
		eventsDocJSON.put("10327",  "Group2 Databinding Time");
		eventsDocJSON.put("10328",  "Group3 Databinding Time");
		eventsDocJSON.put("10329",  "Group4 Databinding Time");
		eventsDocJSON.put("10331",  "Group1 load second Time");
		eventsDocJSON.put("10332",  "Group2 load second Time");
		eventsDocJSON.put("10333",  "Group3 load second Time");
		eventsDocJSON.put("10334",  "Group4 load second Time");
		eventsDocJSON.put("10335",  " Proceed button action time");
		eventsDocJSON.put("10336",  "Group1 MDC rules execution Time");
		eventsDocJSON.put("10337",  "Group2 MDC rules execution Time");
		eventsDocJSON.put("10338",  "Group3 MDC rules execution  Time");
		eventsDocJSON.put("10339",  "Group4 MDC rules execution Time");
		eventsDocJSON.put("10350",  "Match ECM client");
		eventsDocJSON.put("10351",  "Loading time of Clients on Number of Lives : 1");
		eventsDocJSON.put("10352",  "Loading time of Clients on Number of Lives : 2");
		eventsDocJSON.put("10353",  "Loading time of Clients on Number of Lives : 3");
		eventsDocJSON.put("10354",  "Loading time of Clients on Number of Lives : 4");
		eventsDocJSON.put("10355",  "Loading time of Clients on Number of Lives : 5");
		eventsDocJSON.put("10356",  "Loading time for group1 html");
		eventsDocJSON.put("10357",  "Loading time for group2 html");
		eventsDocJSON.put("10358",  "Loading time for group3 html");
		eventsDocJSON.put("10359",  "Loading time for group4 html");
		eventsDocJSON.put("10400",  "Owner");
		eventsDocJSON.put("10401",  "Owner Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10402",  "On Owner Type Change to Existing Client");
		eventsDocJSON.put("10403",  "On Owner Type Change to Joint ownership");
		eventsDocJSON.put("10404",  "On Owner Type Change to Other person");
		eventsDocJSON.put("10405",  "On Owner Type Change to Company");
		eventsDocJSON.put("10500",  "Policy");
		eventsDocJSON.put("10501",  "Policy Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10600",  "TIA/Initial Premium");
		eventsDocJSON.put("10601",  "TIA/Initial Premium Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10700",  "Beneficiaries");
		eventsDocJSON.put("10701",  "Beneficiaries Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10800",  "AAR Requirements");
		eventsDocJSON.put("10801",  "AAR Requirements Section Initialization Time(on Scroll)");
		eventsDocJSON.put("10900",  "Financial Advisor Disclosure Statement");
		eventsDocJSON.put("10901",  "Financial Advisor Disclosure Statement Section Initialization Time(on Scroll)");
		eventsDocJSON.put("11000",  "Forms and Signatures");
		eventsDocJSON.put("11001",  "Forms and Signatures Section Initialization Time(on Scroll)");
		eventsDocJSON.put("11002",  "Signature pre process lock/validations/save EAPP");
		eventsDocJSON.put("11003",  "WetSignature After validation of eapp");
		eventsDocJSON.put("11004",  "e-signature After validation of eapp");
		eventsDocJSON.put("11005",  "Continue e-signature/ esign ceromony start");
		eventsDocJSON.put("11006",  "Submit e-signature");
		eventsDocJSON.put("11007",  "e-signature process(Sessions url preparation)");
		eventsDocJSON.put("11008",  "Launching e-signature window");
		eventsDocJSON.put("11009",  "Launching e-signature switching window");
		eventsDocJSON.put("11010",  "Eapp policy number generation time");
		eventsDocJSON.put("11011",  "Generating pdfs");
		eventsDocJSON.put("11012",  "Silanis invocation/sessions creation time");
		eventsDocJSON.put("11100",  "Financial Advisor Report");
		eventsDocJSON.put("11101",  "Financial Advisor Report Section Initialization Time(on Scroll)");
		eventsDocJSON.put("11200",  "ChildRider");
		eventsDocJSON.put("11201",  "ChildRider Section Initialization Time (on Scroll)");
		eventsDocJSON.put("11301",  "eapp.min.js load time");
		eventsDocJSON.put("11303",  "eapp.assembly.js load time");
		eventsDocJSON.put("20001",  "Mortgage/Line Of Credit Information Window Open time");
		eventsDocJSON.put("20002",  "Calling Information Client Pop-up Open time");
		eventsDocJSON.put("20003",  "Bankruptcy Pop-up Open time");
		eventsDocJSON.put("20004",  "Cooperators Insurance InForce Pop-up Open time");
		eventsDocJSON.put("20005",  "Insurance In Force with Other Companies Pop-up Open time");
		eventsDocJSON.put("20006",  "Insurance Pending Pop-up Open time");
		eventsDocJSON.put("20007",  "Policy Change or Replacement Details Pop-up Open time");
		eventsDocJSON.put("20008",  "Insured Declined/Postponed Pop-up Open time");
		eventsDocJSON.put("20009",  "Add Other Person Pop-up Open time");
		eventsDocJSON.put("20010",  "Add Beneficial Ownership Pop-up Open time");
		eventsDocJSON.put("20011",  "Add Signing Officer Pop-up Open time");
		eventsDocJSON.put("20012",  "Add Other Partners or Shareholders policy BFQ Pop-up Open time");
		eventsDocJSON.put("20013",  "Add Partner or Shareholder Requesting Coverage Now Pop-up Open time");
		eventsDocJSON.put("20014",  "Key Person Details Pop-up Open time");
		eventsDocJSON.put("20015",  "Add Primary Beneficiaries Pop-up Open time");
		eventsDocJSON.put("20016",  "Add Trustee for Primary Beneficiary Pop-up Open time");
		eventsDocJSON.put("20017",  "Add Contingent Beneficiaries Pop-up Open time");
		eventsDocJSON.put("20018",  "Owner as Company Bankruptcy Pop-up Open time");
		eventsDocJSON.put("20019",  "Child Rider Pop-up Open time");
		eventsDocJSON.put("20020",  "Add Other Partners or Shareholders policy BFQ 2 Pop-up Open time");
		eventsDocJSON.put("20021",  "Add Trustee for Contingent Beneficiary Pop-up Open time");
		eventsDocJSON.put("20022",  "JointOwnership Add Other Person Bankruptcy0 Pop-up Open time");
		eventsDocJSON.put("20023",  "Owner as SoleProprieter Bankruptcypopup0 Pop-up Open time");
		eventsDocJSON.put("20024",  "Other Owner Bankruptcy Information Pop-up Open time");
		eventsDocJSON.put("20051",  "Mortgage/Line Of Credit Information Window Edit time");
		eventsDocJSON.put("20052",  "Calling Information Client Pop-up Edit time");
		eventsDocJSON.put("20053",  "Bankruptcy Pop-up Edit time");
		eventsDocJSON.put("20054",  "Cooperators Insurance InForce Pop-up Edit time");
		eventsDocJSON.put("20055",  "Insurance In Force with Other Companies Pop-up Edit time");
		eventsDocJSON.put("20056",  "Insurance Pending Pop-up Edit time");
		eventsDocJSON.put("20057",  "Policy Change or Replacement Details Pop-up Edit time");
		eventsDocJSON.put("20058",  "Insured Declined/Postponed Pop-up Edit time");
		eventsDocJSON.put("20059",  "Add Other Person Pop-up Edit time");
		eventsDocJSON.put("20060",  "Add Beneficial Ownership Pop-up Edit time");
		eventsDocJSON.put("20061",  "Add Signing Officer Pop-up Edit time");
		eventsDocJSON.put("20062",  "Add Other Partners or Shareholders policy BFQ Pop-up Edit time");
		eventsDocJSON.put("20063",  "Add Partner or Shareholder Requesting Coverage Now Pop-up Edit time");
		eventsDocJSON.put("20064",  "Key Person Details Pop-up Edit time");
		eventsDocJSON.put("20065",  "Add Primary Beneficiaries Pop-up Edit time");
		eventsDocJSON.put("20066",  "Add Trustee for Primary Beneficiary Pop-up Edit time");
		eventsDocJSON.put("20067",  "Add Contingent Beneficiaries Pop-up Edit time");
		eventsDocJSON.put("20068",  "Owner as Company Bankruptcy Pop-up Edit time");
		eventsDocJSON.put("20069",  "Child Rider Pop-up Edit time");
		eventsDocJSON.put("20070",  "Add Other Partners or Shareholders policy BFQ 2 Pop-up Edit time");
		eventsDocJSON.put("20071",  "Add Trustee for Contingent Beneficiary Pop-up Edit time");
		eventsDocJSON.put("20072",  "JointOwnership Add Other Person Bankruptcy0 Pop-up Edit time");
		eventsDocJSON.put("20073",  "Owner as SoleProprieter Bankruptcypopup0 Pop-up Edit time");
		eventsDocJSON.put("20074",  "Other Owner Bankruptcy Information Pop-up Edit time");
		eventsDocJSON.put("30000",  "Eapp Launching Time");
		eventsDocJSON.put("30001",  "Eapp(LWTK) Launching Time");
		eventsDocJSON.put("30002",  "App Setup screen proceed button action time");
		eventsDocJSON.put("30003",  "App Setup databinding time");
		eventsDocJSON.put("30004",  "Edit Partial App Launch time");
		eventsDocJSON.put("30005",  "Locked App for eSign Launch time");
		eventsDocJSON.put("30006",  "Match ECM client");
		eventsDocJSON.put("30101",  "Group1 load first Time");
		eventsDocJSON.put("30103",  "Group1 Databinding Time");
		eventsDocJSON.put("30104",  "Group1 load second Time");
		eventsDocJSON.put("30105",  "Group1 MDC rules execution Time");
		eventsDocJSON.put("30106",  "Annuitant Initialization Time(on Scroll)");
		eventsDocJSON.put("30107",  "Plan Selection Initialization Time(on Scroll)");
		eventsDocJSON.put("30108",  "Spouse Initialization Time(on Scroll)");
		eventsDocJSON.put("30110",  "Owner Initialization Time(on Scroll)");
		eventsDocJSON.put("30111",  "On Owner Type Change to InTrust For");
		eventsDocJSON.put("30112",  "On Owner Type Change to Joint ownership");
		eventsDocJSON.put("30113",  "On Owner Type Change to Other person");
		eventsDocJSON.put("30114",  "On Owner Type Change to Company");
		eventsDocJSON.put("30201",  "Group2 load first Time");
		eventsDocJSON.put("30203",  "Group2 Databinding Time");
		eventsDocJSON.put("30204",  "Group2 load second Time");
		eventsDocJSON.put("30205",  "Group2 MDC rules execution Time");
		eventsDocJSON.put("30206",  "Investor Profile Questionnaire Initialization Time(on Scroll)");
		eventsDocJSON.put("30207",  "Questionnaire Initialization Time(on Scroll)");
		eventsDocJSON.put("30208",  "Investment Style Initialization Time(on Scroll)");
		eventsDocJSON.put("30209",  "Default Portfolio Options Initialization Time(on Scroll)");
		eventsDocJSON.put("30210",  "Contribution Initialization Time(on Scroll)");
		eventsDocJSON.put("30211",  "Pre Authorized Debit Details Initialization Time(on Scroll)");
		eventsDocJSON.put("30212",  "Investment Options Initialization Time(on Scroll)");
		eventsDocJSON.put("30213",  "Policy Initialization Time(on Scroll)");
		eventsDocJSON.put("30214",  "DisInvestment Options Initialization Time(on Scroll)");
		eventsDocJSON.put("30301",  "Group3 load first Time");
		eventsDocJSON.put("30303",  "Group3 Databinding Time");
		eventsDocJSON.put("30304",  "Group3 load second Time");
		eventsDocJSON.put("30305",  "Group3 MDC rules execution Time");
		eventsDocJSON.put("30306",  "Beneficiaries Initialization Time(on Scroll)");
		eventsDocJSON.put("30307",  "Financial Advisor Disclosure Statement Initialization Time(on Scroll)");
		eventsDocJSON.put("30401",  "Group4 load first Time");
		eventsDocJSON.put("30403",  "Group4 Databinding Time");
		eventsDocJSON.put("30404",  "Group4 load second Time");
		eventsDocJSON.put("30405",  "Group4 MDC rules execution Time");
		eventsDocJSON.put("30406",  "Forms and Signatures Initialization Time(on Scroll)");
		eventsDocJSON.put("30407",  "E-Signatures Initialization Time(on Scroll)");
		eventsDocJSON.put("30408",  "Financial Advisor Report Initialization Time(on Scroll)");
		eventsDocJSON.put("31001",  "Add Co-operators Policy Information Pop-up Open time");
		eventsDocJSON.put("31002",  "Edit Co-operators Policy Information Pop-up Open time");
		eventsDocJSON.put("31003",  "Add Transfers from External Accounts Pop-up Open time");
		eventsDocJSON.put("31004",  "Edit Transfers from External Accounts Pop-up Open time");
		eventsDocJSON.put("31005",  "Add Signing Officer Pop-up Open time");
		eventsDocJSON.put("31006",  "Edit Signing Officer Pop-up Open time");
		eventsDocJSON.put("31007",  "Add Beneficial Ownership Pop-up Open time");
		eventsDocJSON.put("31008",  "Edit Beneficial Ownership Pop-up Open time");
		eventsDocJSON.put("31009",  "Add OtherPerson Pop-up Open time");
		eventsDocJSON.put("31010",  "Edit OtherPerson Pop-up Open time");
		eventsDocJSON.put("31011",  "Add Primary Beneficiary Pop-up Open time");
		eventsDocJSON.put("31012",  "Edit Primary Beneficiary Pop-up Open time");
		eventsDocJSON.put("31013",  "Add Trustee for PrimaryBenificiary Pop-up Open time");
		eventsDocJSON.put("31014",  "Edit Trustee for PrimaryBenificiary Pop-up Open time");
		eventsDocJSON.put("31015",  "Add Contingent Benificiaries Pop-up Open time");
		eventsDocJSON.put("31016",  "Edit Contingent Benificiaries Pop-up Open time");
		eventsDocJSON.put("31017",  "Add Trustee for contingent Benficiaries Pop-up Open time");
		eventsDocJSON.put("31018",  "Edit Trustee for contingent Benficiaries Pop-up Open time");
		eventsDocJSON.put("32002",  "Signature pre process lock/validations/save EAPP");
		eventsDocJSON.put("32003",  "WetSignature After validation of eapp");
		eventsDocJSON.put("32004",  "e-signature After validation of eapp");
		eventsDocJSON.put("32005",  "Continue e-signature/ esign ceromony start");
		eventsDocJSON.put("32006",  "Submit e-signature");
		eventsDocJSON.put("32007",  "e-signature process(Sessions url preparation)");
		eventsDocJSON.put("32008",  "Launching e-signature window");
		eventsDocJSON.put("32009",  "Launching e-signature switching window");
		eventsDocJSON.put("32010",  "Eapp policy number generation time");
		eventsDocJSON.put("32011",  "Generating pdfs");
		eventsDocJSON.put("32012",  "Silanis invocation/sessions creation time");
		eventsDocJSON.put("90001",  "Base Product Change Count");
		eventsDocJSON.put("90002",  "Base Plan Change Count");
		eventsDocJSON.put("fr",  "French");
		eventsDocJSON.put("filePath",  "c://logs//audit.log");
		eventsDocJSON.put("WEC",  "Wealth Create");
		eventsDocJSON.put("version",  "1.2.3");
		eventsDocJSON.put("WEE",  "Wealth Edit");
		eventsDocJSON.put("LIE",  "Life Edit");
		eventsDocJSON.put("LIC",  "Life Create");
		eventsDocJSON.put("en",  "English");
		eventsDocJSON.put("type",  "eapp_metadata");
		eventsDocJSON.put("GIC",  "GIO Create");
		eventsDocJSON.put("GIE",  "GIO Edit");
		eventsDocJSON.put("owner",  "Ebix");
		eventsDocJSON.put("last_updated_date",  "26-10-2015");
		eventsDocJSON.put("GCE",  "GC Edit");
		eventsDocJSON.put("GCC",  "GC Create");
		return eventsDocJSON;
	}
	 	
	public static String getNextDate(String curDate) throws ParseException {
		final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		final Date date = format.parse(curDate);
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		return format.format(calendar.getTime());
	}
	
	public static void getPerformanceMetrics(List<String> auditLogList, JSONObject eventsDocJSON) {
		JSONObject performanceEventsJson = getJson();
		DecimalFormat df = new DecimalFormat("########.###");
		
		HashMap<String,ArrayList<Long>> auditField = new HashMap<String,ArrayList<Long>>();
		HashMap<String,Long> auditFieldSum = new HashMap<String,Long>();
		
		String delimiter ="_";
		String[] lineVariables=null;
	    
	    String auditFieldKey;
		ArrayList<Long> auditFieldValue;
		Long auditFieldSumValue;
		for ( String line : auditLogList) {
			lineVariables = line.split("\\|"); 
			auditFieldKey = lineVariables[2] + lineVariables[3] + lineVariables[4] + delimiter + lineVariables[5];
			auditFieldValue = auditField.get(auditFieldKey);
			if (auditFieldValue == null) {
				//entry is not available and creating new entry
				auditFieldValue = new ArrayList<Long>();
			    //adding to array list
				auditFieldValue.add(Long.valueOf(lineVariables[8]));
			    auditField.put(auditFieldKey, auditFieldValue);
		    	//adding to Sum
		    	auditFieldSum.put(auditFieldKey, Long.valueOf(lineVariables[8]));
			} else {
				auditFieldValue.add(Long.valueOf(lineVariables[8]));
		    	//adding to Sum
				auditFieldSumValue = auditFieldSum.get(auditFieldKey);
				if (auditFieldSumValue == null) {
					auditFieldSum.put(auditFieldKey ,Long.valueOf(lineVariables[8]));
				} else {
					auditFieldSum.put(auditFieldKey ,Long.valueOf(lineVariables[8]) + auditFieldSumValue);
				}
		    }
		}
		
		ArrayList<Long> auditFieldEntryValue;
		int percetailIndex = 0;
		String eventVarArr[] = null;
		JSONObject dataJsonObj = null;
		StringBuilder resultSB = new StringBuilder();
		resultSB.append("EAPP Type, Eidit/Create, Language, Event ID, Event Description, Min, Max, Average, 90percentile, Hits").append("\n");
		
	    for (Entry<String, ArrayList<Long>> auditFieldEntry : auditField.entrySet()) {
			auditFieldEntryValue = auditFieldEntry.getValue();
		    Collections.sort(auditFieldEntryValue);
		    //percentile calculations subracting -1 as index starts from 0 in the list 
		    percetailIndex = ((int)Math.round(0.90 * auditFieldEntryValue.size())-1);
		    eventVarArr = auditFieldEntry.getKey().split(delimiter);
		    resultSB.append(eventVarArr[0].substring(0, eventVarArr[0].length()-1)).append(",")
		    .append(eventVarArr[0].charAt(eventVarArr[0].length()-1)).append(",")
		    .append(eventVarArr[1]).append(",")
		    .append(eventVarArr[2]).append(",")
		    .append(performanceEventsJson.get(eventVarArr[2])).append(",")
		    .append(df.format(auditFieldEntryValue.get(0)/1000.00)).append(",")
		    .append(df.format(auditFieldEntryValue.get(auditFieldEntryValue.size()-1)/1000.00)).append(",") 
		    .append(df.format(auditFieldSum.get(auditFieldEntry.getKey()) / (auditFieldEntryValue.size()*1000.00))).append(",")
		    .append(df.format(auditFieldEntryValue.get(percetailIndex)/1000.00)).append(",")
		    .append(auditFieldEntryValue.size()).append("\n");
		}
	        
		writeFile(resultSB, REPORT_DIR + "FULL");
	}
	
	public static void calculateProceedTime(List<String> auditLogList) {
		String lineArr[];
		String line2Arr[];
		Map<String, Map<String, List<Integer>>> eappIdRep = new HashMap<String, Map<String, List<Integer>>>();
		
		Set<String> list10104 = new HashSet<String>();
		//List<String> resList = new ArrayList<String>();
		List<Integer> vals10101 = new ArrayList<Integer>();
		for (String line : auditLogList) {
			lineArr = line.split("\\|");
			if (!eappIdRep.containsKey(lineArr[1])) {
				eappIdRep.put(lineArr[1], new HashMap<String, List<Integer>>());
			}
			if (lineArr.length != 11) {
				continue;
			}
			if (lineArr[5].equalsIgnoreCase("10104")) {
				list10104.add(line);
			}
			if (lineArr[5].equalsIgnoreCase("10101")) {
				vals10101.add(Integer.parseInt(lineArr[8]));
				Map<String, List<Integer>> tempMap = eappIdRep.get(lineArr[1]);
				if (!tempMap.containsKey("10101")) {
					tempMap.put("10101", new ArrayList<Integer>());
				}
				tempMap.get("10101").add(Integer.parseInt(lineArr[8]));
			}
		}

		ArrayList<Integer> resValList = new ArrayList<Integer>();
		for (String line10104 : list10104) {
			lineArr = line10104.split("\\|");
			for (String linet : auditLogList) {
				if (linet.startsWith(lineArr[0])) {
					line2Arr = linet.split("\\|");
					if (line2Arr[5].equalsIgnoreCase("10326")){
						//resList.add(line10104);
						//resList.add(linet);
						resValList.add(Integer.parseInt(lineArr[8]) + Integer.parseInt(line2Arr[8]));
						Map<String, List<Integer>> temp1Map = eappIdRep.get(lineArr[1]);
						if (!temp1Map.containsKey("10104 + 10326")) {
							temp1Map.put("10104 + 10326", new ArrayList<Integer>());
						}
						temp1Map.get("10104 + 10326").add(Integer.parseInt(lineArr[8]) + Integer.parseInt(line2Arr[8]));
						break;
					}
				}
			}
		}
		
		/*for (String resLine : resList) {
			System.out.println(resLine);
		}*/
		
		/*for (Integer resVal : resValList) {
			System.out.println(resVal);
			sum += resVal;
		}*/
		System.out.println("******************************************************************");
		System.out.println("******************************************************************");
		System.out.println("(10104+10326)min:" + Collections.min(resValList));
		System.out.println("(10104+10326)max:" + Collections.max(resValList));
		System.out.println("(10104+10326)avg:" + avg(resValList));
		System.out.println("******************************************************************");
		System.out.println("******************************************************************");
		System.out.println("10101min:" + Collections.min(vals10101));
		System.out.println("10101max:" + Collections.max(vals10101));
		System.out.println("10101avg:" + avg(vals10101));
		System.out.println("******************************************************************");
		System.out.println("******************************************************************");
		System.out.println("##################################################");
		System.out.println("EAppID,EventID,MIN,MAX,AVERAGE");
		for(Entry<String, Map<String, List<Integer>>> entry : eappIdRep.entrySet()) {
			for(Entry<String, List<Integer>> inEntry : entry.getValue().entrySet()) {
				System.out.println(entry.getKey() + "," 
						+ inEntry.getKey() + "," 
						+ Collections.min(inEntry.getValue()) + "," 
						+ Collections.max(inEntry.getValue()) + "," 
						+ avg(inEntry.getValue()));
			}
		}
		System.out.println("##################################################");
	}
	public static Integer avg(List<Integer> values) {
		Integer sum = 0;
		for (Integer resVal : values) {
			sum += resVal;
		}
		return sum/values.size();
	}
	
	public static String toDay() {
		final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		return format.format(new Date());
	}
	
	public static List<String> filterListByEvents() {
		System.out.println("***************************************************************************");
		System.out.println("***************************************************************************");
		List<String> eventsLogList = fileRead(FILE_PATH);
		List<String> eventList1 = Arrays.asList(new String[]{"10100","10335"});
		List<String> resultList = new ArrayList<String>();
		for (String logLine : eventsLogList) {
			String[] strArr = logLine.split("\\|");
			if(eventList1.contains(strArr[5])) {
				resultList.add(logLine);
				System.out.println(logLine);
			}
		}
		System.out.println("***************************************************************************");
		System.out.println("***************************************************************************");
		return resultList;
	}
}
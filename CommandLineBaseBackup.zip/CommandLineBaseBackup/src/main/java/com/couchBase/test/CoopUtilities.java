package com.couchBase.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
//import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.eapp.dao.impl.AbstractDAOImpl;
import com.eapp.entity.EappCaseAudit;
import com.eapp.entity.EappReports;
import com.eapp.exception.DataAccessException;
import com.eapp.utility.CoopProperties;
import com.ebix.couchbase.core.contracts.IEbixConnectionManager;
import com.ebix.couchbase.core.contracts.IEbixCouchbaseClient;
import com.ebix.couchbase.core.contracts.IEbixDesignDocument;
import com.ebix.couchbase.core.contracts.IEbixPaginator;
import com.ebix.couchbase.core.contracts.IEbixQuery;
import com.ebix.couchbase.core.contracts.IEbixView;
import com.ebix.couchbase.core.contracts.IEbixViewDesign;
import com.ebix.couchbase.core.contracts.IEbixViewResponse;
import com.ebix.couchbase.core.contracts.IEbixViewRow;
import com.ebix.couchbase.legacy.EbixConnectionManager;
import com.fasterxml.jackson.databind.ObjectMapper; 
public class CoopUtilities {

	private static final String CONFFILE_PATH = "ebix.configuration.folder";

	String confPath = System.getProperty(CONFFILE_PATH);

	ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");

	private AbstractDAOImpl abstractDAO = (AbstractDAOImpl) context.getBean("abstractDAO");

	private Logger logger = Logger.getLogger(CoopUtilities.class);

	static IEbixCouchbaseClient client = null;

	private static final String PDF_DIRECTORY = CoopProperties.getProp("pdf.repository.dir");
	
	private static final String SILANIS_DIRECTORY = CoopProperties.getProp("DOWNLOAD-FILE-PATH");

	public static void main(String[] args) throws IOException, URISyntaxException, ParseException {

		IEbixConnectionManager.ref = EbixConnectionManager.init();
		client = EbixConnectionManager.init().instance().getClient();
		CoopUtilities moveDocs = new CoopUtilities();

		if(null != args && args.length > 0 && "renameFolders".equalsIgnoreCase(args[0])){
			moveDocs.renameUploadedFoldersStartingWeek();
		}else{
		int choice = 0;


		while (choice != 14) {
			System.out.println("\nSelect Options: ");
			//System.out.println("1: Moved documents Logs Status - One Time JOB");
			System.out.println("1: Resetting the vendor question option in AAR Section for Old Cases");
			System.out.println("2: Move all Case and Report documents to Oracle with Document- RemainingCases");
			System.out.println("3: Move all Uploaded Case and Report documents to Oracle & Delete From Couchbase");
			System.out.println("4: Rename uploaded case folder Names for archiving");
			System.out.println("5: Move Report documents to oracle By Date");
			System.out.println("6: Move all Old callbackData to Oracle -one time job");
			System.out.println("7: Creating the AdvisorInboxFetch Docs for all users at single time ");
			System.out.println("8: Delete unnecessary html documents from couch base :  ");
			System.out.println("9: Enhancements Data Changes For Inflight Cases :  ");
			System.out.println("10: Adding advisor code in OID+carrierCode+_AdvisorInbox document for Old Cases:  ");
			System.out.println("11: update Base Plan values for Inflight Cases");
			System.out.println("12: update MCI Riders for Inflight Cases");
			System.out.println("13: Get Pre-screen report");
			System.out.println("14: Quit");

			Scanner scan = new Scanner(System.in);
			try {
				choice = Integer.parseInt(scan.nextLine());
			} catch (Exception e) {
				choice = 0;
			}
			switch (choice) {
			case 1:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Moved documents Logs Status");
				System.out.println("\nPlease waite, Operation in progress...");
				moveDocs.findUnnecessaryDocsFromCouchBase();
				break;

			case 2:
				System.out.println("you selected : " + choice);
				System.out.println(
						"you selected :Move all Case and Report documents to Oracle with Document- RemainingCases");
				moveDocs.moveDataToOracle();
				break;

			case 3:
				System.out.println("you selected : " + choice);
				System.out.println("Move all Uploaded Case and Report documents to Oracle & Delete From Couchbase");
				System.out.println(
						"press 'Y/y' conform delete documents from CouchBase OR press any key to cancell Action:");
				scan = new Scanner(System.in);
				String conformDelete = scan.nextLine();
				if (!conformDelete.equalsIgnoreCase("y")) {
					break;
				}
				moveDocs.moveCasess(true, false, true, true);
				break;

			case 4:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Rename uploaded case folder Names for archiving");
				moveDocs.renameUploadedFolders();
				break;

			case 5:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Move Report documents to oracle By Date");
				moveDocs.moveReportsToOracleByDate();
				break;

			case 6:
				System.out.println("you selected : " + choice);
				System.out.println("you selected :Move all Old callbackData to Oracle -one time job");
				System.out.println("Enter Starting file index number:");
				scan = new Scanner(System.in);
				String docSelect = scan.nextLine();
				int index = 1;
				try {
					index = Integer.parseInt(docSelect);
				} catch (Exception e) {
					choice = 0;
				}
				moveDocs.moveLeftOutcassess(index);
				break;

			case 7:
			
				System.out.println("you selected : Creating the AdvisorInboxFetch Docs for all users at single time Job");
			
				moveDocs.advisorDocs();
				break;
				
			case 8:
				System.out.println("you selected : Delete unnecessary html documents from couch base : One Time Job");
				moveDocs.delatingUnnecessaryDocs();
				break;
				
			case 9:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Enhancements Data Changes For Inflight Cases");
				System.out.println("Enter Starting file index number:");
				scan = new Scanner(System.in);
				String docSelects = scan.nextLine();
				int indexs = 1;
				try {
					index = Integer.parseInt(docSelects);
				} catch (Exception e) {
					choice = 0;
				}
				moveDocs.enhancementsDataChangesForInflightCases(indexs);
				break;
			
			case 10:
				System.out.println("you selected : Adding advisor code in OID+carrierCode+_AdvisorInbox document for Old Cases : OneTime Job");
				moveDocs.addingAddvisorCodeForOldCases();
				break;
				
			case 11:
				System.out.println("you selected : update Base Plan values for Inflight Cases");
				moveDocs.updateBasePlanVlaues();
				break;
				
			case 12:
				System.out.println("you selected : update MCI Riders for Inflight Cases");
				moveDocs.updateMCIRidersVlaues();
				break;
				
			case 13:
				System.out.println("you selected : Get Pre-screen report");
				moveDocs.getPreScreenRport();
				break;
				
			case 14:
				System.out.println("press 'Y/y' confirm exit:");
				scan = new Scanner(System.in);
				String conform = scan.nextLine();
				if (!conform.equalsIgnoreCase("y")) {
					choice = 0;
				}
				break;
				
			default:
				System.out.println("you selected  wrong option: " + choice);
				System.out.println("Please select a proper Option");
				break;
			}

			System.out.println("******Task Completed******");
			}
		}
		client.shutdown();
		System.out.println("********END********");
		System.exit(0);
	}
	
	public boolean renameUploadedFoldersStartingWeek(){
		boolean res = false;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		//formatter.setLenient(false);
		Calendar calender = Calendar.getInstance();
		try {
			System.out.println("prasent Date: "+ calender.getTime());
			calender.add(Calendar.DATE, -100);
			System.out.println("starting Date: "+ calender.getTime());
			String startDate = formatter.format(calender.getTime());
			calender.add(Calendar.DATE, 7);
			System.out.println("ending Date: "+ calender.getTime());
			String endDate = formatter.format(calender.getTime());
			startDate = startDate.replaceAll("-0", "-").replaceAll("^0*", "");
			endDate = endDate.replaceAll("-0", "-").replaceAll("^0*", "");
			System.out.println("starting Date: "+ startDate);
			System.out.println("ending Date: "+ endDate);
			renameUploadedFilesCore(startDate, endDate);
		} catch (Exception e) {
			System.out.println("Exception while calculating dates");
		}
		return res;
	}

	/**
	 * Returns json object with date value String with format dd-mm-yyyy (NOTE:
	 * ignores leading 0's as view's will fail to run with leading zeros) values
	 * startDate, endDate
	 */
	public Map<String, String> readDates() {
		Scanner scan = new Scanner(System.in);
		Map<String, String> dateObj = new java.util.HashMap<String, String>();
		String readVal = "";
		boolean invalidDate = true;
		Date date = null;
		String[] dateVals = { "startDate", "endDate" };

		try {
			for (int i = 0; i < dateVals.length; i++) {
				invalidDate = true;
				date = null;
				while (invalidDate) {
					System.out.println("Please enter " + dateVals[i] + "(dd-mm-yyyy):");
					readVal = scan.nextLine();
					readVal = readVal.replaceAll("-0", "-").replaceAll("^0*", "");
					if (null != readVal && !readVal.isEmpty()) {
						date = validateDateFormat(readVal);
						if (null != date) {
							dateObj.put(dateVals[i], readVal);
							invalidDate = false;
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Exception in readDates");
			e.printStackTrace();
		}
		return dateObj;
	}

	public Date validateDateFormat(String dateToValdate) {

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		// To make strict date format validation
		formatter.setLenient(false);
		Date parsedDate = null;
		try {
			parsedDate = formatter.parse(dateToValdate);
			System.out.println("validated DATE TIME :" + dateToValdate);

		} catch (java.text.ParseException e) {
			System.out.println("you have entered wrong date");
		}
		return parsedDate;
	}

	public void renameUploadedFolders() {

		Map<String, String> dateMap = null;
		try {
			dateMap = readDates();
		} catch (Exception e) {
			System.out.println("Exception while reading dates... Please try again with proper dates");
			e.printStackTrace();
		}
		String[] startDate = null;
		String[] endtDate = null;
		// JSONArray reportsArray = null;
		JSONParser parser = new JSONParser();
		boolean isRenamed = false;

		System.out.println("Please wait while Fetching Reports...");

		if (null != dateMap && !dateMap.isEmpty()) {
			renameUploadedFilesCore(dateMap.get("startDate"),dateMap.get("endDate"));
			
			//****old code moved to renameUploadedFilesCore ***//
			/*startDate = dateMap.get("startDate").split("-");
			endtDate = dateMap.get("endDate").split("-");
			if (null != startDate && null != endtDate) {
				String[] carrierCode = { "CLIC", "CUMIS" };
				for (int i = 0; i < carrierCode.length; i++) {
					try {
						int maxcount = 100000;
						String returnStr = "";
						JSONObject retObj = null;
						returnStr = getEappDataObjectByDate(startDate[0], startDate[1], startDate[2], endtDate[0],
								endtDate[1], endtDate[2], "23", "59", "59", "", carrierCode[i], 1, maxcount);
						if (null != returnStr && !returnStr.isEmpty()) {
							retObj = (JSONObject) parser.parse(returnStr);
							JSONArray retArray = (JSONArray) retObj.get("data");
							System.out.println("found " + retObj.get("totalCount") + " Reports with " + carrierCode[i]);
							if (null != retArray && !retArray.isEmpty()) {
								// reportsArray.add(retArray);
								JSONObject responseObj = null;
								String eappId = "";
								String status = "";
								for (int j = 0; j < retArray.size(); j++) {
									responseObj = (JSONObject) retArray.get(j);
									eappId = (String) responseObj.get("eappId");
									status = (String) responseObj.get("status");
									if (null != status && status.equalsIgnoreCase("Uploaded")) {
										isRenamed = renameFiles(eappId, PDF_DIRECTORY);
										System.out.println("PDF_" + eappId + " : " + isRenamed);
										isRenamed = renameFiles(eappId, SILANIS_DIRECTORY);
										System.out.println("SILANIS_" + eappId + " : " + isRenamed);
									}
								}

							}
						}

						System.out.println("compleated Fetching Reports by carrierCode:" + carrierCode[i]);
					} catch (Exception e) {
						System.out.println("Exception while Fetching Reports by carrierCode:" + carrierCode[i]);
						e.printStackTrace();
					}
				}
				System.out.println("compleated Fetching Reports");
			}*/
		}
	}
	
	public boolean renameUploadedFilesCore(String startDateVal, String endDateVal){
		boolean resp = false;
		JSONParser parser = new JSONParser();
		boolean isRenamed = false;

		String[] startDate = startDateVal.split("-");
		String[] endtDate = endDateVal.split("-");
		if (null != startDate && null != endtDate) {
			String[] carrierCode = { "CLIC", "CUMIS" };
			for (int i = 0; i < carrierCode.length; i++) {
				try {
					int maxcount = 100000;
					String returnStr = "";
					JSONObject retObj = null;
					returnStr = getEappDataObjectByDate(startDate[0], startDate[1], startDate[2], endtDate[0],
							endtDate[1], endtDate[2], "23", "59", "59", "", carrierCode[i], 1, maxcount);
					if (null != returnStr && !returnStr.isEmpty()) {
						retObj = (JSONObject) parser.parse(returnStr);
						JSONArray retArray = (JSONArray) retObj.get("data");
						System.out.println("found " + retObj.get("totalCount") + " Reports with " + carrierCode[i]);
						if (null != retArray && !retArray.isEmpty()) {
							// reportsArray.add(retArray);
							JSONObject responseObj = null;
							String eappId = "";
							String status = "";
							for (int j = 0; j < retArray.size(); j++) {
								responseObj = (JSONObject) retArray.get(j);
								eappId = (String) responseObj.get("eappId");
								status = (String) responseObj.get("status");
								if (null != status && status.equalsIgnoreCase("Uploaded")) {
										isRenamed = renameFiles(eappId, PDF_DIRECTORY);
										System.out.println("PDF_" + eappId + " : " + isRenamed);
										isRenamed = renameFiles(eappId, SILANIS_DIRECTORY);
										System.out.println("SILANIS_" + eappId + " : " + isRenamed);
								}
							}
						}
					}

					System.out.println("compleated Fetching Reports by carrierCode:" + carrierCode[i]);
				} catch (Exception e) {
					System.out.println("Exception while Fetching Reports by carrierCode:" + carrierCode[i]);
					e.printStackTrace();
				}
				resp = true;
			}
			System.out.println("compleated Fetching Reports");
		}
	
		return resp;
	}

	public boolean renameFiles(String folderName, String uploadFolder) {
		boolean renamed = false;
		String renameFolder = null;

		try {

			renameFolder = uploadFolder + File.separator + folderName;
			logger.info("Renaming  Folder Path " + renameFolder);
			File dir = new File(renameFolder);
			if (null != dir) {
				File newDir = new File(dir.getParent() + File.separator + "uploaded_" + folderName);
				renamed = dir.renameTo(newDir);
			}

			if (renamed)
				logger.info("Renaming compelted Successfully for Folder " + renameFolder);
			else
				logger.info("Renaming Failed for Folder " + renameFolder);
		} catch (Exception e) {
			System.out.println("Exception renameFiles");
		}
		return renamed;
	}

	public String readFile(String folder, String name) {
		String fileData = null;
		try {
			System.out.println("Reading file:" + name + " in folder" + folder);
			FileInputStream fin = null;
			BufferedReader reader = null;
			fin = new FileInputStream("." + File.separator + folder + File.separator + name);

			if (fin != null) {
				reader = new BufferedReader(new InputStreamReader(fin));
			}
			StringBuilder sb = new StringBuilder();
			String line = "";
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			fileData = sb.toString();
			reader.close();
			System.out.println("Reading compleated.");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		return fileData;
	}

	public void moveDataToOracle() {

		JSONObject repDoc = null;
		String appType = "life";
		JSONObject remainigCases = getDocument("RemainingCases");
		// query.setLimit(100);
		int docsPerPage = 200;
		try {
			if (remainigCases != null && remainigCases.isEmpty()) {
				String listStr = safeGet(remainigCases, "data");
				if (!listStr.isEmpty()) {
					JSONArray changesList = null;
					try {
						changesList = (JSONArray) new JSONParser().parse(listStr);
					} catch (Exception e) {
						System.out.println("Exception while parcing data array in AgentsChangesDoc");
						e.printStackTrace();
					}

					if (null != changesList && !changesList.isEmpty()) {
						String docName = "";
						JSONObject caseData = null;
						for (int i = 0; i < changesList.size(); i++) {
							try {
								docName = (String) changesList.get(i);
								if (null != docName && !docName.isEmpty()) {
									caseData = getDocument(docName);
									if (null != caseData && !caseData.isEmpty()) {
										boolean isCasemoved = false;
										String eapp_Status = safeGet(caseData, "eappStatus");
										appType = safeGet(caseData, "appType");
										if (eapp_Status.equals("Deleted")) {
											// Moving Deleted Cases Case Data to
											// oracle
											repDoc = getFormattedReportFromCaseData(getDocument(docName), appType);
											repDoc = getTableFormattedReportFromReportData(repDoc);
											isCasemoved = moveCaseAudiToDB(docName, true);
										} else {
											isCasemoved = moveCaseAudiToDB(docName, false);
										}
										System.out.println(docName + " isMoved:" + isCasemoved);
										boolean ismoved = saveReports(docName, repDoc);
										if (ismoved) {
											client.delete(docName.replace("COOPTrans", "Reports"));
										}
									}
								}
								if (docsPerPage != 0) {
									docsPerPage = docsPerPage - 1;
								} else {
									try {
										Thread.sleep(2000);
										docsPerPage = 200;
									} catch (InterruptedException ex) {
										Thread.currentThread().interrupt();
									}
								}
							} catch (Exception e) {
								System.out.println("Exception while processing document of:" + docName);
								e.printStackTrace();
							}
						}
					}

				} else {
					System.out.println("Cannot Find data array AgentsChangesDoc");
				}
			}

		} catch (Exception e) {
			System.out.println("Exception in moveDataToOracle");
			e.printStackTrace();
		}

	}

	/**
	 * move reports docs to oracle db and clean up
	 * 
	 */
	public void moveReportsToOracle() {
		JSONObject repDoc = null;
		JSONObject formatedrepDoc = null;
		String appType = "life";
		int pcnt = 0;
		String eappId = null;
		IEbixView view = client.getView_("advisor", "by_dateForAudit1");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);
		int docsPerPage = 100;
		try {
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
			while (pages.hasNext()) {
				System.out.println("Please Waite.. Processing Page:" + pcnt++);
				IEbixViewResponse response = pages.next();
				try {
					for (IEbixViewRow row : response) {
						String eid = row.getId();
						try {
							System.out.println("Report Id -" + eid);
							repDoc = getDocument(eid);
							String eapp_Status = safeGet(repDoc, "ST");
							eappId = safeGet(repDoc, "EID");
							if (eapp_Status.equals("Deleted")) {
								// Moving Deleted Cases Case Data to oracle
								JSONObject eappCaseData = getDocument(eappId);
								appType = safeGet(eappCaseData, "appType");
								if (!appType.equalsIgnoreCase("wealth")) {
									appType = "life";
								}
								boolean ismoved = moveCaseAudiToDB(eappId, true);
								System.out.println(eappId + " isMoved:" + ismoved);
							}
							if (repDoc != null && !repDoc.isEmpty()) {
								formatedrepDoc = getTableFormattedReportFromReportData(repDoc);
								boolean ismoved = saveReports(eappId, formatedrepDoc);
								if (ismoved) {
									client.delete(eid);
								}
							}
						} catch (Exception e) {
							System.out.println("Exception while processing:" + eid + " in moveReportsToOracle");
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					System.out.println("Exception while iterating view in moveReportsToOracle");
					e.printStackTrace();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
			}

		} catch (Exception e) {
			System.out.println("Exception in moveReportsToOracle");
			e.printStackTrace();
		}

	}

	/**
	 * Getting all Documents from CouchBase through Views
	 */
	public void findUnnecessaryDocsFromCouchBase() {
		IEbixDesignDocument designDoc = null;
		String mapFunction = null;
		IEbixViewDesign viewDesign = null;
		//File file = null;
		//FileWriter fr = null;
		boolean isUploadedCase = false;
		boolean isAdvisoruploaded = false;
		boolean isDeletedCase = false;
		JSONObject eappData = new JSONObject();
		try {
			designDoc = client.getDesignDoc_("appDocs");
			System.out.println("............::::Creating View::::............");
			if (designDoc == null) {
				designDoc = client.createDesignDocumentInstance("appDocs");
				mapFunction = "function(doc,meta){\n  emit(meta.id,null);\n}";
				viewDesign = client.createViewDesignInstance("by_docId", mapFunction);
				designDoc.setView(viewDesign);
				client.createDesignDoc(designDoc);
				System.out.println(":::::::::::::Created View::::::::::::::::");
			}
		} catch (Exception e) {
			logger.info("Something went wrong while creating Design Doc : " + designDoc.getName());
			e.printStackTrace();
		}

		try {
			Thread.sleep(5000);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
		
		IEbixView view = client.getView_("appDocs", "by_docId");
		IEbixQuery query = client.getQueryInstance_();
		query.setIncludeDocs(true);
		int docsPerPage = 50;
		try {
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
			System.out.println(":::::::::::::Fetching DOC's::::::::::::::::");
			//file = new File("log.txt");
			//fr = new FileWriter(file, false);
			while (pages.hasNext()) {
				IEbixViewResponse response = pages.next();
				try {
					for (IEbixViewRow row : response) {
						String eid = row.getId();					
						try {
							//fr.write(eid.toString() + "\r\n ");			
							System.out.println("Vendor options are Changed:" + eid);	
							if (null != eid && !eid.isEmpty() && eid.startsWith("COOPTrans-") && !eid.endsWith("AUDIT_AUDIT_LOG") && !eid.endsWith("_AAR_Client_1") && !eid.endsWith("_AAR_Client_2") && !eid.endsWith("AUDIT_SNAPSHOT")) {
								eappData = getDocument(eid);
								isUploadedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Uploaded") ? true : false;
								isAdvisoruploaded = safeGet(eappData, "advisorCode").equalsIgnoreCase("Uploaded") ? true : false;
								isDeletedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Deleted") ? true : false;
								if(!isDeletedCase && !isUploadedCase && !isAdvisoruploaded){
									JSONObject eappDatas = changeAArVendorOptions(eid,eappData);
									boolean isSaved=saveDocument(eid,eappDatas);
									System.out.println("Is is Key values is changed :  "+isSaved);
								}
							}						
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					System.out.println("Exception in Document Ids");
					e.printStackTrace();
				}
				try {
					Thread.sleep(1000);
				} catch (InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
			}
		} catch (Exception e) {
			System.out.println("Exception in findUnnecessaryDocsFromCouchBase");
			e.printStackTrace();
		} finally {
			// close resources
			try {
				//fr.close();
				if (null != designDoc) {
					// Delete the design doc here
					client.deleteDesignDoc("appDocs");
				}
			//} catch (IOException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * Move old call-back data to Orcle DB
	 */

	public void moveLeftOutcassess(int index) {
		String folderName = "moves";
		String fileStr = null;
		JSONArray idsList = null;
		JSONObject caseDocs = null;
		JSONObject reportDoc = null;
		String eappId = null;
		String appType = "Life";
		for (int i = index; i <= 16; i++) {
			fileStr = readFile(folderName, "move" + i + ".json");
			if (null != fileStr && !fileStr.isEmpty()) {
				try {
					idsList = (JSONArray) new JSONParser().parse(fileStr);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				if (null != idsList && !idsList.isEmpty()) {
					for (int j = 0; j < idsList.size(); j++) {
						eappId = (String) idsList.get(j);
						System.out.println(eappId + "-- Processing:");
						caseDocs = getDocument(eappId);
						if (null == caseDocs) {
							boolean isCasemoved = false;
							JSONObject callbackData = getDocument("callbackdata_" + eappId);
							if (null != callbackData && !callbackData.isEmpty()) {
								isCasemoved = moveCaseAudiToDB(eappId, true);
							}

						}
					}
				}
			}
			try {
				Thread.sleep(2000);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}

		}

	}
	
	
	/**
	 * Enhancements Data Changes For Inflight Cases
	 * @throws ParseException 
	 */

	public void enhancementsDataChangesForInflightCases(int index) throws ParseException {
		String folderName = "moves";
		String fileStr = null;
		JSONArray idsList = null;
		JSONObject caseDocs = null;
		JSONObject reportDoc = null;
		String eappId = null;
		String appType = null;
		String PolicyNumber=null;
		String combineValue=null;
		for (int i = index; i <= 16; i++) {
			fileStr = readFile(folderName, "move" + i + ".json");
			if (null != fileStr && !fileStr.isEmpty()) {
				try {
					idsList = (JSONArray) new JSONParser().parse(fileStr);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				if (null != idsList && !idsList.isEmpty()) {
					for (int j = 0; j < idsList.size(); j++) {
						eappId = (String) idsList.get(j);
						System.out.println(eappId + "-- Processing:");
						caseDocs = getDocument(eappId);
						 
						if (null != caseDocs && !caseDocs.isEmpty()) {
							appType = safeGet(caseDocs, "appType");
							if(appType.equalsIgnoreCase("Wealth")) {
								caseDocs=hanldingWealthInflightCasesData(caseDocs);
							}else {
								if(caseDocs.containsKey("GCAAROrderForm")) {
									caseDocs.put("GCAAROrderForm","No Preference");
								}								
								PolicyNumber=safeGet(caseDocs, "ingeniumPolicyNumber");
								combineValue=safeGet(caseDocs, "GCpolMonthlyPAD");
								if(PolicyNumber.length()==0 && (combineValue.length() > 0 && (combineValue.equalsIgnoreCase("CPAD") || combineValue.equalsIgnoreCase("CPDP")))) {
									caseDocs=updateSectionFlagForValidation(caseDocs);
								}
								if( PolicyNumber.length()==0 ) {
									caseDocs=updateSectionFlagForValidationPAD(caseDocs);
								}
								caseDocs = updateCallingInformationInflightCases(caseDocs);
							}

							saveDocument(eappId, caseDocs);
						}
						try {
							Thread.sleep(3000);
						} catch (InterruptedException ex) {
							Thread.currentThread().interrupt();
						}
					}
				}
			}
			try {
				Thread.sleep(5000);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}

		}

	}
	
	public JSONObject updateSectionFlagForValidation(JSONObject caseData) {	
		try {
		if(caseData.containsKey("validatedSectionsInfo")){
			JSONObject validitionObj=(JSONObject)caseData.get("validatedSectionsInfo");			
			if(validitionObj.containsKey("GCPolicy0")) {
				JSONObject validitionObj1=(JSONObject) validitionObj.get("GCPolicy0");
				if(validitionObj1.containsKey("isTouched")) {
					validitionObj1.put("isTouched", false);
					caseData.remove("GCpolMonthlyPAD");
				}

			}
		}
		if(caseData.containsKey("validatedSections")){
			JSONObject validitionObj=(JSONObject)caseData.get("validatedSections");	
			if(null!=validitionObj && validitionObj.containsKey("GCPolicy0")) {
				JSONObject GCPolicy0_errorObject = (JSONObject) validitionObj.get("GCPolicy0");
				JSONArray errorObject = (JSONArray) GCPolicy0_errorObject.get("errors");
				if(null == errorObject ||  errorObject.size()==0){
					errorObject  = new JSONArray();
					JSONObject errorObjectNew= new JSONObject();
					errorObjectNew.put("message", "Missing PAD Type");
					errorObjectNew.put("name", "GCpolMonthlyPAD");
					errorObjectNew.put("method", "required");     
					errorObject.add(errorObjectNew);
					GCPolicy0_errorObject.put("errors",errorObject);
				}
			}
		}
		
		} catch(Exception e){
			
		}
		return caseData;

	}
	
	
	public JSONObject updateSectionFlagForValidationPAD(JSONObject caseData) {
		try{
		if(caseData.containsKey("validatedSectionsInfo")){
			JSONObject validitionObj=(JSONObject)caseData.get("validatedSectionsInfo");			
			if(validitionObj.containsKey("GCPreAuthorizedDebitDetails0")) {
				JSONObject validitionObj1=(JSONObject) validitionObj.get("GCPreAuthorizedDebitDetails0");
				if(validitionObj1.containsKey("isTouched")) {
					validitionObj1.put("isTouched", false);
				}

			}
		}
		} catch(Exception e){
			
		}
		return caseData;

	}

	/**
	 * 
	 */
	public void updateOldReportDocuments() {

		JSONObject eappData = new JSONObject();
		JSONObject repDoc = new JSONObject();
		String appType = "life";
		int pcnt = 0;
		IEbixView view = client.getView_("advisor", "by_ApplicationType");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);
		int docsPerPage = 50;
		try {
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
			while (pages.hasNext()) {
				System.out.println("Please Waite.. Processing Page:" + pcnt++);
				IEbixViewResponse response = pages.next();
				try {
					for (IEbixViewRow row : response) {
						String eid = row.getId();
						try {
							if (null != eid && !eid.isEmpty() && eid.startsWith("COOPTrans-")) {
								eappData = getDocument(eid);
								appType = safeGet(eappData, "appType");
								if (!appType.equalsIgnoreCase("wealth")) {
									appType = "life";
								}
								repDoc = getFormattedReportFromCaseData(eappData, appType);
								client.set(eid.replace("COOPTrans", "Reports"), repDoc.toString());
							}
						} catch (Exception e) {
							System.out.println("Exception while processing:" + eid + " in updateOldReportDocuments");
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					System.out.println("Exception while iterating view in updateOldReportDocuments");
					e.printStackTrace();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
			}

		} catch (Exception e) {
			System.out.println("Exception in updateOldReportDocuments");
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * @param moveCasess
	 * @param moveAllCasess
	 * @param moveAllReports
	 * @param deleteDocs
	 */
	public void moveCasess(boolean moveCasess, boolean moveAllCasess, boolean moveAllReports, boolean deleteDocs) {

		JSONObject eappData = new JSONObject();
		JSONObject repDoc = new JSONObject();
		JSONObject formattedRepDoc = new JSONObject();
		boolean isUploadedCase = false;
		boolean isAdvisoruploaded = false;
		boolean isDeletedCase = false;
		String appType = "life";

		int pcnt = 0;
		IEbixView view = client.getView_("advisor", "by_ApplicationType");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);

		int docsPerPage = 50;
		IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
		while (pages.hasNext()) {
			System.out.println("Please Waite.. Processing Page:" + pcnt++);
			IEbixViewResponse response = pages.next();
			for (IEbixViewRow row : response) {
				String eid = row.getId();
				try {
					if (null != eid && !eid.isEmpty() && eid.startsWith("COOPTrans-")) {
						eappData = getDocument(eid);
						isUploadedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Uploaded") ? true : false;
						isAdvisoruploaded = safeGet(eappData, "advisorCode").equalsIgnoreCase("Uploaded") ? true
								: false;
						isDeletedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Deleted") ? true : false;
						if (moveCasess && moveAllCasess || (isDeletedCase || (isUploadedCase && isAdvisoruploaded))) {
							boolean ismoved = moveCaseAudiToDB(eid, deleteDocs);
							System.out.println(eid + " isMoved:" + ismoved);
						}
						if (moveAllReports || ((isDeletedCase || (isUploadedCase && isAdvisoruploaded)))) {
							appType = safeGet(eappData, "appType");
							if (!appType.equalsIgnoreCase("wealth")) {
								appType = "life";
							}
							repDoc = getFormattedReportFromCaseData(eappData, appType);
							formattedRepDoc = getTableFormattedReportFromReportData(repDoc);
							boolean ismoved = saveReports(eid, formattedRepDoc);
							if (ismoved) {
								client.delete(eid.replace("COOPTrans", "Reports"));
							}
							System.out.println(eid.replace("COOPTrans", "Reports") + " isMoved:" + ismoved);
						}
					}
				} catch (Exception e) {
					System.out.println("Exception while processing:" + eid + " in moveCasess");
					e.printStackTrace();
				}
			}

			try {
				Thread.sleep(2000);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}

	public boolean moveCaseAudiToDB(String eappId, boolean needToDeleteOracleMovedDocs) {
		boolean deleteDocs = false;
		if (null != eappId && !eappId.isEmpty()) {
			try {
				List objs = (List) getAbstractDAO().findByCriteria(EappCaseAudit.class, "CASEID = '" + eappId + "'");
				if (objs != null && objs.size() != 0) {
					EappCaseAudit OldEappCaseData = (EappCaseAudit) objs.get(0);
					OldEappCaseData = bindEappCaseAudit(eappId, OldEappCaseData);
					try {
						getAbstractDAO().update(OldEappCaseData);
						deleteDocs = true;
					} catch (Exception e) {
						deleteDocs = false;
						System.out.println(
								"Record not Updated ::: Exception while updating record with eappId:" + eappId);
						e.printStackTrace();
					}
				} else {
					EappCaseAudit OldEappCaseData = new EappCaseAudit();
					OldEappCaseData = bindEappCaseAudit(eappId, OldEappCaseData);
					try {
						getAbstractDAO().save(OldEappCaseData);
						deleteDocs = true;
					} catch (Exception e) {
						deleteDocs = false;
						System.out
								.println("Record not Saved ::: Exception while updating record with eappId:" + eappId);
						e.printStackTrace();
					}
				}

			} catch (DataAccessException e) {
				e.printStackTrace();
			} catch (Exception e) {
				System.out.println("Exception in moveCaseAudiToDB while processing :" + eappId);
				e.printStackTrace();
			}
		}

		if (!eappId.startsWith("Agent_Data_") && deleteDocs && needToDeleteOracleMovedDocs) {
			client.delete(eappId);
			client.delete(eappId + "AUDIT_AUDIT_LOG");
			client.delete(eappId + "AUDIT_SNAPSHOT");
			client.delete("eapp_pdf_" + eappId);
			client.delete("callbackdata_" + eappId);
		}

		return deleteDocs;
	}

	public boolean saveReports(String eappId, JSONObject eappJSONObject) {
		boolean isReportSaved = false;
		try {
			List objs = (List) getAbstractDAO().findByCriteria(EappReports.class, "EAPPID = '" + eappId + "'");
			if (objs != null && objs.size() != 0) {
				EappReports OldEappReports = (EappReports) objs.get(0);
				Long id = OldEappReports.getId();
				OldEappReports = prepareEappReportsFromJson(OldEappReports, eappJSONObject);
				OldEappReports.setId(id);
				getAbstractDAO().update(OldEappReports);
				isReportSaved = true;
			} else {
				EappReports OldEappRepoers = new EappReports();
				OldEappRepoers = prepareEappReportsFromJson(OldEappRepoers, eappJSONObject);
				getAbstractDAO().save(OldEappRepoers);
				isReportSaved = true;
			}

		} catch (Exception e) {
			System.out.println("Report not saved for EappId:" + eappId + " :::Exception in saveReports: " + e);
			isReportSaved = false;
			e.printStackTrace();
		}
		return isReportSaved;

	}

	private EappCaseAudit bindEappCaseAudit(String eappId, EappCaseAudit OldEappCaseData) throws DataAccessException {
		// getting data from couchbase.
		String caseData = fetch(eappId);
		String auditLog = fetch(eappId + "AUDIT_AUDIT_LOG");
		String snapShort = fetch(eappId + "AUDIT_SNAPSHOT");
		String pdfData = fetch("eapp_pdf_" + eappId);
		String callBackData = fetch("callbackdata_" + eappId);

		Blob caseBlob = convertToBlob(caseData);
		Blob auditBlob = convertToBlob(auditLog);
		Blob snapShortBlob = convertToBlob(snapShort);
		Blob pdfDataBlob = convertToBlob(pdfData);
		Blob callBackDataBlob = convertToBlob(callBackData);

		OldEappCaseData.setCaseid(eappId);
		if (null != caseBlob) {
			OldEappCaseData.setCaseData(caseBlob);
		}
		if (null != auditBlob) {
			OldEappCaseData.setAuditdata(auditBlob);
		}
		if (null != snapShortBlob) {
			OldEappCaseData.setSnapShot(snapShortBlob);
		}
		if (null != pdfDataBlob) {
			OldEappCaseData.setPdfData(pdfDataBlob);
		}
		if (null != callBackDataBlob) {
			OldEappCaseData.setCallbackData(callBackDataBlob);
		}

		if (eappId.startsWith("COOPTrans-") && null != caseData && !caseData.isEmpty()) {
			JSONObject formated_Json_eappDoc = null;
			String carrierCode = null;
			String appType = null;
			try {
				formated_Json_eappDoc = (JSONObject) new JSONParser().parse(caseData);
				carrierCode = (String) formated_Json_eappDoc.get("carrierCode");
				appType = (String) formated_Json_eappDoc.get("appType");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			OldEappCaseData.setAppType(appType);
			if (null != carrierCode && carrierCode.equalsIgnoreCase("CUMIS")) {
				OldEappCaseData.setType("CUMIS");
			} else {
				OldEappCaseData.setType("CLIC");
			}
		} else if (eappId.startsWith("D2CTransId-")) {
			OldEappCaseData.setType("D2C");
		} else if (eappId.startsWith("Agent_Data_")) {
			OldEappCaseData.setType("AGENT");
		}

		return OldEappCaseData;
	}

	private Blob convertToBlob(String data) {
		Blob blob = null;
		if (null != data && !data.isEmpty()) {
			byte[] buff = data.getBytes();
			try {
				blob = new SerialBlob(buff);
			} catch (SerialException e) {
				System.out.println("Exception in converting to Blob ::: " + e);
				e.printStackTrace();
			} catch (SQLException e) {
				System.out.println("Exception in converting to Blob ::: " + e);
				e.printStackTrace();
			}
		}
		return blob;
	}

	private String fetch(String eappId) {
		String val = (String) client.get(eappId);
		return null != val ? val : "";
	}

	public JSONObject getDocument(String id) {
		JSONObject jsonobject = null;
		try {
			String data = fetch(id);
			if (null != data && !data.isEmpty()) {
				jsonobject = (JSONObject) new JSONParser().parse(data);
			}

		} catch (Exception e) {
			System.out.println("Exception while getting document for:" + id);
			e.printStackTrace();
		}
		return jsonobject;
	}
	
	private String safeGet(JSONObject jso, String prop) {
		Object propobj = null;
		try {
			propobj = jso.get(prop);
		} catch (Exception exprop) {
		}
		return propobj == null ? "" : propobj.toString();
	}

	private void createMapperDocuments() {
		String mapperDoc = "{\"eappId\":\"EID\",\"policy\":\"No\",\"advisor\":\"A\",\"appType\":\"App\",\"modifiedDate\":\"date\",\"advisorCode\":\"AC\",\"sign\":\"sign\",\"carrierCode\":\"CC\",\"firstName\":\"FN\",\"lastName\":\"LN\",\"status\":\"ST\",\"product\":\"PR\",\"plan\":\"plan\",\"lives\":\"lives\",\"lwtk\":\"lwtk\",\"lastModifiedDate\":\"LMD\",\"deletedBy\":\"DB\",\"deletedDate\":\"DD\"}";
		String mapperDoc_life = "{\"EID\":\"eappId\",\"No\":\"ingeniumPolicyNumber\",\"A\":\"advisor\",\"App\":\"appType\",\"date\":\"dateMillis\",\"AC\":\"advisorCode\",\"sign\":\"SignType\",\"CC\":\"carrierCode\",\"FN\":\"GCCDFName_firstName\",\"LN\":\"GCCDFName_lastName\",\"ST\":\"eappStatus\",\"PR\":\"GCplaBase\",\"plan\":\"GCplaBasePlan\",\"lives\":\"GCplaNumbar\",\"lwtk\":\"lwtk\",\"LMD\":\"lastModifiedDate\",\"DB\":\"Deleted_By\",\"DD\":\"Deleted_date\",\"column_1\":\"\"}";
		String mapperDoc_welth = "{\"EID\":\"eappId\",\"No\":\"ingeniumPolicyNumber\",\"A\":\"advisor\",\"App\":\"appType\",\"date\":\"dateMillis\",\"AC\":\"advisorCode\",\"sign\":\"SignType\",\"CC\":\"carrierCode\",\"FN\":\"annPIName_firstName\",\"LN\":\"annPIName_lastName\",\"ST\":\"eappStatus\",\"PR\":\"wealth_product\",\"plan\":\"\",\"lives\":\"\",\"lwtk\":\"lwtk\",\"LMD\":\"lastModifiedDate\",\"DB\":\"Deleted_By\",\"DD\":\"Deleted_date\",\"column_1\":\"\"}";

		client.set("eappReportsMapper", mapperDoc);
		client.set("eappReportsMapper_life", mapperDoc_life);
		client.set("eappReportsMapper_wealth", mapperDoc_welth);
	}

	public JSONObject getFormattedReportFromCaseData(JSONObject eappJSONObject, String appType) {
		JSONObject valObj = new JSONObject();
		try {
			JSONObject reportsMapper = null;

			if (null != appType && appType.equals("Wealth")) {
				reportsMapper = getMapperDocument("eappReportsMapper_wealth");
			} else {
				reportsMapper = getMapperDocument("eappReportsMapper_life");
			}
			if (null != reportsMapper) {
				Iterator keys = reportsMapper.keySet().iterator();
				while (keys.hasNext()) {
					String key = (String) keys.next();
					valObj.put(key, eappJSONObject.get(reportsMapper.get(key)));
				}
				if (null == valObj.get("carrierCode") || valObj.get("carrierCode").toString().isEmpty()) {
					valObj.put("carrierCode", "CLIC");
				}
			} else {
				System.out.println("Document Not Found:::: eappReportsMapper :::: in CouchBase for appType=" + appType);
			}
			return valObj;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	public JSONObject getTableFormattedReportFromReportData(JSONObject eappJSONObject) {
		JSONObject valObj = new JSONObject();
		try {
			JSONObject reportsMapper = null;

			reportsMapper = getMapperDocument("eappReportsMapper");

			if (null != reportsMapper && !reportsMapper.isEmpty()) {
				Iterator keys = reportsMapper.keySet().iterator();
				while (keys.hasNext()) {
					String key = (String) keys.next();
					valObj.put(key, eappJSONObject.get(reportsMapper.get(key)));
				}
				if (null == valObj.get("carrierCode") || valObj.get("carrierCode").toString().isEmpty()) {
					valObj.put("carrierCode", "CLIC");
				}
			} else {
				System.out.println("Document :::: eappReportsMapper :::: Not Found in CouchBase");
			}
			return valObj;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	private EappReports prepareEappReportsFromJson(EappReports oldEappRepoers, JSONObject eappJSONObject) {
		ObjectMapper mapper = new ObjectMapper();

		try {
			oldEappRepoers = mapper.readValue(eappJSONObject.toJSONString(), EappReports.class);
		} catch (IOException e) {
			System.out.println("Error while parsing json to EappReports object :::: " + e.getMessage());
			e.printStackTrace();
		}

		return oldEappRepoers;
	}

	public JSONObject getMapperDocument(String id) {
		JSONObject obj = getDocument(id);
		if (null == obj || obj.isEmpty()) {
			createMapperDocuments();
			obj = getDocument(id);
		}
		return obj;
	}

	public AbstractDAOImpl getAbstractDAO() {
		return abstractDAO;
	}

	public void setAbstractDAO(AbstractDAOImpl abstractDAO) {
		this.abstractDAO = abstractDAO;
	}

	public String getEappDataObjectByDate(String sd, String sm, String sy, String ed, String em, String ey, String ehr,
			String emin, String esec, String reportType, String carrierCode, int listMin, int listMax) {

		JSONArray arrayRet = new JSONArray();
		int cbSize = 0;
		JSONObject returnVlaue = new JSONObject();
		listMin = listMin - 1;
		int oraMin = 0;
		int oraMax = listMax;
		int cbPageSize = 0;
		int inListSize = 5000;

		JSONArray jArray = new JSONArray();

		// all reports from CouchBase (latest records)
		Map<String, Object> arrayRetView = getEappReportsByDateFromView(sd, sm, sy, ed, em, ey, ehr, emin, esec,
				carrierCode);
		String eappIdsQuery = "";
		Map<String, Object> paramMap = new java.util.HashMap<String, Object>();
		if (null != arrayRetView && arrayRetView.size() != 0) {
			cbSize = arrayRetView.size();
			jArray.addAll(arrayRetView.values());
			eappIdsQuery = "";
			List<String> keyList = new ArrayList<String>(arrayRetView.keySet()); // (List<String>)
																					// arrayRetView.keySet();
			List<String> tempList = new ArrayList<String>();
			int nxtsize = 0;
			String idsString = "";
			for (int i = 0; i < keyList.size(); i += inListSize) {
				idsString = "";
				nxtsize = i + inListSize;
				if (nxtsize > keyList.size()) {
					nxtsize = keyList.size();
				}
				tempList = keyList.subList(i, nxtsize);
				for (String v : tempList) {
					if (idsString == "") {
						idsString = "'" + v + "'";
					} else {
						idsString = idsString + ",'" + v + "'";
					}
				}
				eappIdsQuery = eappIdsQuery + " and eappId NOT IN (" + idsString + ")";
			}
		}

		String lowRangeDate = sd + "-" + sm + "-" + sy + "_00:00:0";
		String upperRangeDate = ed + "-" + em + "-" + ey + "_" + ehr + ":" + emin + ":" + esec;
		String ccQuery = "";
		if (null != carrierCode && carrierCode.equalsIgnoreCase("CUMIS")) {
			ccQuery = "carriercode='CUMIS'";
		} else {
			// ideally carriercode will be 'CLIC' for CLIC & old records also
			// BCZ we are updating reports
			// update query if required
			ccQuery = "carriercode='' or carriercode IS NULL or carriercode='CLIC'";
		}

		String queryStr = "(modified_date >= to_date('" + lowRangeDate
				+ "','DD/MM/YYYY HH24:MI:SS') and modified_date <= to_date('" + upperRangeDate
				+ "','DD/MM/YYYY HH24:MI:SS')) and  (" + ccQuery + ") " + eappIdsQuery + " ORDER BY modified_date asc";
		List objsCNT = null;
		int oraListSize = 0;

		// for getting count of records in oracle to find total number of
		// records
		try {

			objsCNT = (List) getAbstractDAO()
					.executeNativeQuery("select count(*) from " + "eapp_reports" + " where " + queryStr, paramMap);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if (null != objsCNT && objsCNT.size() != 0) {
			try {
				oraListSize = (int) ((BigDecimal) objsCNT.get(0)).intValue();
			} catch (Exception e) {
				logger.error("cannot convert oracle record count to integer");
				e.printStackTrace();
			}
		}
		int cbMin = listMin, cbMax = cbSize;

		/*
		 * if(listMin <= cbSize){ if(cbSize > listMax ){ cbMax = listMax; }
		 * arrayRet.addAll(jArray.subList(cbMin,cbMax)); }
		 */
		// remove following line if you uncomment above line(for pagination)
		arrayRet.addAll(jArray);

		cbPageSize = arrayRet.size();

		// for Getting Records from oracle
		if (cbPageSize < (listMax - listMin)) {
			oraMax = listMax - listMin - cbPageSize;
			if (listMin > cbSize) {
				oraMin = listMin - cbSize;
			}

			List objs = new ArrayList();

			try {
				objs = (List) getAbstractDAO().executeCriteriaByRange(EappReports.class, queryStr, paramMap, oraMin,
						oraMax);

			} catch (DataAccessException e) {
				logger.error("Exceprion while retriving record fom oracle:: " + e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				logger.error("Exceprion while retriving record fom oracle:: " + e.getMessage());
				e.printStackTrace();
			}

			for (Object temp : objs) {
				EappReports report = (EappReports) temp;
				arrayRet.add(getReportJsonFromEappReport(report));

			}

		}

		returnVlaue.put("data", arrayRet);
		returnVlaue.put("totalCount", cbSize + oraListSize);

		return returnVlaue.toString();
	}

	private Map<String, Object> getEappReportsByDateFromView(String sd, String sm, String sy, String ed, String em,
			String ey, String ehr, String emin, String esec, String carrierCode) {
		// to get reports from view

		JSONParser parser = new JSONParser();
		JSONObject policyJsonDoc = null;

		JSONArray arrayRet = new JSONArray();

		// to get current day records from view (couchBase)
		IEbixView view1 = client.getView_("advisor", "by_dateForAudit1");
		IEbixQuery objQuery = client.getQueryInstance_();
		objQuery.setIncludeDocs(true);
		String lowRange = "[\"" + carrierCode + "\"," + "[" + sy + "," + sm + "," + sd + "]]";
		String upperRange = "[\"" + carrierCode + "\"," + "[" + ey + "," + em + "," + ed + "," + ehr + "," + emin + ","
				+ esec + "]]";
		String sortOrder = "asc";
		if (null != sortOrder && sortOrder.equalsIgnoreCase("desc")) {
			objQuery.setRange(upperRange, lowRange);
			objQuery.setDescending(true);
		} else {
			objQuery.setRange(lowRange, upperRange);
			objQuery.setDescending(false);
		}

		Map<String, Object> map = new java.util.HashMap<String, Object>();
		IEbixViewResponse res = client.excuteViewWithViewObjAndQueryObj(view1, objQuery);
		String repDocString = null;
		for (IEbixViewRow row : res) {
			try {
				if (row.getDocument() != null) {
					repDocString = row.getDocument().toString();
				}
				if (null != repDocString && !repDocString.isEmpty()) {
					policyJsonDoc = (JSONObject) parser.parse(repDocString);
					policyJsonDoc = getTableFormattedReportFromReportData(policyJsonDoc);
					map.put((String) policyJsonDoc.get("eappId"), policyJsonDoc);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return map;
	}

	public JSONObject getReportJsonFromEappReport(EappReports reports) {
		JSONObject resultTmp = new JSONObject();
		ObjectMapper mapper = new ObjectMapper();
		try {
			String resultStr = "";
			try {
				resultStr = mapper.writeValueAsString(reports);
			} catch (Exception e) {
				e.printStackTrace();
			}
			resultTmp = (JSONObject) new JSONParser().parse(resultStr);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultTmp;
	}

	private void moveReportsToOracleByDate() {

		Map<String, String> dateMap = null;
		try {
			dateMap = readDates();
		} catch (Exception e) {
			System.out.println("Exception while reading dates... Please try again with proper dates");
			e.printStackTrace();
		}
		String[] startDate = null;
		String[] endtDate = null;
		// JSONArray reportsArray = null;
		boolean isRenamed = false;

		System.out.println("Please waite Fetching Reports...");

		if (null != dateMap && !dateMap.isEmpty()) {
			startDate = dateMap.get("startDate").split("-");
			endtDate = dateMap.get("endDate").split("-");
			if (null != startDate && null != endtDate) {
				String[] carrierCode = { "CLIC", "CUMIS" };
				Map<String, Object> returnMap = new HashMap<String, Object>();
				boolean isUploadedCase = false;
				boolean isAdvisoruploaded = false;
				boolean isDeletedCase = false;
				for (int i = 0; i < carrierCode.length; i++) {
					System.out.println("Fetching Reports by carrierCode:" + carrierCode[i]);
					try {
						returnMap = getEappReportsByDateFromView(startDate[0], startDate[1], startDate[2], endtDate[0],
								endtDate[1], endtDate[2], "23", "59", "59", carrierCode[i]);
						if (null != returnMap && !returnMap.isEmpty()) {
							System.out.println(
									"toal records found by carrierCode:" + carrierCode[i] + ": " + returnMap.size());
							JSONArray retArray = new JSONArray();
							retArray.addAll(returnMap.values());
							if (null != retArray && !retArray.isEmpty()) {
								// reportsArray.add(retArray);
								JSONObject responseObj = null;
								String eappId = "";
								String status = "";
								String appType = "";
								for (int j = 0; j < retArray.size(); j++) {
									responseObj = (JSONObject) retArray.get(j);
									eappId = safeGet(responseObj, "eappId");
									status = safeGet(responseObj, "status");
									isUploadedCase = safeGet(responseObj, "eappStatus").equalsIgnoreCase("Uploaded")
											? true : false;
									isAdvisoruploaded = safeGet(responseObj, "advisorCode").equalsIgnoreCase("Uploaded")
											? true : false;
									isDeletedCase = safeGet(responseObj, "eappStatus").equalsIgnoreCase("Deleted")
											? true : false;

									if (isDeletedCase || (isUploadedCase && isAdvisoruploaded)) {
										// Moving Deleted Cases Case Data to
										// oracle
										JSONObject eappCaseData = getDocument(eappId);
										appType = safeGet(eappCaseData, "appType");
										if (!appType.equalsIgnoreCase("wealth")) {
											appType = "life";
										}
										boolean ismoved = moveCaseAudiToDB(eappId, true);
										System.out.println(eappId + " isMoved:" + ismoved);
									}
									if (responseObj != null && !responseObj.isEmpty()
											&& eappId.startsWith("COOPTrans")) {
										boolean ismoved = saveReports(eappId, responseObj);
										if (ismoved) {
											System.out.println(eappId + " isMoved:" + ismoved);
											client.delete(eappId.replace("COOPTrans", "Reports"));
										}
									}
								}

							}
						}
						try {
							System.out.println("Please waite...");
							Thread.sleep(3000);
						} catch (InterruptedException ex) {
							Thread.currentThread().interrupt();
						}

					} catch (Exception e) {
						System.out.println("Exception while Fetching Reports by carrierCode:" + carrierCode[i]);
						e.printStackTrace();
					}
				}
				System.out.println("compleated Fetching Reports");
			}
		}
	}

	/*
	 * Service for getting agent level data doc generate the while in
	 */
	
	public String advisorDocs() {

		String agentUPN = null;
		String agentOID = null;
		String docs = null;
		List object = new ArrayList<String>();
		org.json.simple.JSONObject currentAdvisorInbox = null;
		JSONObject agentId = getDocument("OIDUPN_Mapper");
		Set<String> keys = agentId.keySet();
		Iterator<String> a = keys.iterator();
		while (a.hasNext()) {
			try {
				agentUPN = a.next();
				//System.out.println("--------------- : " + agentUPN);
				agentOID = (String) agentId.get(agentUPN);
				object.add(agentOID + "_" + "CLIC_AdvisorInbox");
				object.add(agentOID + "_" + "CUMIS_AdvisorInbox");
				if (!"null".equalsIgnoreCase(agentUPN) && !agentUPN.isEmpty() && agentUPN != null && agentOID != null && !agentOID.isEmpty() && !"null".equalsIgnoreCase(agentOID)) {
					Iterator iter = object.iterator();
					while (iter.hasNext()) {
						try {
							docs = (String) iter.next();
							currentAdvisorInbox = getDocument(docs);
							if (null == currentAdvisorInbox || currentAdvisorInbox.isEmpty()) {
								currentAdvisorInbox = createAdvisorInboxLiteDocument(agentUPN, agentOID, "CUMIS");
								currentAdvisorInbox = createAdvisorInboxLiteDocument(agentUPN, agentOID, "CLIC");
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					object.removeAll(object);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}

		return currentAdvisorInbox.toString();
	}
	
	
	
	public org.json.simple.JSONObject createAdvisorInboxLiteDocument(String agentId, String OID, String carrierCode) {

		IEbixDesignDocument designDoc = null;
		IEbixView view = null;
		IEbixQuery query = null;
		IEbixPaginator paginatedQuery = null;
		int totalRecordcount = 0;
		org.json.simple.JSONObject tempObj = new org.json.simple.JSONObject();

		org.json.simple.JSONObject masteradvisorObj = new org.json.simple.JSONObject();
		org.json.simple.JSONObject currentAdvisorData = new org.json.simple.JSONObject();

		JSONParser parser = new JSONParser();
		int recordsPerPage = 50;

		try {
			designDoc = client.getDesignDoc_("advisor");
			view = client.getView_("advisor", "by_AppStatus");

			query = client.getQueryInstance_();

			query.setIncludeDocs(true);

			String lowRange = "[\"" + carrierCode + "\",\"" + agentId + "\"]";
			String upperRange = "[\"" + carrierCode + "\",\"" + agentId + "\",\"\uefff\"]";

			query.setRange(lowRange, upperRange);
			query.setDescending(false);

			paginatedQuery = client.paginatedQuery(view, query, recordsPerPage);

			String rowData = null;
			String eappId = null;

			while (paginatedQuery.hasNext()) {
				IEbixViewResponse response = paginatedQuery.next();
				totalRecordcount = totalRecordcount + response.size();
				for (IEbixViewRow row : response) {
					try {
						if (row.getDocument() != null) {
							rowData = row.getDocument().toString();

							eappId = row.getId();
						}
						if (null != rowData && null != eappId) {
							tempObj = (org.json.simple.JSONObject) parser.parse(rowData);
							masteradvisorObj = new org.json.simple.JSONObject();

							// mapping the fields
							org.json.simple.JSONObject inboxMapperObj = (org.json.simple.JSONObject) getDocument(
									"InboxParameterMapper").get(safeGet(tempObj, "appType"));
							for (Iterator iterator = inboxMapperObj.keySet().iterator(); iterator.hasNext();) {
								String key = (String) iterator.next();
								if (tempObj.containsKey(inboxMapperObj.get(key))) {
									masteradvisorObj.put(key, tempObj.get(inboxMapperObj.get(key)));
								} else {
									// masteradvisorObj.put(key,
									// inboxMapperObj.get(key));
									masteradvisorObj.put(key, "");
								}
							}
							currentAdvisorData.put(eappId, masteradvisorObj);

						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			// creating inbox_lite document for advisor with OID
			if (OID != null && !OID.isEmpty() && !OID.equalsIgnoreCase("null")) {
				saveDocument(OID + "_" + carrierCode + "_AdvisorInbox", currentAdvisorData);
				System.out.println("creating new document:" + OID + "_" + carrierCode + "_AdvisorInbox");
			} else {
				System.out.println("Falied to creating new document:" + OID + "_" + carrierCode + "_AdvisorInbox");
			}
		} catch (Exception e) {
			System.out.println("Exception while getting records from view while creating agentInbox document");
			e.printStackTrace();
		}

		return currentAdvisorData;
	}



	public boolean saveDocument(String docId, JSONObject jsonObject) {
		boolean isSaved = false;
		try {
			isSaved = saveDocumentWithString(docId, jsonObject.toString());
			
			if (isSaved && !safeGet(jsonObject, "eappId").isEmpty() && safeGet(jsonObject, "eappId").startsWith("COOPTrans") &&  safeGet(jsonObject, "type").equals("eapp")) {
				 try {
					 //Here the code for Inbox with advisor case documents with out view
						if(null!=jsonObject && !safeGet(jsonObject, "advisor").isEmpty() ){
						
							boolean isUploadedCase = safeGet(jsonObject, "eappStatus").equalsIgnoreCase("Uploaded")?true:false;
							boolean isAdvisoruploaded = safeGet(jsonObject, "advisorCode").equalsIgnoreCase("Uploaded")?true:false;
							boolean isDeletedCase = safeGet(jsonObject, "eappStatus").equalsIgnoreCase("Deleted")?true:false;
							
							String carrierCode=safeGet(jsonObject, "carrierCode");
							String advisor = safeGet(jsonObject, "advisor");
							org.json.simple.JSONObject upnOidMapper = getDocument("OIDUPN_Mapper");
							String OID = (String) upnOidMapper.get(advisor);
							if (OID!=null && !OID.isEmpty()) {
								String currentAdvisorDoc = OID+"_"+carrierCode+"_AdvisorInbox";
								if(isAdvisoruploaded || isUploadedCase || isDeletedCase ) {
									deleteEappIdFromDoc(currentAdvisorDoc,safeGet(jsonObject, "eappId"));
								} else
								   saveAdvisorCurrenteappId(jsonObject,currentAdvisorDoc,safeGet(jsonObject, "eappId"));
							}
						}
					 } catch(Exception e) {
						 System.out.println("Error to save Advisor Inbox document "+e.getMessage());
					 }
					 try{
						// eappAuditService.doAudit(docId);
						 updateReportJson(jsonObject);
					 }catch(Exception e){
						 System.out.println("Error while performing audit/updateReportJson: "+e.getMessage());
					 }
					}
		} catch (Exception e) {
			System.out.println("saveDocument:: " + e.getMessage());
		}
		return isSaved;
	}

	public boolean saveDocumentWithString(String docId, String jsonObject) {
		boolean isSaved = false;
		try {
			client.set(docId, jsonObject.toString());
			isSaved = true;
		} catch (Exception e) {
			System.out.println("saveDocument:: " + e.getMessage());
		}
		return isSaved;
	}
	/*
	 * Delete unnecessary html docs from couch base
	 */
	public void delatingUnnecessaryDocs() {
		JSONObject agentId = getDocument("UnnessaryDocs");
		JSONArray retArray = (JSONArray) agentId.get("htmlDocs");
		if (null != retArray && !retArray.isEmpty()) {
			String responseObjOne = null;
			for (int j = 0; j < retArray.size(); j++) {
				responseObjOne = (String) retArray.get(j);
				System.out.println("----------------- :" + responseObjOne.toString());
				// client.delete(responseObjOne);
			}
		}
	}
	
	public JSONObject changeAArVendorOptions(String eappId,JSONObject eappData) {
		try {
			String PolicyNumber="";
			String AAROrderForm="";
			if (null != eappId && !eappId.isEmpty()) {
				PolicyNumber=safeGet(eappData, "ingeniumPolicyNumber");
				AAROrderForm=safeGet(eappData, "GCAAROrderForm");			
				if(null != PolicyNumber && !PolicyNumber.isEmpty() && null != AAROrderForm && !AAROrderForm.isEmpty()){
					eappData.put("GCAAROrderForm", "No Preference");
				}else if(null != AAROrderForm && !AAROrderForm.isEmpty()) {
					eappData.put("GCAAROrderForm","");
				}
			}
		} catch (Exception e) {
			logger.fatal("Change Vendor options:: " + e.getMessage());
		}
		return eappData;

	}
	
	public void addingAddvisorCodeForOldCases() {
		// TODO Auto-generated method stub
		org.json.simple.JSONObject currentAdvisorInbox = null;
		String docName ="";
		JSONObject advisorUpnIds = getDocument("OIDUPN_Mapper");
		Set<String> documents = new LinkedHashSet();
		if (advisorUpnIds != null && !advisorUpnIds.isEmpty()) {
			documents = advisorUpnIds.keySet();
			for (String key : documents) {
				String[] carrierCode = {"CLIC", "CUMIS"};
				for( int i = 0; i <carrierCode.length; i++){
					docName = advisorUpnIds.get(key)+"_"+carrierCode[i]+"_AdvisorInbox";
					currentAdvisorInbox = getDocument(docName);
					if(currentAdvisorInbox != null && !currentAdvisorInbox.isEmpty()) { 						
						currentAdvisorInbox = getRecordsFromDocForInboxSSALite(currentAdvisorInbox);

						boolean isSaved = saveDocument(docName,currentAdvisorInbox);
						System.out.println(docName+" is saved :  "+isSaved);
					}
				}
			}


		}

	}
	
	
	private org.json.simple.JSONObject getRecordsFromDocForInboxSSALite(org.json.simple.JSONObject response ){
		org.json.simple.JSONObject advisorInboxDoc = new org.json.simple.JSONObject();
		Set<String> documents = new LinkedHashSet();
		if (response != null && !response.isEmpty()) {
			documents = response.keySet();
		}

		for (String key : documents) {
			try
			{
				org.json.simple.JSONObject caseOidData = new JSONObject();
				caseOidData=(org.json.simple.JSONObject) response.get(key);
				JSONObject caseData = getDocument(key);
				String advisorCode = (String) caseData.get("advisorCode");
					//JSONObject advisorRecord = (JSONObject) caseOidData.get(key);
					caseOidData.put("advisorCode", advisorCode);
					advisorInboxDoc.put(key,caseOidData);
				

			}catch(Exception e){
				System.out.println("Exception in getRecordsFromDocForInboxSSALite:: "+e);
			}
		}

		return advisorInboxDoc;
	}
	

	private void updateBasePlanVlaues() {
		org.json.simple.JSONObject currentAdvisorInbox = null;
		String docName ="";
		JSONObject advisorUpnIds = getDocument("OIDUPN_Mapper");
		Set<String> documents = new LinkedHashSet();
		Set<String> eappIds  = new LinkedHashSet();
		JSONObject reportDoc = null;
		JSONObject caseDoc = null;
		JSONObject appSetup = null;
		String reportId = "";
		String planVal = "";
		String newPlanVal = "";
		boolean isSaved = false;
//		String plans_str = "{\"Critical Assist® III with LOIE - Level to Age 75\":\"Critical Assist® - Level to 75\",\"Critical Assist® Head Start III - 10 Year Renewals to Age 75\":\"Critical Assist® Head Start - 10 Year Renewals to 75\",\"Critical Assist® Head Start III - 25 Year with 20 Year Renewals to Age 75\":\"Critical Assist® Head Start - 25 Year with 20 Year Renewals to 75\",\"Critical Assist® III with LOIE – 25 Year Renewable\":\"Critical Assist® - 25 Year with 20 Year Renewals to 75\",\"Critical Assist® III with LOIE - 10 Year Renewals to Age 75\":\"Critical Assist® - 10 Year Renewals to 75\",\"Critical Assist® Head Start III - Level to Age 75\":\"Critical Assist® Head Start - Level to 75\"}";
//		String plans_str = "{\"Critical Assist® III with LOIE - Level to Age 75\":\"Critical Assist® - Level to 75\",\"Critical Assist® Head Start III - 10 Year Renewals to Age 75\":\"Critical Assist® Head Start - 10 Year Renewals to 75\",\"Critical Assist® Head Start III - 25 Year with 20 Year Renewals to Age 75\":\"Critical Assist® Head Start - 25 Year with 20 Year Renewals to 75\",\"Critical Assist® III with LOIE – 25 Year Renewable\":\"Critical Assist® - 25 Year with 20 Year Renewals to 75\",\"Critical Assist® III with LOIE - 10 Year Renewals to Age 75\":\"Critical Assist® - 10 Year Renewals to 75\",\"Critical Assist® Head Start III - Level to Age 75\":\"Critical Assist® Head Start - Level to 75\",\"Critical Assist® Head Start - Level to 75\":\"Critical Assist® Head Start - Level to Age 75\"}";
		//String plans_str = "{\"Critical Assist\u00AE III with LOIE - Level to Age 75\":\"Critical Assist\u00AE - Level to 75\",\"Critical Assist\u00AE Head Start III - 10 Year Renewals to Age 75\":\"Critical Assist\u00AE Head Start - 10 Year Renewals to 75\",\"Critical Assist\u00AE Head Start III - 25 Year with 20 Year Renewals to Age 75\":\"Critical Assist\u00AE Head Start - 25 Year with 20 Year Renewals to 75\",\"Critical Assist\u00AE III with LOIE \u2013 25 Year Renewable\":\"Critical Assist\u00AE - 25 Year with 20 Year Renewals to 75\",\"Critical Assist\u00AE III with LOIE - 10 Year Renewals to Age 75\":\"Critical Assist\u00AE - 10 Year Renewals to 75\",\"Critical Assist\u00AE Head Start III - Level to Age 75\":\"Critical Assist\u00AE Head Start - Level to 75\",\"Critical Assist\u00AE Head Start - Level to Age 75\":\"Critical Assist\u00AE Head Start - Level to 75\",\"Critical Assist\u00AE Head Start - Level to 75\":\"Critical Assist\u00AE Head Start - Level to 75\"}";
		//String plans_str = "{\"Critical Assist\u00AE Head Start - 10 Year Renewals to 75\":\"Critical Assist\u00AE - Head Start - 10 Year Renewals to 75\",\"Critical Assist\u00AE Head Start - 25 Year with 20 Year Renewals to 75\":\"Critical Assist\u00AE - Head Start - 25 Year with 20 Year Renewals to 75\",\"Critical Assist\u00AE Head Start - Level to 75\":\"Critical Assist\u00AE - Head Start - Level to 75\",\"Critical Assist\u00AE \u2013 Head Start - Level 20-Pay with Coverage to 75\":\"Critical Assist\u00AE - Head Start - Level 20-Pay with Coverage to 75\"}";
		String plans_str = "{\"Critical Assist\u00AE III with LOIE - Level to Age 75\":\"Critical Assist\u00AE - Level to 75\",\"Critical Assist\u00AE Head Start III - 10 Year Renewals to Age 75\":\"Critical Assist\u00AE - Head Start - 10 Year Renewals to 75\",\"Critical Assist\u00AE Head Start III - 25 Year with 20 Year Renewals to Age 75\":\"Critical Assist\u00AE - Head Start - 25 Year with 20 Year Renewals to 75\",\"Critical Assist\u00AE III with LOIE \u2013 25 Year Renewable\":\"Critical Assist\u00AE - 25 Year with 20 Year Renewals to 75\",\"Critical Assist\u00AE III with LOIE - 10 Year Renewals to Age 75\":\"Critical Assist\u00AE - 10 Year Renewals to 75\",\"Critical Assist\u00AE Head Start III - Level to Age 75\":\"Critical Assist\u00AE - Head Start - Level to 75\"}";
		JSONObject plans = null;
		try {
			plans = (JSONObject) new JSONParser().parse(plans_str);
		} catch (ParseException e) {
			System.out.println("Exception while parsing planes data:: "+e);
		}
		if(plans == null){
			System.out.println("planes data is empty, aborting operation");
			return;
		}
		if (advisorUpnIds != null && !advisorUpnIds.isEmpty()) {
			documents = advisorUpnIds.keySet();
			for (String upn : documents) {
				String[] carrierCode = {"CLIC", "CUMIS"};
				for( int i = 0; i <carrierCode.length; i++){
					try {
						docName = advisorUpnIds.get(upn)+"_"+carrierCode[i]+"_AdvisorInbox";
						currentAdvisorInbox = getDocument(docName);
						if(currentAdvisorInbox != null && !currentAdvisorInbox.isEmpty()) { 						
							eappIds = currentAdvisorInbox.keySet();
							for (String eappId : eappIds) {
								try {
									reportId = eappId.replace("COOPTrans", "Reports");
									reportDoc = getDocument(reportId);
									if(null != reportDoc && !reportDoc.isEmpty()){
										planVal = (String) reportDoc.get("PR");
										if(plans.containsKey(planVal)){
											newPlanVal = (String) plans.get(planVal);
											caseDoc = getDocument(eappId);
											if(null != caseDoc && !caseDoc.isEmpty()){
												caseDoc.put("GCplaBase", newPlanVal);
												caseDoc.put("lifeplaBaseAppSetup", newPlanVal);
												appSetup = (JSONObject) caseDoc.get("Applicatisetup_Data");
												if(null != appSetup && !appSetup.isEmpty()){
													appSetup.put("GCplaBase", newPlanVal);
													appSetup.put("lifeplaBaseAppSetup", newPlanVal);
													caseDoc.put("Applicatisetup_Data", appSetup);
												}else{
													System.out.println("Applicatisetup_Data is not prasent in caseData for EappId"+eappId);
												}
												isSaved = saveDocument(eappId,caseDoc);
												if(isSaved){
													System.out.println("updated BasePlan Vlaue of eappId:: "+eappId);												
												}else{
													System.out.println("issue in updating BasePlan Vlaue of eappId:: "+eappId);
												}
											}else{
												System.out.println("cannot find case document with id:: "+eappId);
											}
										}
									}else{
										System.out.println("cannot find report document with id:: "+reportId);
									}
								} catch (Exception e) {
									System.out.println("Exception while processing eappId:"+eappId);
									e.printStackTrace();
								}
							}
						}
					} catch (Exception e) {
						System.out.println("Exception while processing of UPN:"+upn+" with carrierCode:"+carrierCode);
						e.printStackTrace();
					}
				}
			}
		}else{
			System.out.println("aborting operation, OIDUPN_Mapper document is empty/null");
		}

	}
	
	private void updateMCIRidersVlaues() {
	org.json.simple.JSONObject currentAdvisorInbox = null;
	String docName ="";
	JSONObject advisorUpnIds = getDocument("OIDUPN_Mapper");
	Set<String> documents = new LinkedHashSet();
	Set<String> eappIds  = new LinkedHashSet();
	JSONObject reportDoc = null;
	JSONObject caseDoc = null;
	JSONObject appSetup = null;
	JSONArray MCIRiders=null;
	String reportId = "";
	String planVal = "";
	String newPlanVal = "";
	JSONArray MCIRidersListArray=new JSONArray();
	boolean isSaved = false;
	FileWriter writer = null;
	int numberOfLives=1;
	int clno=1;
	String cloneString=null;
	String clientString=null;
	String GCplaCost="";
	String CreatedDate="";
	String cumisMCIRider="";
	try{
		String folderName = "MCIRidersList";
		String filePath = "." + File.separator + folderName + File.separator + "MCIRidersResult.csv";
		File file = new File(filePath);
	    if(!file.getParentFile().exists()){
	    	file.getParentFile().mkdirs();
	    }
	    //Remove if clause if you want to overwrite file
	    if(!file.exists()){
	        try {
	        	file.createNewFile();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	writer = new FileWriter(file);
	//columns in csv file
	writer.append("Last Name").append(",")
	.append("First Name").append(",")
	.append("Financial Advisor Code").append(",")
	.append("Financial Advisor Name").append(",")
	.append("Base Product").append(",")
	.append("Base Plan Type").append(",")
	.append("Product Variant").append(",")
	.append("# of Lives").append(",")
	.append("Primary/Secondary Client").append(",")
	.append("MCI Rider Code").append(",")
	.append("CUMIS MCI Rider Code").append(",")
	.append("Eapp Status").append(",")
	.append("Type").append(",")
	.append("LWTK").append(",")
	.append("Company").append(",")
	.append("Eapp Id").append(",")
	.append("Created Date").append(",")
	.append("Last Modified Date").append(",");
	writer.append("\n");
	//add the MCI Riders List
	MCIRidersListArray.add("3785");
	MCIRidersListArray.add("3786");
	MCIRidersListArray.add("3789");
	MCIRidersListArray.add("3790");
	MCIRidersListArray.add("3804");
	MCIRidersListArray.add("3806");
	MCIRidersListArray.add("3787");
	MCIRidersListArray.add("3788");
	MCIRidersListArray.add("3805");
	MCIRidersListArray.add("3807");
	MCIRidersListArray.add("3962");
	MCIRidersListArray.add("3967");
	MCIRidersListArray.add("3973");
	MCIRidersListArray.add("3976");
	MCIRidersListArray.add("3978");
	MCIRidersListArray.add("3979");
	MCIRidersListArray.add("4159");
	MCIRidersListArray.add("4160");
	MCIRidersListArray.add("4161");
	MCIRidersListArray.add("4162");
	MCIRidersListArray.add("4288");
	MCIRidersListArray.add("4290");
	MCIRidersListArray.add("3787");
	MCIRidersListArray.add("4346");
	MCIRidersListArray.add("4289");
	MCIRidersListArray.add("4291");
	MCIRidersListArray.add("4165");
	MCIRidersListArray.add("4170");
	MCIRidersListArray.add("4176");
	MCIRidersListArray.add("4179");
	MCIRidersListArray.add("4181");
	MCIRidersListArray.add("4182");
	if (advisorUpnIds != null && !advisorUpnIds.isEmpty()) {
		documents = advisorUpnIds.keySet();
		for (String upn : documents) {
			String[] carrierCode = {"CLIC", "CUMIS"};
			for( int i = 0; i <carrierCode.length; i++){
				try {
					
					docName = advisorUpnIds.get(upn)+"_"+carrierCode[i]+"_AdvisorInbox";
					currentAdvisorInbox = getDocument(docName);
					if(currentAdvisorInbox != null && !currentAdvisorInbox.isEmpty()) { 						
						eappIds = currentAdvisorInbox.keySet();
						for (String eappId : eappIds) {
							try {
								reportId = eappId.replace("COOPTrans", "Reports");
								reportDoc = getDocument(reportId);
								//if(null != reportDoc && !reportDoc.isEmpty()){
										caseDoc = getDocument(eappId);
										if(null != caseDoc && !caseDoc.isEmpty()){
											String BasePlan=safeGet(caseDoc, "GCplaBase");
											if(BasePlan.equalsIgnoreCase("Universal Life")){
												 GCplaCost=safeGet(caseDoc, "GCplaCostOfInsurance");
											}else if(BasePlan.equalsIgnoreCase("Versatile Term")){
												GCplaCost=safeGet(caseDoc, "GCcliLevel");
												GCplaCost=GCplaCost+" Year";
											}else{
												GCplaCost="";
											}
											if(caseDoc.containsKey("eappCreatedDate")){
											DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:MM:SS");
											long eappCreatedDate=Long.parseLong(safeGet(caseDoc, "eappCreatedDate"));
											Calendar calendar = Calendar.getInstance();
											calendar.setTimeInMillis(eappCreatedDate);
											CreatedDate=formatter.format(calendar.getTime());
											}
											if(caseDoc.containsKey("GCplaNumbar") && !safeGet(caseDoc,"GCplaNumbar").isEmpty() && !((safeGet(caseDoc,"GCplaNumbar").trim().length())>1)){
											numberOfLives=Integer.parseInt(safeGet(caseDoc,"GCplaNumbar"));
											}
											for(int no=0;no<numberOfLives;no++){
												cloneString=(no>0)?"clone"+no+"_":"";
												clno=no+1;
												clientString=(clno>=0)?"Client "+clno+"":"";
											if(caseDoc.containsKey(cloneString+"lifeRBList")){
											 for(int j=0;MCIRidersListArray.size()>j;j++){
												String MCIRidersListVal=(String) MCIRidersListArray.get(j);
												if(caseDoc.containsKey(cloneString+"lifeRBList") && caseDoc.get(cloneString+"lifeRBList") instanceof String){
													String lifeRBListString=(String) caseDoc.get(cloneString+"lifeRBList");
													 if(lifeRBListString.contains(MCIRidersListVal)){
														 if((safeGet(caseDoc, "carrierCode")).equalsIgnoreCase("CUMIS")){
															 JSONObject cumisRiders=getDocument("cumisRiderPlanCodeList");
															 cumisMCIRider=safeGet(cumisRiders,MCIRidersListVal); 
														 }
													    	writer.append(safeGet(caseDoc, "lifeCDFNameAppSetup_firstName")).append(",")
													    	.append(safeGet(caseDoc, "lifeCDFNameAppSetup_lastName")).append(",")
													    	.append(safeGet(caseDoc, "advisorCode")).append(",")
													    	.append(safeGet(caseDoc, "advisor")).append(",")
													    	.append(safeGet(caseDoc, "GCplaBase")).append(",")
													    	.append(safeGet(caseDoc, "GCplaBasePlan")).append(",")
													    	.append(GCplaCost).append(",")
													    	.append(safeGet(caseDoc, "GCplaNumbar")).append(",")
													    	.append(clientString).append(",")
													    	.append(MCIRidersListVal).append(",")
													    	.append(cumisMCIRider).append(",")
													    	.append(safeGet(caseDoc, "eappStatus")).append(",")
													    	.append(safeGet(caseDoc, "appType")).append(",")
													    	.append(safeGet(caseDoc, "lwtk")).append(",")
													    	.append(safeGet(caseDoc, "carrierCode")).append(",")
													    	.append(safeGet(caseDoc, "eappId")).append(",")
													    	.append(CreatedDate).append(",")
													    	.append(safeGet(caseDoc, "lastModifiedDate")).append(",");
													    	
													    	
													    	writer.append("\n");
													    	break;
													    }
												}else if(caseDoc.containsKey(cloneString+"lifeRBList") && caseDoc.get(cloneString+"lifeRBList") instanceof JSONArray){
											    JSONArray lifeRBListArray=(JSONArray) caseDoc.get(cloneString+"lifeRBList");
											    if(lifeRBListArray.contains(MCIRidersListVal)){
											    	if((safeGet(caseDoc, "carrierCode")).equalsIgnoreCase("CUMIS")){
														 JSONObject cumisRiders=getDocument("cumisRiderPlanCodeList");
														 cumisMCIRider=safeGet(cumisRiders,MCIRidersListVal); 
													 }
											    	writer.append(safeGet(caseDoc, "lifeCDFNameAppSetup_firstName")).append(",")
											    	.append(safeGet(caseDoc, "lifeCDFNameAppSetup_lastName")).append(",")
											    	.append(safeGet(caseDoc, "advisorCode")).append(",")
											    	.append(safeGet(caseDoc, "advisor")).append(",")
											    	.append(safeGet(caseDoc, "GCplaBase")).append(",")
											    	.append(safeGet(caseDoc, "GCplaBasePlan")).append(",")
											    	.append(GCplaCost).append(",")
											    	.append(safeGet(caseDoc, "GCplaNumbar")).append(",")
											    	.append(clientString).append(",")
											    	.append(MCIRidersListVal).append(",")
											    	.append(cumisMCIRider).append(",")
											    	.append(safeGet(caseDoc, "eappStatus")).append(",")
											    	.append(safeGet(caseDoc, "appType")).append(",")
											    	.append(safeGet(caseDoc, "lwtk")).append(",")
											    	.append(safeGet(caseDoc, "carrierCode")).append(",")
											    	.append(safeGet(caseDoc, "eappId")).append(",")
											    	.append(CreatedDate).append(",")
											    	.append(safeGet(caseDoc, "lastModifiedDate")).append(",");
											    	
											    	writer.append("\n");
											    	break;
											    }
											  }
											}
										  }
									    }
										
										}else{
											System.out.println("cannot find case document with id:: "+eappId);
										}
								//	}
								//}
							} catch (Exception e) {
								System.out.println("Exception while processing eappId:"+eappId);
								e.printStackTrace();
							}
							
						}
					}
				} catch (Exception e) {
					System.out.println("Exception while processing of UPN:"+upn+" with carrierCode:"+carrierCode);
					e.printStackTrace();
				}
				
			}
		}
	}else{
		System.out.println("aborting operation, OIDUPN_Mapper document is empty/null");
	}
	}catch (Exception e) {
		e.printStackTrace();
	}
	finally {
        try {
      writer.flush();
      writer.close();
        } catch (IOException e) {
      e.printStackTrace();
}
}
}
	
	
	private Boolean saveAdvisorCurrenteappId(JSONObject eappData, String currentAdvisorDoc, String eappId) {
		logger.info("saveAdvisorCurrenteappId method() strat ::: ");
		JSONObject currentAdvisorData = null;
		JSONObject masteradvisorObj = new JSONObject();
		Boolean saveFlag = null;
		try {
			currentAdvisorData = getDocument(currentAdvisorDoc);
			if (null != currentAdvisorData) {
				JSONObject inboxMapperObj=(JSONObject) getDocument("InboxParameterMapper").get(safeGet(eappData, "appType"));
				for (Iterator iterator = inboxMapperObj.keySet().iterator(); iterator.hasNext();) {
					String key = (String) iterator.next();
					if (eappData.containsKey(inboxMapperObj.get(key))) {
						masteradvisorObj.put(key, safeGet(eappData,inboxMapperObj.get(key).toString()));
					}else {
//						masteradvisorObj.put(key, inboxMapperObj.get(key));
						masteradvisorObj.put(key, "");
					}
				}
				currentAdvisorData.put(eappId, masteradvisorObj);
				saveFlag = saveDocument(currentAdvisorDoc, currentAdvisorData);
			} else {
				logger.warn("Current Advisor don't have eapp tracking document :::" + currentAdvisorDoc);
			}

		} catch (Exception ex) {
			logger.fatal(
					"IntegrationServiceImpl:::saveAdvisorCurrenteappId::Error occured while saveAdvisorCurrenteappId:: "
							+ ex.getMessage());

		}
		logger.info("saveAdvisorCurrenteappId method()  end ::: ");
		return saveFlag;
	}

	private Boolean deleteEappIdFromDoc(String currentAdvisorDoc, String eappId) {
		logger.info("deleteEappIdFromDoc method() strat ::: ");
		Boolean deleteFlag = null;
		try {
			JSONObject currentAdvisorData = getDocument(currentAdvisorDoc);
			if (null != currentAdvisorData && currentAdvisorData.containsKey(eappId)) {
				currentAdvisorData.remove(eappId);
				deleteFlag = saveDocument(currentAdvisorDoc, currentAdvisorData);
			}

		} catch (Exception ex) {
			logger.fatal("IntegrationServiceImpl:::deleteEappIdFromDoc::Error occured while deleteEappIdFromDoc:: "
					+ ex.getMessage());

		}
		logger.info("deleteEappIdFromDoc method()  end ::: ");
		return deleteFlag;

	}
	
	public void updateReportJson(JSONObject eappData) {

		try {
			 if (safeGet(eappData, "eappId").isEmpty() || !safeGet(eappData, "eappId").startsWith("COOPTrans") ||  !safeGet(eappData, "type").equals("eapp")) {
				 return;
			 }
			JSONObject eappReport = new JSONObject();
			
			boolean isUploadedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Uploaded")?true:false;
			boolean isAdvisoruploaded = safeGet(eappData, "advisorCode").equalsIgnoreCase("Uploaded")?true:false;
			boolean isDeletedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Deleted")?true:false;
			String eappAppType = safeGet(eappData, "appType");
			String eappId = safeGet(eappData, "eappId");
			
			eappReport = getFormattedReport(eappData, eappAppType);
			eappReport.put("Type", "rp");
			saveDocument(eappId.replace("COOPTrans", "Reports"),eappReport);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public JSONObject getFormattedReport(JSONObject eappJSONObject, String appType) {
		boolean isReportSaved = false;
		String resourcePath = null;
		JSONObject reportsMapper = null;
		JSONObject valObj = new JSONObject();
		
		if (null != appType && appType.equals("oldApps")) {
			reportsMapper = getDocument("eappReportsMapper");
		}else if(null != appType && appType.equals("Wealth")) {
			reportsMapper = getDocument("eappReportsMapper_wealth");
		}else{
			reportsMapper = getDocument("eappReportsMapper_life");
		}
	
		if(null != reportsMapper){
			Iterator keys = reportsMapper.keySet().iterator();
			while(keys.hasNext()){
				String key = (String) keys.next();
				valObj.put(key, safeGet(eappJSONObject,reportsMapper.get(key).toString()));
			}
			if(null == valObj.get("carrierCode") || valObj.get("carrierCode").toString().isEmpty()){
				valObj.put("carrierCode","CLIC");
			}
		}else{
			logger.error("Document Not Found:::: eappReportsMapper :::: in CouchBase for appType="+appType);
		}
		return valObj;
		
	}
	
	/*
	 * Method for handling inflight case data 
	 */
	public JSONObject hanldingWealthInflightCasesData(JSONObject caseData) throws ParseException {
		
		if( caseData.containsKey("questTypeOfInvestor")) {
			caseData.put("invesProfileType_header", caseData.get("questTypeOfInvestor"));
		}
		
		if( caseData.containsKey("contract_pension_plans")) {
			caseData.put("appsetupcontractpensionplans", caseData.get("contract_pension_plans"));
		}
		
		if(caseData.containsKey("wealth_product")) {
			caseData.put("appSetupwealthproduct", caseData.get("wealth_product"));
			caseData.put("appSetupwealthproductheader", caseData.get("wealth_product"));
		}		

		
		if(caseData.get("ownerIs")!=null && caseData.get("ownerIs").equals("Other Person")) {
			caseData.put("othperonftfIsthisa", caseData.get("othper_nftfIsthisa"));
			caseData.remove("othper_nftfIsthisa");

			caseData.put("othperonftfIsthisclient", caseData.get("othper_nftfIsthisclient"));
			caseData.remove("othper_nftfIsthisclient");

			caseData.put("othperonftfExisting", caseData.get("othper_nftfExisting"));
			caseData.remove("othper_nftfExisting");	

			caseData.put("othperonftfweask", caseData.get("othper_nftfweask"));
			caseData.remove("othper_nftfweask");
			
			if(caseData.get("othper_nftfProvidetype")!=null && caseData.get("othper_nftfProvidetype").equals("CreditFileMethod")) {
				caseData.put("othperonftfProvidetype","Credit File Method");
				caseData.remove("othper_nftfProvidetype");
			}else if(caseData.get("othper_nftfProvidetype")!=null && caseData.get("othper_nftfProvidetype").equals("DualProcessMethod")){
				caseData.put("othperonftfProvidetype","Dual Process Method");
				caseData.remove("othper_nftfProvidetype");
			}
		}



		if(caseData.get("ownerIs")!=null && caseData.get("ownerIs").equals("Company") && caseData.get("ownerCompanyType") !=null && caseData.get("ownerCompanyType").equals("Sole Proprietor")) {			
			caseData.put("addsoleonftfIsthisa", caseData.get("addsole_nftfIsthisa"));
			caseData.remove("addsole_nftfIsthisa");

			caseData.put("addsoleonftfIsthisclient", caseData.get("addsole_nftfIsthisclient"));
			caseData.remove("addsole_nftfIsthisclient");

			caseData.put("addsoleonftfExisting", caseData.get("addsole_nftfExisting"));
			caseData.remove("addsole_nftfExisting");	
			
			caseData.put("addsoleonftfweask", caseData.get("addsole_nftfweask"));
			caseData.remove("addsole_nftfweask");
			
			if(caseData.get("addsole_nftfProvidetype")!=null && caseData.get("addsole_nftfProvidetype").equals("CreditFileMethod")) {
				caseData.put("addsoleonftfProvidetype","Credit File Method");
				caseData.remove("addsole_nftfProvidetype");
			}else if(caseData.get("addsole_nftfProvidetype")!=null && caseData.get("addsole_nftfProvidetype").equals("DualProcessMethod")) {
				caseData.put("addsoleonftfProvidetype","Dual Process Method");
				caseData.remove("addsole_nftfProvidetype");
			}
		}

		if(caseData.get("ownerIs")!=null && caseData.get("ownerIs").equals("Company") && caseData.get("ownerCompanyType") !=null && caseData.get("ownerCompanyType").equals("Corporation/Entity")) {
			if(caseData.containsKey("AddSigningOfficer0_dataObj")){
				if(caseData.get("AddSigningOfficer0_dataObj") instanceof JSONArray) {
					JSONArray validitionObj=(JSONArray)caseData.get("AddSigningOfficer0_dataObj");
					JSONArray dataObj = new JSONArray();
					for(int i=0; i<validitionObj.size();i++) {
						String retObj =(String) validitionObj.get(i);
						JSONObject obj = (JSONObject) new JSONParser().parse(retObj);
						
						obj.put("addsignonftfIsthisa", obj.get("addsign_nftfIsthisa"));
						obj.remove("addsign_nftfIsthisa");

						obj.put("addsignonftfIsthisclient", obj.get("addsign_nftfIsthisclient"));
						obj.remove("addsign_nftfIsthisclient");

						obj.put("addsignonftfExisting", obj.get("addsign_nftfExisting"));
						obj.remove("addsign_nftfExisting");

						obj.put("addsignonftfweask", obj.get("addsign_nftfweask"));
						obj.remove("addsign_nftfweask");
						
						if(obj.get("addsign_nftfProvidetype")!=null && obj.get("addsign_nftfProvidetype").equals("CreditFileMethod")) {
							obj.put("addsignonftfProvidetype","Credit File Method");
							obj.remove("addsign_nftfProvidetype");
						}else if(obj.get("addsign_nftfProvidetype")!=null && obj.get("addsign_nftfProvidetype").equals("DualProcessMethod")) {
							obj.put("addsignonftfProvidetype","Dual Process Method");
							obj.remove("addsign_nftfProvidetype");
						}
						
						dataObj.add(obj.toString());
					}
					caseData.remove("AddSigningOfficer0_dataObj");
					caseData.put("AddSigningOfficer0_dataObj", dataObj);
				}

			}
		}

		if(caseData.get("ownerIs")!=null && caseData.get("ownerIs").equals("Joint Ownership")) {
			if(caseData.containsKey("AddOtherPerson0_dataObj")){
				if(caseData.get("AddOtherPerson0_dataObj") instanceof JSONArray) {
					JSONArray validitionObj=(JSONArray)caseData.get("AddOtherPerson0_dataObj");
					JSONArray dataObj = new JSONArray();
					for(int i=0; i<validitionObj.size();i++) {
						String retObj =(String) validitionObj.get(i);
						JSONObject obj = (JSONObject) new JSONParser().parse(retObj);
						obj.put("addothperonftfIsthisa", obj.get("addothper_nftfIsthisa"));
						obj.remove("addothper_nftfIsthisa");

						obj.put("addothperonftfIsthisclient", obj.get("addothper_nftfIsthisclient"));
						obj.remove("addothper_nftfIsthisclient");

						obj.put("addothperonftfExisting", obj.get("addothper_nftfExisting"));
						obj.remove("addothper_nftfExisting");

						obj.put("addothperonftfweask", obj.get("addothper_nftfweask"));
						obj.remove("addothper_nftfweask");
						
						if(obj.get("addothper_nftfProvidetype")!=null && obj.get("addothper_nftfProvidetype").equals("CreditFileMethod")) {
							obj.put("addothperonftfProvidetype","Credit File Method");
							obj.remove("addothper_nftfProvidetype");
						}else if(obj.get("addothper_nftfProvidetype")!=null && obj.get("addothper_nftfProvidetype").equals("DualProcessMethod")) {
							obj.put("addothperonftfProvidetype","Dual Process Method");
							obj.remove("addothper_nftfProvidetype");
						}
												
						dataObj.add(obj.toString());
					}
					caseData.remove("AddOtherPerson0_dataObj");
					caseData.put("AddOtherPerson0_dataObj", dataObj);

				}
			}
		}
		
		if(caseData.containsKey("AddCooperatorsPolicyInformation0_dataObj")){
			/*JSONObject errorPopupCountsUid=(JSONObject)caseData.get("ErrorPopupCountsUid");//error count of grid
			JSONObject errorPopupsMapUid=(JSONObject)caseData.get("ErrorPopupsMapUid");//error's details  of gridc
			if(errorPopupCountsUid==null) {
				errorPopupCountsUid=new JSONObject();
			}if(errorPopupsMapUid==null) {
				errorPopupsMapUid=new JSONObject();
			}*/
			JSONObject validatedSectionsInfo=(JSONObject)caseData.get("validatedSectionsInfo");
			if(validatedSectionsInfo==null) {
				validatedSectionsInfo=new JSONObject();
				JSONObject obj=new JSONObject();
				obj.put("isTouched", false);
				validatedSectionsInfo.put("Contribution0",obj);
			}
			
			if(caseData.get("AddCooperatorsPolicyInformation0_dataObj") instanceof JSONArray) {
				JSONArray validitionObj=(JSONArray)caseData.get("AddCooperatorsPolicyInformation0_dataObj");
				JSONArray dataObj = new JSONArray();
				   
				for(int i=0; i<validitionObj.size();i++) {
					String retObj =(String) validitionObj.get(i);
					JSONObject obj = (JSONObject) new JSONParser().parse(retObj);
					JSONArray invalidEles=(JSONArray)obj.get("invalidElements");
					boolean validRecord=(Boolean)obj.get("validRecord");
					String addCooperatorsPolicyInformation0_RID=(String) obj.get("AddCooperatorsPolicyInformation0_RID");
					if(null!=invalidEles && invalidEles.size()== 0 && validRecord) {
					 obj.put("validRecord", false);
					}					
					dataObj.add(obj.toString());
					
				}
				caseData.put("isInflight", true);
				caseData.put("validatedSectionsInfo", validatedSectionsInfo);
				caseData.remove("AddCooperatorsPolicyInformation0_dataObj");
				caseData.put("AddCooperatorsPolicyInformation0_dataObj", dataObj);
			}else {
				System.out.println(":::: AddCooperatorsPolicyInformation0_dataObj  is not an array");
			}
		}else {
			System.out.println(":::: AddCooperatorsPolicyInformation0_dataObj Key is not available in CASEDATA");
		}
		return caseData;
	}
	/**
	 * Enhancements Data Changes For Calling Information Inflight Cases
	 * @throws ParseException
	 */



	public JSONObject updateCallingInformationInflightCases(JSONObject caseDocs) throws  ParseException {

		
		try {
			Integer numberOfLives = Integer.parseInt(safeGet(caseDocs, "GCplaNumbar"));
			
			for (int n = 0; n < numberOfLives; n++) {
				String prefix = "";
				if (n == 0) {
					prefix = "";
				} else {
					prefix = "clone"+n+"_";
				}
				JSONArray callingObj = (JSONArray) caseDocs
						.get(prefix + "AddCallingInformation0_dataObj");
				if(null!=callingObj && callingObj.size()>0) {
					int count=0;
					ArrayList arry=new ArrayList();
					for(int k=0;k<callingObj.size();k++) {
						String phoneObj="";
						JSONObject responseObj = (JSONObject) new JSONParser().parse(callingObj.get(k).toString());
						if((null!=responseObj && !responseObj.isEmpty())) {
							String gcpopCICallat=(null!=responseObj.get("GCpopCICallat") && responseObj.get("GCpopCICallat")!="")?String.valueOf(responseObj.get("GCpopCICallat")):"";
							if(null!=gcpopCICallat && gcpopCICallat.length()>0) {
								arry.add(gcpopCICallat);
								count++;
								if(gcpopCICallat.equalsIgnoreCase("Cell/Mobile")) {
									gcpopCICallat="Mobile";
								}
								phoneObj="phoneNbr"+gcpopCICallat;
							}
							String phoneVal=(null!=responseObj.get("GCpopCIPhone") && responseObj.get("GCpopCIPhone")!="")?String.valueOf(responseObj.get("GCpopCIPhone")):"";
							if(null!=phoneVal && phoneVal.length()>0)
								caseDocs.put(prefix+phoneObj,phoneVal);	
						}
					}
					if(count>1) {
						caseDocs.put(prefix+"persCallPref",arry);	
					}else {
						caseDocs.put(prefix+"persCallPref", arry.get(0));	
					}
					caseDocs.put("ECMModel",new JSONObject());
				}
			}


		} catch (Exception e) {
			e.printStackTrace();
		}
		return caseDocs;
	}

	public void getPreScreenRport(){
		Map<String, String> dateMap = null;
		try {
			dateMap = readDates();
		} catch (Exception e) {
			System.out.println("Exception while reading dates... Please try again with proper dates");
			e.printStackTrace();
		}
		String[] startDate = null;
		String[] endDate = null;
		// JSONArray reportsArray = null;
		boolean resp = false;
		JSONParser parser = new JSONParser();
		FileWriter writer = null;
		
		try {
			
			System.out.println("Please waite Fetching Reports...");

			if (null != dateMap && !dateMap.isEmpty()) {
				startDate = dateMap.get("startDate").split("-");
				endDate = dateMap.get("endDate").split("-");
				if (null != startDate && null != endDate) {
					String folderName = "PreScreenRport";
					String filePath = "." + File.separator + folderName + File.separator + "Rport"+dateMap.get("startDate")+"_to_"+dateMap.get("endDate")+".csv";
					File file = new File(filePath);
					if(!file.getParentFile().exists()){
						file.getParentFile().mkdirs();
					}
					//Remove if clause if you want to overwrite file
					if(!file.exists()){
					    try {
					    	file.createNewFile();
					    } catch (Exception e) {
					        e.printStackTrace();
					    }
					}
					writer = new FileWriter(file);
					//columns in csv file
					writer.append("First Name").append(",")
					.append("Last Name").append(",")
					.append("Policy Number").append(",")
					.append("Financial Advisor Code").append(",")
					.append("Financial Advisor Name").append(",")
					.append("Base Product").append(",")
					.append("Base Plan Type").append(",")
					.append("No of Lives").append(",")
					.append("Eapp Status").append(",")
					.append("App Type").append(",")
					.append("LWTK").append(",")
					.append("Carrier Code").append(",")
					.append("Eapp Id").append(",")
					.append("Created Date").append(",")
					.append("Last Modified Date").append(",")
					.append("Pre-Screen").append(",");
					writer.append("\n");
					
					
					String[] carrierCode = { "CLIC", "CUMIS" };
					for (int i = 0; i < carrierCode.length; i++) {
						System.out.println("Fetching Reports by carrierCode:" + carrierCode[i]);
						try {
							int maxcount = 100000;
							String returnStr = "";
							JSONObject retObj = null;
							JSONObject caseDoc = null;
							returnStr = getEappDataObjectByDate(startDate[0], startDate[1], startDate[2], endDate[0],
									endDate[1], endDate[2], "23", "59", "59", "", carrierCode[i], 1, maxcount);
							if (null != returnStr && !returnStr.isEmpty()) {
								retObj = (JSONObject) parser.parse(returnStr);
								JSONArray retArray = (JSONArray) retObj.get("data");
								System.out.println("found " + retObj.get("totalCount") + " Reports with " + carrierCode[i]);
								if (null != retArray && !retArray.isEmpty()) {
									// reportsArray.add(retArray);
									JSONObject responseObj = null;
									String eappId = "";
									String appType = "";
									String CreatedDate = "";
									for (int j = 0; j < retArray.size(); j++) {
										responseObj = (JSONObject) retArray.get(j);
										appType = safeGet(responseObj,"appType");
										eappId = safeGet(responseObj,"eappId");
										if(appType.equalsIgnoreCase("LIFE")){
											caseDoc = fetchDocument(eappId);
											CreatedDate = "";
											if(caseDoc.containsKey("eappCreatedDate")){
												DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:MM:SS");
												long eappCreatedDate=Long.parseLong(safeGet(caseDoc, "eappCreatedDate"));
												Calendar calendar = Calendar.getInstance();
												calendar.setTimeInMillis(eappCreatedDate);
												CreatedDate=formatter.format(calendar.getTime());
												}
											writer
											.append(safeGet(caseDoc, "lifeCDFNameAppSetup_firstName")).append(",")
									    	.append(safeGet(caseDoc, "lifeCDFNameAppSetup_lastName")).append(",")
									    	.append(safeGet(caseDoc, "ingeniumPolicyNumber")).append(",")
									    	.append(safeGet(caseDoc, "advisorCode")).append(",")
									    	.append(safeGet(caseDoc, "advisor")).append(",")
									    	.append(safeGet(caseDoc, "GCplaBase")).append(",")
									    	.append(safeGet(caseDoc, "GCplaBasePlan")).append(",")
									    	.append(safeGet(caseDoc, "GCplaNumbar")).append(",")
									    	.append(safeGet(caseDoc, "eappStatus")).append(",")
									    	.append(safeGet(caseDoc, "appType")).append(",")
									    	.append(safeGet(caseDoc, "lwtk")).append(",")
									    	.append(safeGet(caseDoc, "carrierCode")).append(",")
									    	.append(safeGet(caseDoc, "eappId")).append(",")
									    	.append(CreatedDate).append(",")
									    	.append(safeGet(caseDoc, "lastModifiedDate")).append(",")
									    	.append(safeGet(caseDoc, "GCplaWould")).append(",");
									    	
									    	
									    	writer.append("\n");
										}
									}
								}
							}
						}catch(Exception e){
							System.out.println();
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
	        try {
	            writer.flush();
	            writer.close();
	        } catch (IOException e) {
	            e.printStackTrace();
            }
		}
							
	}
	
	public JSONObject fetchDocument(String id) {
		JSONObject jsonobject = null;
		try {
			String data = fetch(id);
			if (null != data && !data.isEmpty()) {
				jsonobject = (JSONObject) new JSONParser().parse(data);
			}else{
				data = fetchCaseDataFromDB(id);
				if (null != data && !data.isEmpty()) {
					jsonobject = (JSONObject) new JSONParser().parse(data);
				}
			}

		} catch (Exception e) {
			System.out.println("Exception while getting document for:" + id);
			e.printStackTrace();
		}
		return jsonobject;
	}
	
	public String fetchCaseDataFromDB(String eappId) {
		String caseData = null;
		try {
			String tempId = eappId;
			tempId = tempId.replace("AUDIT_AUDIT_LOG", "").replace("AUDIT_SNAPSHOT", "").replace("eapp_pdf_", "").replace("callbackdata_", "");
			
			List objs = (List)getAbstractDAO().findByCriteria((Class)EappCaseAudit.class,"CASEID = '"+tempId+"'");
				if (objs!=null && objs.size()!=0) {
					EappCaseAudit OldEappCaseAudit =  (EappCaseAudit)objs.get(0);
					if(eappId.endsWith("AUDIT_AUDIT_LOG")){
						caseData = blobToString(OldEappCaseAudit.getAuditdata());
					} else if(eappId.endsWith("AUDIT_SNAPSHOT")){
						caseData = blobToString(OldEappCaseAudit.getSnapShot());
					} else if(eappId.startsWith("eapp_pdf_")){
						caseData = blobToString(OldEappCaseAudit.getPdfData());
					} else if(eappId.startsWith("callbackdata_")){
						caseData = blobToString(OldEappCaseAudit.getCallbackData());
					} else{
						caseData = blobToString(OldEappCaseAudit.getCaseData());
					} 
				}
			
			if(caseData == null || caseData.isEmpty())
				caseData = "";
		} catch (Exception e) {
			System.out.println("Exception in fetchCaseDataFromDB"+ e);
		} 
		return caseData;
	}
	
	public static String blobToString(Blob blob){
		String result = null;
		if(null != blob){
			byte[] bdata;
			try {
				bdata = blob.getBytes(1, (int) blob.length());
				result = new String(bdata);
			} catch (Exception e) {
				System.out.println("problen in converting Blob to String.  Exception:"+ e);
			}
		}
		return result;
	}
	
}

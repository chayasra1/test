package com.couchBase.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.Set;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.eapp.dao.impl.AbstractDAOImpl;
import com.eapp.entity.EappCaseAudit;
import com.eapp.entity.EappReports;
import com.eapp.exception.DataAccessException;
import com.eapp.utility.CoopProperties;
import com.ebix.couchbase.core.contracts.IEbixConnectionManager;
import com.ebix.couchbase.core.contracts.IEbixCouchbaseClient;
import com.ebix.couchbase.core.contracts.IEbixPaginator;
import com.ebix.couchbase.core.contracts.IEbixQuery;
import com.ebix.couchbase.core.contracts.IEbixView;
import com.ebix.couchbase.core.contracts.IEbixViewResponse;
import com.ebix.couchbase.core.contracts.IEbixViewRow;
import com.ebix.couchbase.legacy.EbixConnectionManager;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author VinaykumarE
 *
 */

public class CoopUtility {

	private static final String CONFFILE_PATH = "ebix.configuration.folder";

	String confPath = System.getProperty(CONFFILE_PATH);

	ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");

	private AbstractDAOImpl abstractDAO = (AbstractDAOImpl) context.getBean("abstractDAO");

	private Logger logger = Logger.getLogger(CoopUtility.class);

	static IEbixCouchbaseClient client = null;

	private static final String PDF_DIRECTORY = CoopProperties.getProp("pdf.repository.dir");

	public static void main(String[] args) throws IOException, URISyntaxException {

		IEbixConnectionManager.ref = EbixConnectionManager.init();
		client = EbixConnectionManager.init().instance().getClient();

		int choice = 0;

		CoopUtility moveDocs = new CoopUtility();

		while (choice != 10) {
			System.out.println("\nSelect Options: ");
			System.out.println("1: Move Report documents to oracle");
			System.out.println("2: Move all Case and Report documents to Oracle with Document- RemainingCases");
			System.out.println("3: Move all Uploaded Case and Report documents to Oracle & Delete From Couchbase");
			System.out.println("4: Rename uploaded case folder Names for archiving");
			System.out.println("5: Move Report documents to oracle By Date");
			System.out.println("6: Remove and backup old pakageids in 'eapp_packageId'");
			System.out.println("7: Clean Upload History documents");
			System.out.println("8: Generate Perormance Metrics Report as CSV's");
			System.out.println("9: Delete all transational data ***ONLY IN LOCAL REGION***");
			System.out.println("10: Quit");

			Scanner scan = new Scanner(System.in);
			try {
				choice = Integer.parseInt(scan.nextLine());
			} catch (Exception e) {
				choice = 0;
			}
			switch (choice) {
			case 1:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Move Report documents to oracle - Daily");
				System.out.println("\nPlease wait, Operation in progress...");
				moveDocs.moveReportsToOracle();
				break;

			case 2:
				System.out.println("you selected : " + choice);
				System.out.println(
						"you selected :Move all Case and Report documents to Oracle with Document- RemainingCases");
				moveDocs.moveDataToOracle();
				break;

			case 3:
				System.out.println("you selected : " + choice);
				System.out.println("Move all Uploaded Case and Report documents to Oracle & Delete From Couchbase");
				System.out.println(
						"press 'Y/y' conform delete documents from CouchBase OR press any key to cancel Action:");
				scan = new Scanner(System.in);
				String conformDelete = scan.nextLine();
				if (!conformDelete.equalsIgnoreCase("y")) {
					break;
				}
				moveDocs.moveCasess(true, false, true, true);
				break;

			case 4:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Rename uploaded case folder Names for archiving");
				moveDocs.renameUploadedFolders();
				break;
				
			case 5:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Move Report documents to oracle By Date");
				moveDocs.moveReportsToOracleByDate();
				break;

			case 6:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : 6: Remove and backup old pakageids in 'eapp_packageId'");
				moveDocs.removeAndBackupPackegeIds(); //removeAndBackupPackegeIdsFromView();
				break;
			
			case 7:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : 7: Clean Upload History documents");
				moveDocs.cleanUploadHistory();
				break;
			
			case 8:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : 8: Generate Perormance Metrics Report as CSV's");
				moveDocs.generatePerormanceMetricsReport();
				break;
			
			case 9:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : 9: Delete all transational data");
				moveDocs.deleteAllTransationalData(true);
				break;
				
			case 10:
				System.out.println("press 'Y/y' confirm exit:");
				scan = new Scanner(System.in);
				String conform = scan.nextLine();
				if (!conform.equalsIgnoreCase("y")) {
					choice = 0;
				}
				break;

			default:
				System.out.println("you selected  wrong option: " + choice);
				System.out.println("Please select a proper Option");
				break;
			}

			System.out.println("******Task Completed******");
		}
		client.shutdown();
		System.out.println("********END********");
		System.exit(0);
	}
	/**
	 *  To Clean Upload History documents of all advisors
	 *  Cases uploaded before 6 months to present date/time will be removed from upload doc
	 */
	private void cleanUploadHistory() {
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
		//formatter.setLenient(false);
		Calendar calender = Calendar.getInstance();
		String folderName = "UploadHistory_";
		try {
			folderName = folderName + formatter.format(calender.getTime());
			System.out.println("prasent Date: "+ calender.getTime());
			calender.add(Calendar.MONTH, -6);
			long cutoffDate = calender.getTimeInMillis();
			JSONObject upnOidMapper = getDocument("OIDUPN_Mapper");
			Set set = upnOidMapper.keySet();
			Iterator iterator = set.iterator();
			JSONObject backupObj = new JSONObject();
			String advisor = "";
			boolean isSaved = false;
			
			while(iterator.hasNext()){
				isSaved = false;
				backupObj = new JSONObject();
				advisor = (String) iterator.next();
				//to remove cases with older than cutoffDate of advisor UploadHistory Doc
				backupObj = cleanAdvisorUploadHistory(cutoffDate,advisor);
				if(null != backupObj && !backupObj.isEmpty()){
					//to Save/backup removed entries of UploadHistory Doc
					isSaved = writeToFile(folderName,"UploadHistory_"+advisor+".txt", backupObj.toString());
					System.out.println("Upload History Backup of is "+ (isSaved?"SAVED":"NOT SAVED")+" for advisor :"+advisor);
				}
			}
			
		} catch (Exception e) {
			System.out.println("Exception while cleaning Upload History");
		}
	}
	
	/**
	 * To remove cases dated before the cutoffDays from given advisor UploadHistory document.
	 * Returns removed entries JSONObject
	 * @param cutoffDate
	 * @param advisor
	 * @return
	 */
	private JSONObject cleanAdvisorUploadHistory(long cutoffDate, String advisor) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(cutoffDate);
		JSONObject deletedObj = new JSONObject();
		try {
			JSONObject uploadDoc = getDocument("UploadHistory_"+advisor);
			if(null != uploadDoc && !uploadDoc.isEmpty()){
				Set keys = uploadDoc.keySet();
				if(!keys.isEmpty()){
					Iterator itr = keys.iterator();
					String key = "";
					JSONObject obj = null;
					String plolicy = "";
					long uploadDate = 0;
					while(itr.hasNext()){
						key = (String) itr.next();
						uploadDate = Long.parseLong(key);
						if(uploadDate < cutoffDate){
							obj = (JSONObject) uploadDoc.get(key);
							deletedObj.put(key, obj);
							//uploadDoc.remove(key);
							itr.remove();
						}
					}
				}
				client.set("UploadHistory_"+advisor, uploadDoc.toString());
			}else{
				System.out.println("Upload History Document is EMPTY or NOT FOUNDED for advisor: "+advisor);
			}
		} catch (Exception e) {
			System.out.println("Exception while Cleaning Upload History for advisor:"+advisor+" exception:"+e.getMessage());
		}
		return deletedObj;
	}
	/**
	 * For Removing and backup of old pakageids in 'eapp_packageId' document
	 * NEED: document size increasing as new packages create and we never delete them, so the size always increases.
	 *
	 */
	private void removeAndBackupPackegeIds() {
		JSONObject eappPackageIds = getDocument("eapp_packageId");
		int uploadCnt = 0;
		int deleteCnt = 0;
		if(null != eappPackageIds && !eappPackageIds.isEmpty()){
			String folderName = "moves";
			JSONObject eappIds_upload = null;
			JSONObject eappIds_delete = null;
			String upload_str = readFile(folderName,"uploaded.json");
			String delete_str = readFile(folderName,"deleted.json");
			try{
				eappIds_upload = (JSONObject) new JSONParser().parse(upload_str);
				eappIds_delete = (JSONObject) new JSONParser().parse(delete_str);
			}catch(Exception e){
				e.printStackTrace();
			}
			if(null != eappIds_upload && !eappIds_upload.isEmpty()){
				try {
					JSONObject backup_upload = new JSONObject();
					JSONObject backup_delete = new JSONObject();
					Set set = eappPackageIds.keySet();
					Iterator iterator = set.iterator();
					String packageId = "";
					String eappId = "";
					System.out.println("Removing packageIds Please wait...");
					while(iterator.hasNext()){
						try {
							packageId = (String) iterator.next();
							eappId = (String) eappPackageIds.get(packageId);
							if(!safeGet(eappIds_upload, eappId).isEmpty()){
								backup_upload.put(packageId, eappId);
//								eappPackageIds.remove(packageId);
								iterator.remove();
								uploadCnt++;
							}else if(!safeGet(eappIds_delete, eappId).isEmpty()){
								backup_delete.put(packageId, eappId);
//								eappPackageIds.remove(packageId);
								iterator.remove();
								deleteCnt++;
							}
						} catch (Exception e) {
							System.out.println("Exception while removing eappid "+safeGet(eappIds_upload, packageId));
							e.printStackTrace();
						}
					}
					System.out.println("Removing packageIds completed");
					client.set("eapp_packageId", eappPackageIds.toString());
					client.set("eapp_packageId_upload_backup_09oct18_to_09Nov18", backup_upload.toString());
					client.set("eapp_packageId_delete_backup_09oct18_to_09Nov18", backup_delete.toString());
					System.out.println("new documents saved in couchBase:");
					System.out.println(uploadCnt+" records moved to eapp_packageId_upload_backup_09oct18_to_09Nov18");
					System.out.println(deleteCnt+" records moved to eapp_packageId_delete_backup_09oct18_to_09Nov18");
				} catch (Exception e) {
					System.out.println("Exception in removeAndBackupPackegeIds");
					e.printStackTrace();
				}
			}
		}else{
			System.out.println("Operation failed Document 'eapp_packageId' is missing in couchBase.");
		}
		
	}
	
	/**
	 * For Removing and backup of old pakageids in 'eapp_packageId' document
	 * Automation: gets eappIds from view.
	 */
	private void removeAndBackupPackegeIdsFromView() {
		Map<String, String> dateMap = null;
		try {
			dateMap = readDates();
		} catch (Exception e) {
			System.out.println("Exception while reading dates... Please try again with proper dates");
			e.printStackTrace();
		}
		String[] startDate = null;
		String[] endtDate = null;
		// JSONArray reportsArray = null;
		JSONParser parser = new JSONParser();
		boolean isRenamed = false;
		JSONObject eappIds_upload = new JSONObject();
		JSONObject eappIds_delete = new JSONObject();
		

		System.out.println("Please wait Fetching Reports...");

		try {
			if (null != dateMap && !dateMap.isEmpty()) {
				startDate = dateMap.get("startDate").split("-");
				endtDate = dateMap.get("endDate").split("-");
				if (null != startDate && null != endtDate) {
					String[] carrierCode = { "CLIC", "CUMIS" };
					for (int i = 0; i < carrierCode.length; i++) {
						try {
							int maxcount = 100000;
							String returnStr = "";
							JSONObject retObj = null;
							returnStr = getEappDataObjectByDate(startDate[0], startDate[1], startDate[2], endtDate[0],
									endtDate[1], endtDate[2], "23", "59", "59", "", carrierCode[i], 1, maxcount);
							if (null != returnStr && !returnStr.isEmpty()) {
								retObj = (JSONObject) parser.parse(returnStr);
								JSONArray retArray = (JSONArray) retObj.get("data");
								System.out.println("found " + retObj.get("totalCount") + " Reports with " + carrierCode[i]);
								if (null != retArray && !retArray.isEmpty()) {
									// reportsArray.add(retArray);
									JSONObject responseObj = null;
									String eappId = "";
									String status = "";
									for (int j = 0; j < retArray.size(); j++) {
										responseObj = (JSONObject) retArray.get(j);
										eappId = (String) responseObj.get("eappId");
										status = (String) responseObj.get("status");
										if (null != status && status.equalsIgnoreCase("Uploaded")) {
											eappIds_upload.put(eappId, eappId);
										}else if (null != status && status.equalsIgnoreCase("Deleted")) {
											eappIds_delete.put(eappId, eappId);
										}
									}

								}
							}

							System.out.println("completed Fetching Reports by carrierCode:" + carrierCode[i]);
						} catch (Exception e) {
							System.out.println("Exception while Fetching Reports by carrierCode:" + carrierCode[i]);
							e.printStackTrace();
						}
					}
					System.out.println("completed Fetching Reports");
				}
			}
		} catch (Exception e1) {
			System.out.println("Exception while getting uploaded and deleted Eappids.");
		}
		
		try {
			JSONObject eappPackageIds = getDocument("eapp_packageId");
			DateFormat formatCouch = new SimpleDateFormat("dd/MM/yyyy");
			String presentTime = formatCouch.format(new Date());
			//to backup
			client.set("eapp_packageId_"+presentTime, eappPackageIds.toString());
			System.out.println("eapp_packageId backup document saved with name 'eapp_packageId_"+presentTime+"'");
			
			if(null != eappPackageIds && !eappPackageIds.isEmpty()){
				if((null != eappIds_upload && !eappIds_upload.isEmpty()) || (null != eappIds_delete && !eappIds_delete.isEmpty())){
					try {
						JSONObject backup_upload = new JSONObject();
						JSONObject backup_delete = new JSONObject();
						Set set = eappPackageIds.keySet();
						Iterator iterator = set.iterator();
						String packageId = "";
						String eappId = "";
						System.out.println("Removing packageIds Please wait...");
						while(iterator.hasNext()){
							try {
								packageId = (String) iterator.next();
								eappId = (String) eappPackageIds.get(packageId);
								if(null != eappIds_upload && eappIds_upload.containsKey(eappId)){
									backup_upload.put(packageId, eappId);
//								eappPackageIds.remove(packageId);
									iterator.remove();
								}else if(null != eappIds_delete && eappIds_delete.containsKey(eappId)){
									backup_delete.put(packageId, eappId);
//								eappPackageIds.remove(packageId);
									iterator.remove();
								}
							} catch (Exception e) {
								System.out.println("Exception while removing eappid "+safeGet(eappIds_upload, packageId));
								e.printStackTrace();
							}
						}
						System.out.println("Removing packageIds completed");
						client.set("eapp_packageId", eappPackageIds.toString());
						client.set("eapp_packageId_upload_backup"+dateMap.get("startDate")+"_to_"+dateMap.get("endDate"), backup_upload.toString());
						client.set("eapp_packageId_delete_backup"+dateMap.get("startDate")+"_to_"+dateMap.get("endDate"), backup_delete.toString());
						System.out.println("new documents saved in couchBase with Names:");
						System.out.println("eapp_packageId_upload_backup"+dateMap.get("startDate")+"_to_"+dateMap.get("endDate"));
						System.out.println("eapp_packageId_delete_backup"+dateMap.get("startDate")+"_to_"+dateMap.get("endDate"));
					} catch (Exception e) {
						System.out.println("Exception in removeAndBackupPackegeIds");
						e.printStackTrace();
					}
				}else{
					System.out.println("aborting operation ad no Uploaded/Deleted eappIds are present");
				}
			}else{
				System.out.println("Oration failed Document 'eapp_packageId' is missing in couchBase.");
			}
		} catch (Exception e) {
			System.out.println("Exception while removing uploaded/deleted packegeIds from 'eapp_packageId' document");
		}
		
	}

	/**
	 * Returns json object with date value String with format dd-mm-yyyy (NOTE:
	 * ignores leading 0's as view's will fail to run with leading zeros) values
	 * startDate, endDate
	 */
	public Map<String, String> readDates() {
		Scanner scan = new Scanner(System.in);
		Map<String, String> dateObj = new java.util.HashMap<String, String>();
		String readVal = "";
		boolean invalidDate = true;
		Date date = null;
		String[] dateVals = { "startDate", "endDate" };

		try {
			for (int i = 0; i < dateVals.length; i++) {
				invalidDate = true;
				date = null;
				while (invalidDate) {
					System.out.println("Please enter " + dateVals[i] + "(dd-mm-yyyy):");
					readVal = scan.nextLine();
					readVal = readVal.replaceAll("-0", "-").replaceAll("^0*", "");
					if (null != readVal && !readVal.isEmpty()) {
						date = validateDateFormat(readVal);
						if (null != date) {
							dateObj.put(dateVals[i], readVal);
							invalidDate = false;
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Exception in readDates");
			e.printStackTrace();
		}
		return dateObj;
	}

	public Date validateDateFormat(String dateToValdate) {

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		// To make strict date format validation
		formatter.setLenient(false);
		Date parsedDate = null;
		try {
			parsedDate = formatter.parse(dateToValdate);
			System.out.println("validated DATE TIME :" + dateToValdate);

		} catch (java.text.ParseException e) {
			System.out.println("you have entered wrong date");
		}
		return parsedDate;
	}

	public void renameUploadedFolders() {

		Map<String, String> dateMap = null;
		try {
			dateMap = readDates();
		} catch (Exception e) {
			System.out.println("Exception while reading dates... Please try again with proper dates");
			e.printStackTrace();
		}
		String[] startDate = null;
		String[] endtDate = null;
		// JSONArray reportsArray = null;
		JSONParser parser = new JSONParser();
		boolean isRenamed = false;

		System.out.println("Please wait Fetching Reports...");

		if (null != dateMap && !dateMap.isEmpty()) {
			startDate = dateMap.get("startDate").split("-");
			endtDate = dateMap.get("endDate").split("-");
			if (null != startDate && null != endtDate) {
				String[] carrierCode = { "CLIC", "CUMIS" };
				for (int i = 0; i < carrierCode.length; i++) {
					try {
						int maxcount = 100000;
						String returnStr = "";
						JSONObject retObj = null;
						returnStr = getEappDataObjectByDate(startDate[0], startDate[1], startDate[2], endtDate[0],
								endtDate[1], endtDate[2], "23", "59", "59", "", carrierCode[i], 1, maxcount);
						if (null != returnStr && !returnStr.isEmpty()) {
							retObj = (JSONObject) parser.parse(returnStr);
							JSONArray retArray = (JSONArray) retObj.get("data");
							System.out.println("found " + retObj.get("totalCount") + " Reports with " + carrierCode[i]);
							if (null != retArray && !retArray.isEmpty()) {
								// reportsArray.add(retArray);
								JSONObject responseObj = null;
								String eappId = "";
								String status = "";
								for (int j = 0; j < retArray.size(); j++) {
									responseObj = (JSONObject) retArray.get(j);
									eappId = (String) responseObj.get("eappId");
									status = (String) responseObj.get("status");
									if (null != status && status.equalsIgnoreCase("Uploaded")) {
										isRenamed = renameFiles(eappId);
										System.out.println(eappId + " : " + isRenamed);
									}
								}

							}
						}

						System.out.println("completed Fetching Reports by carrierCode:" + carrierCode[i]);
					} catch (Exception e) {
						System.out.println("Exception while Fetching Reports by carrierCode:" + carrierCode[i]);
						e.printStackTrace();
					}
				}
				System.out.println("completed Fetching Reports");
			}
		}
	}

	public boolean renameFiles(String folderName) {
		boolean renamed = false;
		String uploadFolder = PDF_DIRECTORY;
		String renameFolder = null;

		try {

			renameFolder = uploadFolder + File.separator + folderName;
			logger.info("Renaming  Folder Path " + renameFolder);
			File dir = new File(renameFolder);
			if (null != dir) {
				File newDir = new File(dir.getParent() + File.separator + "uploaded_" + folderName);
				renamed = dir.renameTo(newDir);
			}

			if (renamed)
				logger.info("Renaming completed Successfully for Folder " + renameFolder);
			else
				logger.info("Renaming Failed for Folder " + renameFolder);
		} catch (Exception e) {
			System.out.println("Exception renameFiles");
		}
		return renamed;
	}

	public String readFile(String folder, String name) {
		String fileData = null;
		try {
			System.out.println("Reading file:" + name + " in folder" + folder);
			FileInputStream fin = null;
			BufferedReader reader = null;
			fin = new FileInputStream("." + File.separator + folder + File.separator + name);

			if (fin != null) {
				reader = new BufferedReader(new InputStreamReader(fin));
			}
			StringBuilder sb = new StringBuilder();
			String line = "";
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			fileData = sb.toString();
			reader.close();
			System.out.println("Reading completed.");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		return fileData;
	}
	
	public String readFileFromPath(String fileName) {
		String fileData = null;
		try {
			System.out.println("Reading file:");
			FileInputStream fin = null;
			BufferedReader reader = null;
			fin = new FileInputStream(fileName);

			if (fin != null) {
				reader = new BufferedReader(new InputStreamReader(fin));
			}
			StringBuilder sb = new StringBuilder();
			String line = "";
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			fileData = sb.toString();
			reader.close();
			System.out.println("Reading completed.");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		return fileData;
	}
	
	public boolean writeToFile(String folderName,String fileName, String data){
		boolean result = false;
		if(null == folderName || folderName.isEmpty()){
			folderName = "created";
		}
		String filePath = "." + File.separator + folderName + File.separator + fileName;
		File file = new File(filePath);
	    if(!file.getParentFile().exists()){
	    	file.getParentFile().mkdirs();
	    }
	    //Remove if clause if you want to overwrite file
	    if(!file.exists()){
	        try {
	        	file.createNewFile();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
		Writer writer = null;

		try {
		    writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filePath), "utf-8"));
		    System.out.println("Info  : Document Created" + fileName);
			if (data!=null) {
				writer.write(data);
				result = true;
			}
		} catch (IOException ex) {
			System.out.println("Exception : " + ex.getMessage());
			ex.printStackTrace();
		} finally {
		   try {writer.close();} catch (Exception ex) {
			   System.out.println("Exception : " + ex.getMessage());
				ex.printStackTrace();
			}
		}
		return result;
	}

	public void moveDataToOracle() {

		JSONObject repDoc = null;
		String appType = "life";
		JSONObject remainigCases = getDocument("RemainingCases");
		// query.setLimit(100);
		int docsPerPage = 200;
		try {
			if (remainigCases != null && remainigCases.isEmpty()) {
				String listStr = safeGet(remainigCases, "data");
				if (!listStr.isEmpty()) {
					JSONArray changesList = null;
					try {
						changesList = (JSONArray) new JSONParser().parse(listStr);
					} catch (Exception e) {
						System.out.println("Exception while parcing data array in AgentsChangesDoc");
						e.printStackTrace();
					}

					if (null != changesList && !changesList.isEmpty()) {
						String docName = "";
						JSONObject caseData = null;
						for (int i = 0; i < changesList.size(); i++) {
							try {
								docName = (String) changesList.get(i);
								if (null != docName && !docName.isEmpty()) {
									caseData = getDocument(docName);
									if (null != caseData && !caseData.isEmpty()) {
										boolean isCasemoved = false;
										String eapp_Status = safeGet(caseData, "eappStatus");
										appType = safeGet(caseData, "appType");
										if (eapp_Status.equals("Deleted")) {
											// Moving Deleted Cases Case Data to
											// oracle
											repDoc = getFormattedReportFromCaseData(getDocument(docName), appType);
											repDoc = getTableFormattedReportFromReportData(repDoc);
											isCasemoved = moveCaseAudiToDB(docName, true);
										} else {
											isCasemoved = moveCaseAudiToDB(docName, false);
										}
										System.out.println(docName + " isMoved:" + isCasemoved);
										boolean ismoved = saveReports(docName, repDoc);
										if (ismoved) {
											client.delete(docName.replace("COOPTrans", "Reports"));
										}
									}
								}
								if (docsPerPage != 0) {
									docsPerPage = docsPerPage - 1;
								} else {
									try {
										Thread.sleep(2000);
										docsPerPage = 200;
									} catch (InterruptedException ex) {
										Thread.currentThread().interrupt();
									}
								}
							} catch (Exception e) {
								System.out.println("Exception while processing document of:" + docName);
								e.printStackTrace();
							}
						}
					}

				} else {
					System.out.println("Cannot Find data array AgentsChangesDoc");
				}
			}

		} catch (Exception e) {
			System.out.println("Exception in moveDataToOracle");
			e.printStackTrace();
		}

	}

	/**
	 * move reports docs to oracle db and clean up
	 * 
	 */
	public void moveReportsToOracle() {
		JSONObject repDoc = null;
		JSONObject formatedrepDoc = null;
		String appType = "life";
		int pcnt = 0;
		String eappId = null;
		IEbixView view = client.getView_("advisor", "by_dateForAudit1");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);
		int docsPerPage = 100;
		try {
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
			while (pages.hasNext()) {
				System.out.println("Please Waite.. Processing Page:" + pcnt++);
				IEbixViewResponse response = pages.next();
				try {
					for (IEbixViewRow row : response) {
						String eid = row.getId();
						try {
							System.out.println("Report Id -" + eid);
							repDoc = getDocument(eid);
							String eapp_Status = safeGet(repDoc, "ST");
							eappId = safeGet(repDoc, "EID");
							if (eapp_Status.equals("Deleted")) {
								// Moving Deleted Cases Case Data to oracle
								JSONObject eappCaseData = getDocument(eappId);
								appType = safeGet(eappCaseData, "appType");
								if (!appType.equalsIgnoreCase("wealth")) {
									appType = "life";
								}
								boolean ismoved = moveCaseAudiToDB(eappId, true);
								System.out.println(eappId + " isMoved:" + ismoved);
							}
							if (repDoc != null && !repDoc.isEmpty()) {
								formatedrepDoc = getTableFormattedReportFromReportData(repDoc);
								boolean ismoved = saveReports(eappId, formatedrepDoc);
								if (ismoved) {
									client.delete(eid);
								}
							}
						} catch (Exception e) {
							System.out.println("Exception while processing:" + eid + " in moveReportsToOracle");
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					System.out.println("Exception while iterating view in moveReportsToOracle");
					e.printStackTrace();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
			}

		} catch (Exception e) {
			System.out.println("Exception in moveReportsToOracle");
			e.printStackTrace();
		}

	}

	/**
	 * 
	 */
	public void updateOldReportDocuments() {

		JSONObject eappData = new JSONObject();
		JSONObject repDoc = new JSONObject();
		String appType = "life";
		int pcnt = 0;
		IEbixView view = client.getView_("advisor", "by_ApplicationType");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);
		int docsPerPage = 50;
		try {
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
			while (pages.hasNext()) {
				System.out.println("Please Waite.. Processing Page:" + pcnt++);
				IEbixViewResponse response = pages.next();
				try {
					for (IEbixViewRow row : response) {
						String eid = row.getId();
						try {
							if (null != eid && !eid.isEmpty() && eid.startsWith("COOPTrans-")) {
								eappData = getDocument(eid);
								appType = safeGet(eappData, "appType");
								if (!appType.equalsIgnoreCase("wealth")) {
									appType = "life";
								}
								repDoc = getFormattedReportFromCaseData(eappData, appType);
								client.set(eid.replace("COOPTrans", "Reports"), repDoc.toString());
							}
						} catch (Exception e) {
							System.out.println("Exception while processing:" + eid + " in updateOldReportDocuments");
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					System.out.println("Exception while iterating view in updateOldReportDocuments");
					e.printStackTrace();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
			}

		} catch (Exception e) {
			System.out.println("Exception in updateOldReportDocuments");
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * @param moveCasess
	 * @param moveAllCasess
	 * @param moveAllReports
	 * @param deleteDocs
	 */
	public void moveCasess(boolean moveCasess, boolean moveAllCasess, boolean moveAllReports, boolean deleteDocs) {

		JSONObject eappData = new JSONObject();
		JSONObject repDoc = new JSONObject();
		JSONObject formattedRepDoc = new JSONObject();
		boolean isUploadedCase = false;
		boolean isAdvisoruploaded = false;
		boolean isDeletedCase = false;
		String appType = "life";

		int pcnt = 0;
		IEbixView view = client.getView_("advisor", "by_ApplicationType");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);

		int docsPerPage = 50;
		IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
		while (pages.hasNext()) {
			System.out.println("Please Waite.. Processing Page:" + pcnt++);
			IEbixViewResponse response = pages.next();
			for (IEbixViewRow row : response) {
				String eid = row.getId();
				try {
					if (null != eid && !eid.isEmpty() && eid.startsWith("COOPTrans-")) {
						eappData = getDocument(eid);
						isUploadedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Uploaded") ? true : false;
						isAdvisoruploaded = safeGet(eappData, "advisorCode").equalsIgnoreCase("Uploaded") ? true
								: false;
						isDeletedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Deleted") ? true : false;
						if (moveCasess && moveAllCasess || (isDeletedCase || (isUploadedCase && isAdvisoruploaded))) {
							boolean ismoved = moveCaseAudiToDB(eid, deleteDocs);
							System.out.println(eid + " isMoved:" + ismoved);
						}
						if (moveAllReports || ((isDeletedCase || (isUploadedCase && isAdvisoruploaded)))) {
							appType = safeGet(eappData, "appType");
							if (!appType.equalsIgnoreCase("wealth")) {
								appType = "life";
							}
							repDoc = getFormattedReportFromCaseData(eappData, appType);
							formattedRepDoc = getTableFormattedReportFromReportData(repDoc);
							boolean ismoved = saveReports(eid, formattedRepDoc);
							if (ismoved) {
								client.delete(eid.replace("COOPTrans", "Reports"));
							}
							System.out.println(eid.replace("COOPTrans", "Reports") + " isMoved:" + ismoved);
						}
					}
				} catch (Exception e) {
					System.out.println("Exception while processing:" + eid + " in moveCasess");
					e.printStackTrace();
				}
			}

			try {
				Thread.sleep(2000);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}
	
	public void deleteAllTransationalData(boolean deleteDocs) {

		JSONObject eappData = new JSONObject();
		JSONObject repDoc = new JSONObject();
		JSONObject formattedRepDoc = new JSONObject();
		String appType = "life";
		
		if(deleteDocs){
			System.out.println("press 'Y/y' for DELETE confirm :");
			Scanner scan = new Scanner(System.in);
			String conform = scan.nextLine();
			if (!conform.equalsIgnoreCase("y")) {
				System.out.println("Abourting operation...");
				return;
			}
		}else{
			System.out.println("Abourting operation...");
			return;
		}
		System.out.println("Delete operation starting...");
		
		int pcnt = 0;
		//IEbixView view = client.getView_("advisor", "by_ApplicationType");
		//IEbixView view = client.getView_("fadCode ", "by_FadCode");
		IEbixView view = client.getView_("appDocs", "by_docId");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);
		
		List<String> agentLst = new ArrayList<String>();
		agentLst.add("Agent_Data_Janes");
		agentLst.add("Agent_Data_Yarkle");
		agentLst.add("Agent_Data_Kerry");
		agentLst.add("Agent_Data_Smith");
		agentLst.add("Agent_Data_CumisTest");
		agentLst.add("Agent_Data_CumisTestfr");
		agentLst.add("Agent_Data_cumistest");
		agentLst.add("Agent_Data_cumistestfr");

		int docsPerPage = 100;
		IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
		while (pages.hasNext()) {
			System.out.println("Please Waite.. Processing Page:" + pcnt++);
			IEbixViewResponse response = pages.next();
			for (IEbixViewRow row : response) {
				String eappId = row.getId();
				try {
					if (null != eappId && !eappId.isEmpty() && eappId.startsWith("COOPTrans-")) {
						//eappData = (JSONObject) row.getDocument();
						//eappData = getDocument(eappId);
						client.delete(eappId);
						client.delete("eapp_pdf_" + eappId);
						client.delete(eappId.replace("COOPTrans", "Reports"));
						client.delete("callbackdata_" + eappId);
						client.delete(eappId + "AUDIT_SNAPSHOT");
						client.delete(eappId + "AUDIT_AUDIT_LOG");
						//if (eappData != null) {
						//	appType = String.valueOf(eappData.get("appType"));
						//	String noOfClients = safeGet(eappData,"GCplaNumbar");
							int cnt = 5;	//Integer.parseInt(noOfClients);
						/*	if (appType != null && appType.equalsIgnoreCase("wealth")) {
								client.delete(eappId + "_AAR_Client_" + 1);
							} else {
						*/		for (int i = 1; i <= cnt; i++) {
									client.delete(eappId + "_AAR_Client_" + i);
								}
						//	}
						//}
						System.out.println("Deleted all related documents of EappId:" + eappId);
					}else if(null != eappId && !eappId.isEmpty() && eappId.startsWith("Agent_Data_")){
						int ind = agentLst.lastIndexOf(eappId);
						if(ind == -1){
							client.delete(eappId);
							System.out.println("Deleted AgentData document of:" + eappId);
						}
					}else if(null != eappId && !eappId.isEmpty() && (eappId.startsWith("Reports-") || eappId.contains("COOPTrans-"))){
						client.delete(eappId);
						System.out.println("Deleted document with id:" + eappId);
					}
				} catch (Exception e) {
					System.out.println("Exception while deleting:" + eappId );
					e.printStackTrace();
				}
			}

			try {
				Thread.sleep(2000);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}
	
	public boolean isTransationalRelatedDoc(String id){
		boolean transDoc = false;
		if(id.startsWith("COOPTrans-") || id.startsWith("COOPTrans-") || id.startsWith("COOPTrans-") || id.startsWith("COOPTrans-") || id.startsWith("COOPTrans-") || id.startsWith("COOPTrans-")){
			
		}
		return transDoc;
	}

	public boolean moveCaseAudiToDB(String eappId, boolean needToDeleteOracleMovedDocs) {
		boolean deleteDocs = false;
		if (null != eappId && !eappId.isEmpty()) {
			try {
				List objs = (List) getAbstractDAO().findByCriteria(EappCaseAudit.class, "CASEID = '" + eappId + "'");
				if (objs != null && objs.size() != 0) {
					EappCaseAudit OldEappCaseData = (EappCaseAudit) objs.get(0);
					OldEappCaseData = bindEappCaseAudit(eappId, OldEappCaseData);
					try {
						getAbstractDAO().update(OldEappCaseData);
						deleteDocs = true;
					} catch (Exception e) {
						deleteDocs = false;
						System.out.println(
								"Record not Updated ::: Exception while updating record with eappId:" + eappId);
						e.printStackTrace();
					}
				} else {
					EappCaseAudit OldEappCaseData = new EappCaseAudit();
					OldEappCaseData = bindEappCaseAudit(eappId, OldEappCaseData);
					try {
						getAbstractDAO().save(OldEappCaseData);
						deleteDocs = true;
					} catch (Exception e) {
						deleteDocs = false;
						System.out
								.println("Record not Saved ::: Exception while updating record with eappId:" + eappId);
						e.printStackTrace();
					}
				}

			} catch (DataAccessException e) {
				e.printStackTrace();
			} catch (Exception e) {
				System.out.println("Exception in moveCaseAudiToDB while processing :" + eappId);
				e.printStackTrace();
			}
		}

		if (!eappId.startsWith("Agent_Data_") && deleteDocs && needToDeleteOracleMovedDocs) {
			client.delete(eappId);
			client.delete(eappId + "AUDIT_AUDIT_LOG");
			client.delete(eappId + "AUDIT_SNAPSHOT");
			client.delete("eapp_pdf_" + eappId);
		}

		return deleteDocs;
	}

	public boolean saveReports(String eappId, JSONObject eappJSONObject) {
		boolean isReportSaved = false;
		try {
			List objs = (List) getAbstractDAO().findByCriteria(EappReports.class, "EAPPID = '" + eappId + "'");
			if (objs != null && objs.size() != 0) {
				EappReports OldEappReports = (EappReports) objs.get(0);
				Long id = OldEappReports.getId();
				OldEappReports = prepareEappReportsFromJson(OldEappReports, eappJSONObject);
				OldEappReports.setId(id);
				getAbstractDAO().update(OldEappReports);
				isReportSaved = true;
			} else {
				EappReports OldEappRepoers = new EappReports();
				OldEappRepoers = prepareEappReportsFromJson(OldEappRepoers, eappJSONObject);
				getAbstractDAO().save(OldEappRepoers);
				isReportSaved = true;
			}

		} catch (Exception e) {
			System.out.println("Report not saved for EappId:" + eappId + " :::Exception in saveReports: " + e);
			isReportSaved = false;
			e.printStackTrace();
		}
		return isReportSaved;

	}

	private EappCaseAudit bindEappCaseAudit(String eappId, EappCaseAudit OldEappCaseData) throws DataAccessException {
		// getting data from couchbase.
		String caseData = fetch(eappId);
		String auditLog = fetch(eappId + "AUDIT_AUDIT_LOG");
		String snapShort = fetch(eappId + "AUDIT_SNAPSHOT");
		String pdfData = fetch("eapp_pdf_" + eappId);

		Blob caseBlob = convertToBlob(caseData);
		Blob auditBlob = convertToBlob(auditLog);
		Blob snapShortBlob = convertToBlob(snapShort);
		Blob pdfDataBlob = convertToBlob(pdfData);

		OldEappCaseData.setCaseid(eappId);
		if (null != caseBlob) {
			OldEappCaseData.setCaseData(caseBlob);
		}
		if (null != auditBlob) {
			OldEappCaseData.setAuditdata(auditBlob);
		}
		if (null != snapShortBlob) {
			OldEappCaseData.setSnapShot(snapShortBlob);
		}
		if (null != pdfDataBlob) {
			OldEappCaseData.setPdfData(pdfDataBlob);
		}

		if (eappId.startsWith("COOPTrans-") && null != caseData && !caseData.isEmpty()) {
			JSONObject formated_Json_eappDoc = null;
			String carrierCode = null;
			String appType = null;
			try {
				formated_Json_eappDoc = (JSONObject) new JSONParser().parse(caseData);
				carrierCode = (String) formated_Json_eappDoc.get("carrierCode");
				appType = (String) formated_Json_eappDoc.get("appType");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			OldEappCaseData.setAppType(appType);
			if (null != carrierCode && carrierCode.equalsIgnoreCase("CUMIS")) {
				OldEappCaseData.setType("CUMIS");
			} else {
				OldEappCaseData.setType("CLIC");
			}
		} else if (eappId.startsWith("D2CTransId-")) {
			OldEappCaseData.setType("D2C");
		} else if (eappId.startsWith("Agent_Data_")) {
			OldEappCaseData.setType("AGENT");
		}

		return OldEappCaseData;
	}

	private Blob convertToBlob(String data) {
		Blob blob = null;
		if (null != data && !data.isEmpty()) {
			byte[] buff = data.getBytes();
			try {
				blob = new SerialBlob(buff);
			} catch (SerialException e) {
				System.out.println("Exception in converting to Blob ::: " + e);
				e.printStackTrace();
			} catch (SQLException e) {
				System.out.println("Exception in converting to Blob ::: " + e);
				e.printStackTrace();
			}
		}
		return blob;
	}

	private String fetch(String eappId) {
		String val = (String) client.get(eappId);
		return null != val ? val : "";
	}

	public JSONObject getDocument(String id) {
		JSONObject jsonobject = null;
		try {
			String data = fetch(id);
			if (null != data && !data.isEmpty()) {
				jsonobject = (JSONObject) new JSONParser().parse(data);
			}

		} catch (Exception e) {
			System.out.println("Exception while getting document for:" + id);
			e.printStackTrace();
		}
		return jsonobject;
	}
	private void saveJson(String eappId, JSONObject doc) {
		client.set(eappId, doc.toString());
	}
	
	private void saveString(String eappId, String doc) {
		client.set(eappId, doc);
	}

	private String safeGet(JSONObject jso, String prop) {
		Object propobj = null;
		try {
			propobj = jso.get(prop);
		} catch (Exception exprop) {
		}
		return propobj == null ? "" : propobj.toString();
	}

	private void createMapperDocuments() {
		String mapperDoc = "{\"eappId\":\"EID\",\"policy\":\"No\",\"advisor\":\"A\",\"appType\":\"App\",\"modifiedDate\":\"date\",\"advisorCode\":\"AC\",\"sign\":\"sign\",\"carrierCode\":\"CC\",\"firstName\":\"FN\",\"lastName\":\"LN\",\"status\":\"ST\",\"product\":\"PR\",\"plan\":\"plan\",\"lives\":\"lives\",\"lwtk\":\"lwtk\",\"lastModifiedDate\":\"LMD\",\"deletedBy\":\"DB\",\"deletedDate\":\"DD\"}";
		String mapperDoc_life = "{\"EID\":\"eappId\",\"No\":\"ingeniumPolicyNumber\",\"A\":\"advisor\",\"App\":\"appType\",\"date\":\"dateMillis\",\"AC\":\"advisorCode\",\"sign\":\"SignType\",\"CC\":\"carrierCode\",\"FN\":\"GCCDFName_firstName\",\"LN\":\"GCCDFName_lastName\",\"ST\":\"eappStatus\",\"PR\":\"GCplaBase\",\"plan\":\"GCplaBasePlan\",\"lives\":\"GCplaNumbar\",\"lwtk\":\"lwtk\",\"LMD\":\"lastModifiedDate\",\"DB\":\"Deleted_By\",\"DD\":\"Deleted_date\",\"column_1\":\"\"}";
		String mapperDoc_welth = "{\"EID\":\"eappId\",\"No\":\"ingeniumPolicyNumber\",\"A\":\"advisor\",\"App\":\"appType\",\"date\":\"dateMillis\",\"AC\":\"advisorCode\",\"sign\":\"SignType\",\"CC\":\"carrierCode\",\"FN\":\"annPIName_firstName\",\"LN\":\"annPIName_lastName\",\"ST\":\"eappStatus\",\"PR\":\"wealth_product\",\"plan\":\"\",\"lives\":\"\",\"lwtk\":\"lwtk\",\"LMD\":\"lastModifiedDate\",\"DB\":\"Deleted_By\",\"DD\":\"Deleted_date\",\"column_1\":\"\"}";

		client.set("eappReportsMapper", mapperDoc);
		client.set("eappReportsMapper_life", mapperDoc_life);
		client.set("eappReportsMapper_wealth", mapperDoc_welth);
	}

	public JSONObject getFormattedReportFromCaseData(JSONObject eappJSONObject, String appType) {
		JSONObject valObj = new JSONObject();
		try {
			JSONObject reportsMapper = null;

			if (null != appType && appType.equals("Wealth")) {
				reportsMapper = getMapperDocument("eappReportsMapper_wealth");
			} else {
				reportsMapper = getMapperDocument("eappReportsMapper_life");
			}
			if (null != reportsMapper) {
				Iterator keys = reportsMapper.keySet().iterator();
				while (keys.hasNext()) {
					String key = (String) keys.next();
					valObj.put(key, eappJSONObject.get(reportsMapper.get(key)));
				}
				if (null == valObj.get("carrierCode") || valObj.get("carrierCode").toString().isEmpty()) {
					valObj.put("carrierCode", "CLIC");
				}
			} else {
				System.out.println("Document Not Found:::: eappReportsMapper :::: in CouchBase for appType=" + appType);
			}
			return valObj;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	public JSONObject getTableFormattedReportFromReportData(JSONObject eappJSONObject) {
		JSONObject valObj = new JSONObject();
		try {
			JSONObject reportsMapper = null;

			reportsMapper = getMapperDocument("eappReportsMapper");

			if (null != reportsMapper && !reportsMapper.isEmpty()) {
				Iterator keys = reportsMapper.keySet().iterator();
				while (keys.hasNext()) {
					String key = (String) keys.next();
					valObj.put(key, eappJSONObject.get(reportsMapper.get(key)));
				}
				if (null == valObj.get("carrierCode") || valObj.get("carrierCode").toString().isEmpty()) {
					valObj.put("carrierCode", "CLIC");
				}
			} else {
				System.out.println("Document :::: eappReportsMapper :::: Not Found in CouchBase");
			}
			return valObj;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	private EappReports prepareEappReportsFromJson(EappReports oldEappRepoers, JSONObject eappJSONObject) {
		ObjectMapper mapper = new ObjectMapper();

		try {
			oldEappRepoers = mapper.readValue(eappJSONObject.toJSONString(), EappReports.class);
		} catch (IOException e) {
			System.out.println("Error while parsing json to EappReports object :::: " + e.getMessage());
			e.printStackTrace();
		}

		return oldEappRepoers;
	}

	public JSONObject getMapperDocument(String id) {
		JSONObject obj = getDocument(id);
		if (null == obj || obj.isEmpty()) {
			createMapperDocuments();
			obj = getDocument(id);
		}
		return obj;
	}

	public AbstractDAOImpl getAbstractDAO() {
		return abstractDAO;
	}

	public void setAbstractDAO(AbstractDAOImpl abstractDAO) {
		this.abstractDAO = abstractDAO;
	}

	public String getEappDataObjectByDate(String sd, String sm, String sy, String ed, String em, String ey, String ehr,
			String emin, String esec, String reportType, String carrierCode, int listMin, int listMax) {

		JSONArray arrayRet = new JSONArray();
		int cbSize = 0;
		JSONObject returnVlaue = new JSONObject();
		listMin = listMin - 1;
		int oraMin = 0;
		int oraMax = listMax;
		int cbPageSize = 0;
		int inListSize = 5000;

		JSONArray jArray = new JSONArray();

		// all reports from CouchBase (latest records)
		Map<String, Object> arrayRetView = getEappReportsByDateFromView(sd, sm, sy, ed, em, ey, ehr, emin, esec,
				carrierCode);
		String eappIdsQuery = "";
		Map<String, Object> paramMap = new java.util.HashMap<String, Object>();
		if (null != arrayRetView && arrayRetView.size() != 0) {
			cbSize = arrayRetView.size();
			jArray.addAll(arrayRetView.values());
			eappIdsQuery = "";
			List<String> keyList = new ArrayList<String>(arrayRetView.keySet()); // (List<String>)
																					// arrayRetView.keySet();
			List<String> tempList = new ArrayList<String>();
			int nxtsize = 0;
			String idsString = "";
			for (int i = 0; i < keyList.size(); i += inListSize) {
				idsString = "";
				nxtsize = i + inListSize;
				if (nxtsize > keyList.size()) {
					nxtsize = keyList.size();
				}
				tempList = keyList.subList(i, nxtsize);
				for (String v : tempList) {
					if (idsString == "") {
						idsString = "'" + v + "'";
					} else {
						idsString = idsString + ",'" + v + "'";
					}
				}
				eappIdsQuery = eappIdsQuery + " and eappId NOT IN (" + idsString + ")";
			}
		}

		String lowRangeDate = sd + "-" + sm + "-" + sy + "_00:00:0";
		String upperRangeDate = ed + "-" + em + "-" + ey + "_" + ehr + ":" + emin + ":" + esec;
		String ccQuery = "";
		if (null != carrierCode && carrierCode.equalsIgnoreCase("CUMIS")) {
			ccQuery = "carriercode='CUMIS'";
		} else {
			// ideally carriercode will be 'CLIC' for CLIC & old records also
			// BCZ we are updating reports
			// update query if required
			ccQuery = "carriercode='' or carriercode IS NULL or carriercode='CLIC'";
		}

		String queryStr = "(modified_date >= to_date('" + lowRangeDate
				+ "','DD/MM/YYYY HH24:MI:SS') and modified_date <= to_date('" + upperRangeDate
				+ "','DD/MM/YYYY HH24:MI:SS')) and  (" + ccQuery + ") " + eappIdsQuery + " ORDER BY modified_date asc";
		List objsCNT = null;
		int oraListSize = 0;

		// for getting count of records in oracle to find total number of
		// records
		try {

			objsCNT = (List) getAbstractDAO()
					.executeNativeQuery("select count(*) from " + "eapp_reports" + " where " + queryStr, paramMap);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if (null != objsCNT && objsCNT.size() != 0) {
			try {
				oraListSize = (int) ((BigDecimal) objsCNT.get(0)).intValue();
			} catch (Exception e) {
				logger.error("cannot convert oracle record count to integer");
				e.printStackTrace();
			}
		}
		int cbMin = listMin, cbMax = cbSize;

		/*
		 * if(listMin <= cbSize){ if(cbSize > listMax ){ cbMax = listMax; }
		 * arrayRet.addAll(jArray.subList(cbMin,cbMax)); }
		 */
		// remove following line if you uncomment above line(for pagination)
		arrayRet.addAll(jArray);

		cbPageSize = arrayRet.size();

		// for Getting Records from oracle
		if (cbPageSize < (listMax - listMin)) {
			oraMax = listMax - listMin - cbPageSize;
			if (listMin > cbSize) {
				oraMin = listMin - cbSize;
			}

			List objs = new ArrayList();

			try {
				objs = (List) getAbstractDAO().executeCriteriaByRange(EappReports.class, queryStr, paramMap, oraMin,
						oraMax);

			} catch (DataAccessException e) {
				logger.error("Exception while retrieving record from oracle:: " + e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				logger.error("Exception while retrieving record from oracle:: " + e.getMessage());
				e.printStackTrace();
			}

			for (Object temp : objs) {
				EappReports report = (EappReports) temp;
				arrayRet.add(getReportJsonFromEappReport(report));

			}

		}

		returnVlaue.put("data", arrayRet);
		returnVlaue.put("totalCount", cbSize + oraListSize);

		return returnVlaue.toString();
	}

	private Map<String, Object> getEappReportsByDateFromView(String sd, String sm, String sy, String ed, String em,
			String ey, String ehr, String emin, String esec, String carrierCode) {
		// to get reports from view

		JSONParser parser = new JSONParser();
		JSONObject policyJsonDoc = null;

		JSONArray arrayRet = new JSONArray();

		// to get current day records from view (couchBase)
		IEbixView view1 = client.getView_("advisor", "by_dateForAudit1");
		IEbixQuery objQuery = client.getQueryInstance_();
		objQuery.setIncludeDocs(true);
		String lowRange = "[\"" + carrierCode + "\"," + "[" + sy + "," + sm + "," + sd + "]]";
		String upperRange = "[\"" + carrierCode + "\"," + "[" + ey + "," + em + "," + ed + "," + ehr + "," + emin + ","
				+ esec + "]]";
		String sortOrder = "asc";
		if (null != sortOrder && sortOrder.equalsIgnoreCase("desc")) {
			objQuery.setRange(upperRange, lowRange);
			objQuery.setDescending(true);
		} else {
			objQuery.setRange(lowRange, upperRange);
			objQuery.setDescending(false);
		}

		Map<String, Object> map = new java.util.HashMap<String, Object>();
		IEbixViewResponse res = client.excuteViewWithViewObjAndQueryObj(view1, objQuery);
		String repDocString = null;
		for (IEbixViewRow row : res) {
			try {
				if (row.getDocument() != null) {
					repDocString = row.getDocument().toString();
				}
				if (null != repDocString && !repDocString.isEmpty()) {
					policyJsonDoc = (JSONObject) parser.parse(repDocString);
					policyJsonDoc = getTableFormattedReportFromReportData(policyJsonDoc);
					map.put((String) policyJsonDoc.get("eappId"), policyJsonDoc);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return map;
	}

	public JSONObject getReportJsonFromEappReport(EappReports reports) {
		JSONObject resultTmp = new JSONObject();
		ObjectMapper mapper = new ObjectMapper();
		try {
			String resultStr = "";
			try {
				resultStr = mapper.writeValueAsString(reports);
			} catch (Exception e) {
				e.printStackTrace();
			}
			resultTmp = (JSONObject) new JSONParser().parse(resultStr);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultTmp;
	}
	
	private void moveReportsToOracleByDate() {

		Map<String, String> dateMap = null;
		try {
			dateMap = readDates();
		} catch (Exception e) {
			System.out.println("Exception while reading dates... Please try again with proper dates");
			e.printStackTrace();
		}
		String[] startDate = null;
		String[] endtDate = null;
		// JSONArray reportsArray = null;
		boolean isRenamed = false;

		System.out.println("Please waite Fetching Reports...");

		if (null != dateMap && !dateMap.isEmpty()) {
			startDate = dateMap.get("startDate").split("-");
			endtDate = dateMap.get("endDate").split("-");
			if (null != startDate && null != endtDate) {
				String[] carrierCode = { "CLIC", "CUMIS" };
				Map<String, Object> returnMap = new HashMap<String, Object>();
				boolean isUploadedCase = false;
				boolean isAdvisoruploaded = false;
				boolean isDeletedCase = false;
				for (int i = 0; i < carrierCode.length; i++) {
					System.out.println("Fetching Reports by carrierCode:" + carrierCode[i]);
					try {
						returnMap = getEappReportsByDateFromView(startDate[0], startDate[1], startDate[2], endtDate[0],
								endtDate[1], endtDate[2], "23", "59", "59", carrierCode[i]);
						if (null != returnMap && !returnMap.isEmpty()) {
							System.out.println("toal records found by carrierCode:" + carrierCode[i]+": "+returnMap.size());
							JSONArray retArray = new JSONArray();
							retArray.addAll(returnMap.values());
							if (null != retArray && !retArray.isEmpty()) {
								// reportsArray.add(retArray);
								JSONObject responseObj = null;
								String eappId = "";
								String status = "";
								String appType = "";
								for (int j = 0; j < retArray.size(); j++) {
									responseObj = (JSONObject) retArray.get(j);
									eappId = safeGet(responseObj, "eappId");
									status = safeGet(responseObj, "status");
									isUploadedCase = safeGet(responseObj, "eappStatus").equalsIgnoreCase("Uploaded") ? true : false;
									isAdvisoruploaded = safeGet(responseObj, "advisorCode").equalsIgnoreCase("Uploaded") ? true
											: false;
									isDeletedCase = safeGet(responseObj, "eappStatus").equalsIgnoreCase("Deleted") ? true : false;
									
									if (isDeletedCase || (isUploadedCase && isAdvisoruploaded)) {
										// Moving Deleted Cases Case Data to oracle
										JSONObject eappCaseData = getDocument(eappId);
										appType = safeGet(eappCaseData, "appType");
										if (!appType.equalsIgnoreCase("wealth")) {
											appType = "life";
										}
										boolean ismoved = moveCaseAudiToDB(eappId, true);
										System.out.println(eappId + " isMoved:" + ismoved);
									}
									if (responseObj != null && !responseObj.isEmpty() && eappId.startsWith("COOPTrans")) {
										boolean ismoved = saveReports(eappId, responseObj);
										if (ismoved) {
											System.out.println(eappId + " isMoved:" + ismoved);
											client.delete(eappId.replace("COOPTrans", "Reports"));
										}
									}
								}

							}
						}
						try {
							System.out.println("Please wait...");
							Thread.sleep(3000);
						} catch (InterruptedException ex) {
							Thread.currentThread().interrupt();
						}

					} catch (Exception e) {
						System.out.println("Exception while Fetching Reports by carrierCode:" + carrierCode[i]);
						e.printStackTrace();
					}
				}
				System.out.println("completed Fetching Reports");
			}
		}
	}
	
	public boolean generatePerormanceMetricsReport(){
		boolean res = false;
		JSONObject eventsDocJSON = getDocument("performance_events_data");
		
		if (eventsDocJSON == null) {
			System.out.println("Events list object is null");
		}
		
		String fullFilePathR = gatAuditLogPath();
		if(null != fullFilePathR && !fullFilePathR.isEmpty()){
			fullFilePathR = fullFilePathR.replace("audit.log", "");
		}
		try {
			List files = readAuditLogs(fullFilePathR);
			for(int i=0; i<files.size(); i++){
				generatePerormanceMetricsReportCSV(files.get(i).toString());
			}
			
		} catch (Exception e) {
			System.out.println("Exception in generatePerormanceMetricsReport");
			e.printStackTrace();
		}
		return false;
	}
	
	public void generatePerormanceMetricsReportCSV(String reportDate) {
		boolean processStatus = false;
		
		try {
			//couchbase metada events :: performance_events_data
			JSONObject eventsDocJSON = getDocument("performance_events_data");
			
			if (eventsDocJSON == null) {
				System.out.println("Events list object is null");
			}
			
			String fullFilePathR = reportDate;
			/*String fullFilePathR = gatAuditLogPath();
					
			String logDate;
			if (reportDate != null && !reportDate.isEmpty()) {
				logDate = new SimpleDateFormat("yyyy-MM-dd").format(DateUtils.addDays(new Date(), -1));
				fullFilePathR = (fullFilePathR +"_"+ logDate +".log");
			}*/
			String fileName = "";
			if(null != fullFilePathR && !fullFilePathR.isEmpty()){
				String[] arr = fullFilePathR.split("audit");
				fileName = "audit"+arr[arr.length-1];
			}
			
			String auditLogsStr = readFileFromPath(fullFilePathR);
			List<String> auditLogs  = new ArrayList<String>();
			if(null != auditLogsStr && !auditLogsStr.isEmpty()){
				auditLogs = Arrays.asList(auditLogsStr.split("\n"));
			}
			if(auditLogs.isEmpty()) {
				System.out.println("Performance audit logs : " + fullFilePathR + " are empty");
				return; 
			}
					
			//Advisor report
			StringBuilder advisorCSV = getAdvisorPerformaneReport(filterAuditLogs(auditLogs, eventsDocJSON));
			if (advisorCSV.length() > 0) {
				boolean res = writeToFile("Audit Reports", fileName+".csv", advisorCSV.toString());
				if(res){
					System.out.println("Advisor performance metric report file:" + fileName + ".csv generated ");
				}
			}
		} catch (Exception e) {
			System.out.println("Exception in generatePerormanceMetricsReportCSV ::"+e.getMessage());
		}
		
	}
	
	public Map<String, List<String>> filterAuditLogs(List<String> auditLogs, JSONObject eventsDocJSON) {
		Map<String, List<String>> advisorAuditLogs = new HashMap<String, List<String>>();
		String[] lineArr;
		List<String> tempList;
		StringBuilder lineSB;
		for (String line : auditLogs) {
			lineSB = new StringBuilder();
			lineArr = line.split("\\|");
			try {
				tempList = advisorAuditLogs.get(lineArr[9]);
				lineSB.append(lineArr[9])
					   .append(",")
					   .append(lineArr[2])
					   .append(",")
					   .append(lineArr[0].split(" ")[0])
					   .append(",")
					   .append(lineArr[0].split(" ")[1])
					   .append(",")
					   .append(lineArr[10])
					   .append(",")
					   .append(lineArr[5])
					   .append(",")
					   .append(eventsDocJSON.get(lineArr[5]))
					   .append(",")
					   .append(lineArr[8]);
				line = lineSB.toString();
				if (tempList == null) {
					List<String> newList = new ArrayList<String>();
					newList.add(line);
					advisorAuditLogs.put(lineArr[9], newList);
				} else {
					tempList.add(line);
				}
			} catch (Exception e) {
				System.out.println("Invalid audit log entry."+ e.getMessage());
			}
		}
		return advisorAuditLogs;
	}
	
	public StringBuilder getAdvisorPerformaneReport(Map<String, List<String>> advisorAuditLogs) {
		StringBuilder advisorReportCSV = new StringBuilder();
		for (List<String> logEntryList : advisorAuditLogs.values()) {
			for (String logEntry : logEntryList) {
				advisorReportCSV.append(logEntry);
				advisorReportCSV.append("\n");
			}
		}
		return advisorReportCSV;
	}
	
	public List readAuditLogs(String path){
		File folder = new File(path);
		File[] listOfFiles = folder.listFiles();
		List<String> list = new ArrayList<String>();

		for (int i = 0; i < listOfFiles.length; i++) {
		  if (listOfFiles[i].isFile() && listOfFiles[i].getName().startsWith("audit")) {
		    System.out.println("File " + listOfFiles[i].getName());
		    list.add(listOfFiles[i].getPath());
		  }
		}
		return list;
	}
	
	public String gatAuditLogPath() {
		String path = "";
		ResourceBundle rb = null;
		FileInputStream fin = null;
		String confPath = System.getProperty(CONFFILE_PATH);
		try {
			if (null != confPath && !confPath.isEmpty()) {
				fin = new FileInputStream(confPath + "/log4j.properties");
				rb = new PropertyResourceBundle(fin);
				path = rb.getString("log4j.appender.AUDIT.File");
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (null != fin)
					fin.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return path;
	}
	
}
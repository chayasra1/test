package com.couchBase.test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.eapp.dao.impl.AbstractDAOImpl;
import com.eapp.utility.CoopProperties;
import com.ebix.couchbase.core.contracts.IEbixConnectionManager;
import com.ebix.couchbase.core.contracts.IEbixCouchbaseClient;
import com.ebix.couchbase.core.contracts.IEbixDesignDocument;
import com.ebix.couchbase.core.contracts.IEbixPaginator;
import com.ebix.couchbase.core.contracts.IEbixQuery;
import com.ebix.couchbase.core.contracts.IEbixView;
import com.ebix.couchbase.core.contracts.IEbixViewDesign;
import com.ebix.couchbase.core.contracts.IEbixViewResponse;
import com.ebix.couchbase.core.contracts.IEbixViewRow;
import com.ebix.couchbase.legacy.EbixConnectionManager;

public class LoadTest {

	private static final String CONFFILE_PATH = "ebix.configuration.folder";

	String confPath = System.getProperty(CONFFILE_PATH);

	ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");

	private AbstractDAOImpl abstractDAO = (AbstractDAOImpl) context.getBean("abstractDAO");

	private static Logger logger = Logger.getLogger(LoadTest.class);

	static IEbixCouchbaseClient client = null;

	private static final String PDF_DIRECTORY = CoopProperties.getProp("pdf.repository.dir");

	public static void main(String[] args) throws IOException, URISyntaxException {

		IEbixConnectionManager.ref = EbixConnectionManager.init();
		client = EbixConnectionManager.init().instance().getClient();

		RunnableFecthDemo R1 = new RunnableFecthDemo( "Fecthing");
	      R1.start();
	      
	      RunnableSaviDemo R2 = new RunnableSaviDemo( "Saving");
	      R2.start();

	      
	      RunnableQueryDemo R3 = new RunnableQueryDemo( "Quering");
	      R3.start(); 
	}

	




	/**
	 * Getting all Documents from CouchBase through Views
	 */
	public static void findUnnecessaryDocsFromCouchBase() {
		IEbixDesignDocument designDoc = null;
		String mapFunction = null;
		IEbixViewDesign viewDesign = null;
		File file = null;
		FileWriter fr = null;
				
		IEbixView view = client.getView_("D2C", "allmetadata");
		IEbixQuery query = client.getQueryInstance_();
		query.setIncludeDocs(true);
		int docsPerPage = 30;
		try {
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
		    System.out.println("view hitted");
		    if (pages.hasNext()) {
				System.out.println("Please Waite.. Processing Page:");
				IEbixViewResponse response = pages.next();
				try {
					for (IEbixViewRow row : response) {
						String eid = row.getId();
						try {
							System.out.println("Report Id -" + eid);
						} catch(Exception e) {
							e.printStackTrace();
						}
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
		    }
					
		} catch (Exception e) {
			System.out.println("Exception in findUnnecessaryDocsFromCouchBase");
			e.printStackTrace();
		} 
	}

	
	

	
	

	
	private static String fetch(String eappId) {
		String val = (String) client.get(eappId);
		return null != val ? val : "";
	}

	public static JSONObject getDocument(String id) {
		JSONObject jsonobject = null;
		try {
			String data = fetch(id);
			if (null != data && !data.isEmpty()) {
				jsonobject = (JSONObject) new JSONParser().parse(data);
			}

		} catch (Exception e) {
			System.out.println("Exception while getting document for:" + id);
			e.printStackTrace();
		}
		return jsonobject;
	}

	private String safeGet(JSONObject jso, String prop) {
		Object propobj = null;
		try {
			propobj = jso.get(prop);
		} catch (Exception exprop) {
		}
		return propobj == null ? "" : propobj.toString();
	}

	


	public AbstractDAOImpl getAbstractDAO() {
		return abstractDAO;
	}

	public void setAbstractDAO(AbstractDAOImpl abstractDAO) {
		this.abstractDAO = abstractDAO;
	}



	public static boolean saveDocument(String docId, JSONObject jsonObject) {
		boolean isSaved = false;
		try {
			saveDocumentWithString(docId, jsonObject.toString());
			isSaved = true;
		} catch (Exception e) {
			logger.fatal("saveDocument:: " + e.getMessage());
		}
		return isSaved;
	}

	public static boolean saveDocumentWithString(String docId, String jsonObject) {
		boolean isSaved = false;
		try {
			client.set(docId, jsonObject.toString());
			isSaved = true;
		} catch (Exception e) {
			logger.fatal("saveDocument:: " + e.getMessage());
		}
		return isSaved;
	}
	/*
	 * Delete unnecessary html docs from couch base
	 */
	public void delatingUnnecessaryDocs() {
		JSONObject agentId = getDocument("UnnessaryDocs");
		JSONArray retArray = (JSONArray) agentId.get("htmlDocs");
		if (null != retArray && !retArray.isEmpty()) {
			String responseObjOne = null;
			for (int j = 0; j < retArray.size(); j++) {
				responseObjOne = (String) retArray.get(j);
				System.out.println("----------------- :" + responseObjOne.toString());
				// client.delete(responseObjOne);
			}
		}
	}






	public static void deleteDocument(String string) {
		try {
			client.delete(string);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}

 class RunnableFecthDemo implements Runnable {
	   private Thread t;
	   private String threadName;
	   
	   RunnableFecthDemo( String name) {
	      threadName = name;
	      System.out.println("Creating " +  threadName );
	   }
	   
	   public void run() {
	      System.out.println("Running " +  threadName );
	      try {
	         for(int i = 50000; i > 0; i--) {
	            System.out.println("Thread: " + threadName + ", " + i);
	            // Let the thread sleep for a while.
	            LoadTest.getDocument("D2CReqId-007b2c20-98cf-4879-9e4d-1c7b95f37300");
	            if (i%1000==0) {
	            	try {
	        			Thread.sleep(2000);
	        		} catch (InterruptedException ex) {
	        			Thread.currentThread().interrupt();
	        		}
	            }
	         }
	      }catch (Exception e) {
	         System.out.println("Thread " +  threadName + " interrupted.");
	      }
	      System.out.println("Thread " +  threadName + " exiting.");
	   }
	   
	   public void start () {
	      System.out.println("Starting " +  threadName );
	      if (t == null) {
	         t = new Thread (this, threadName);
	         t.start ();
	      }
	   }
	}
 
 
 class RunnableSaviDemo implements Runnable {
	   private Thread t;
	   private String threadName;
	   
	   RunnableSaviDemo( String name) {
	      threadName = name;
	      System.out.println("Creating " +  threadName );
	   }
	   
	   public void run() {
	      System.out.println("Running " +  threadName );
	      try {
	         for(int i = 50000; i > 0; i--) {
	            System.out.println("Thread: " + threadName + ", " + i);
	            // Let the thread sleep for a while.
	            JSONObject obj = LoadTest.getDocument("D2CReqId-007b2c20-98cf-4879-9e4d-1c7b95f37300");
	            obj.put("ss", true);
	            LoadTest.saveDocument("D2CReqId-007b2c20-98cf-4879-9e4d-1c7b95f37300"+i, obj);
	            if (i%1000==0) {
	            	try {
	        			Thread.sleep(2000);
	        		} catch (InterruptedException ex) {
	        			Thread.currentThread().interrupt();
	        		}
	            }
	            LoadTest.deleteDocument("D2CReqId-007b2c20-98cf-4879-9e4d-1c7b95f37300"+i);
	         }
	      }catch (Exception e) {
	         System.out.println("Thread " +  threadName + " interrupted.");
	      }
	      System.out.println("Thread " +  threadName + " exiting.");
	   }
	   
	   public void start () {
	      System.out.println("Starting " +  threadName );
	      if (t == null) {
	         t = new Thread (this, threadName);
	         t.start ();
	      }
	   }
	}
 
 class RunnableQueryDemo implements Runnable {
	   private Thread t;
	   private String threadName;
	   
	   RunnableQueryDemo( String name) {
	      threadName = name;
	      System.out.println("Creating " +  threadName );
	   }
	   
	   public void run() {
	      System.out.println("Running " +  threadName );
	      try {
	         for(int i = 50000; i > 0; i--) {
	        	   System.out.println("Thread: " + threadName + ", " + i);
	        	 LoadTest.findUnnecessaryDocsFromCouchBase();
	        	 
	        	 if (i%1000==0) {
		            	try {
		        			Thread.sleep(2000);
		        		} catch (InterruptedException ex) {
		        			Thread.currentThread().interrupt();
		        		}
		            }
	         }
	      }catch (Exception e) {
	         System.out.println("Thread " +  threadName + " interrupted.");
	      }
	      System.out.println("Thread " +  threadName + " exiting.");
	   }
	   
	   public void start () {
	      System.out.println("Starting " +  threadName );
	      if (t == null) {
	         t = new Thread (this, threadName);
	         t.start ();
	      }
	   }
	}


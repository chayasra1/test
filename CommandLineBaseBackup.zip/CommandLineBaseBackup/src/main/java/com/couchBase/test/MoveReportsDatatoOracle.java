package com.couchBase.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.eapp.dao.impl.AbstractDAOImpl;
import com.eapp.entity.EappCaseAudit;
import com.eapp.entity.EappReports;
import com.eapp.exception.DataAccessException;
import com.ebix.couchbase.core.contracts.IEbixConnectionManager;
import com.ebix.couchbase.core.contracts.IEbixCouchbaseClient;
import com.ebix.couchbase.core.contracts.IEbixPaginator;
import com.ebix.couchbase.core.contracts.IEbixQuery;
import com.ebix.couchbase.core.contracts.IEbixView;
import com.ebix.couchbase.core.contracts.IEbixViewResponse;
import com.ebix.couchbase.core.contracts.IEbixViewRow;
import com.ebix.couchbase.legacy.EbixConnectionManager;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MoveReportsDatatoOracle {

	private static final String CONFFILE_PATH = "ebix.configuration.folder" ;

	
	String confPath = System.getProperty(CONFFILE_PATH);
	
	ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");

	private AbstractDAOImpl abstractDAO = (AbstractDAOImpl) context.getBean("abstractDAO");

	static IEbixCouchbaseClient client = null;

	public static void main(String[] args) throws IOException, URISyntaxException {

		IEbixConnectionManager.ref = EbixConnectionManager.init();
		client = EbixConnectionManager.init().instance().getClient();
		
		int choice = 0;
		
		MoveReportsDatatoOracle moveDocs = new MoveReportsDatatoOracle();
		
		while(choice!=7){
			System.out.println("\nSelect Options: ");
			System.out.println("1: Move Report documents to oracle");
			System.out.println("2: Upadte Agent data");
			System.out.println("3: Move all Case and Report documents to Oracle with Document- RemainingCases");
			System.out.println("4: Move all Only uploaded/Deleted and Report Case documents to Oracle");		
			System.out.println("5: Move all Uploaded Case and Report documents to Oracle & Delete From Couchbase");
			System.out.println("6: Move all Today pending Case and Report documents to Oracle -one time job");
			System.out.println("7: Quit");
			
			Scanner scan = new Scanner(System.in);
			try {
			choice = Integer.parseInt(scan.nextLine());
			} catch (Exception e){
				choice = 0;
			}
			switch (choice) {
			case 1:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Move Report documents to oracle - Daily" );
				System.out.println("\nPlease waite, Operation in progress...");
				moveDocs.moveReportsToOracle();
				break;
			case 2:
				System.out.println("you selected : " + choice);
				System.out.println("you selected : Upadte Agent data" );
				moveDocs.dataUpgradeOfAgentData();
				System.out.println("Please waite, Operation in progress...");
				break;
			case 3:
				System.out.println("you selected : " + choice);
				System.out.println("you selected :Move all Case and Report documents to Oracle with Document- RemainingCases" );
				moveDocs.moveDataToOracle();
				break;
			
			case 4:
				System.out.println("yoiselected : " + choice);
				System.out.println("you selected :Move all Only uploaded/deleted and Report Case documents to Oracle" );
				moveDocs.moveCasess(true, false, true, false);
				break;
				
			case 5:
				System.out.println("you selected : " + choice);
				System.out.println("Move all Uploaded Case and Report documents to Oracle & Delete From Couchbase" );
				System.out.println("press 'Y/y' conform delete documents from CouchBase OR press any key to cancell Action:");
				scan = new Scanner(System.in);
				String conformDelete = scan.nextLine();
				if(!conformDelete.equalsIgnoreCase("y")){
					break;
				}
				moveDocs.moveCasess(true, false, true, true);
				break;
			
			case 6:
				System.out.println("yoiselected : " + choice);
				System.out.println("you selected :Move all Today pending Case and Report documents to Oracle -one time job" );
				System.out.println("Enter Starting file index number:");
				scan = new Scanner(System.in);
				String docSelect = scan.nextLine();
				int index = 1;
				try {
					index = Integer.parseInt(scan.nextLine());
					} catch (Exception e){
						choice = 0;
					}				
				moveDocs.moveLeftOutcassess(index);
				break;
				
			case 7:
				System.out.println("press 'Y/y' conform exit:");
				scan = new Scanner(System.in);
				String conform = scan.nextLine();
				if(!conform.equalsIgnoreCase("y")){
					choice = 0;
				}
				break;

			default:
				System.out.println("Please select a proper Option");
				break;
			}
			
			System.out.println("******Task Completed******");
		}
		client.shutdown();
		System.out.println("********END********");
		System.exit(0);
	}
	
	/**
	 * 
	 */
	public void dataUpgradeOfAgentData(){
		
		JSONObject changesDoc = getDocument("AgentsChangesDoc");
		
		if(null != changesDoc && !changesDoc.isEmpty()){
			String listStr = safeGet(changesDoc, "data");
			if(!listStr.isEmpty()){
				JSONArray changesList = null;
				try {
					changesList = (JSONArray) new JSONParser().parse(listStr);
				} catch (Exception e) {
					System.out.println("Exception while parcing data array in AgentsChangesDoc");
					e.printStackTrace();
				}
				
				if(null != changesList && !changesList.isEmpty()){
					String docName ="";
					JSONObject agentData = null;
					for(int i=0;i<changesList.size();i++){
						try {
							docName = (String) changesList.get(i);
							if(null != docName && !docName.isEmpty()){
								agentData = getDocument("Agent_Data_"+docName);
								if(null != agentData && !agentData.isEmpty()){
									agentData.remove("ObjectId");
									client.set("Agent_Data_"+docName, agentData.toString());
								}
							}
						} catch (Exception e) {
							System.out.println("Exception while processing document of:"+docName);
							e.printStackTrace();
						}
					}
				}
				
				
			}else{
				System.out.println("Cannot Find data array AgentsChangesDoc");
			}
		}else{
			System.out.println("cannot Find AgentsChangesDoc in CouchBase");
		}
		
	}
	
	public String readFile(String folder,String name){
		String fileData = null;
		try {
			System.out.println("Reading file:"+name+" in folder"+folder);
			FileInputStream fin = null;
			BufferedReader reader =null;
			fin = new FileInputStream("."+File.separator+folder+File.separator+name);
			
			if (fin != null ){
				reader = new BufferedReader(new InputStreamReader(fin));
			}
			StringBuilder sb = new StringBuilder();
			String line="";
			while((line = reader.readLine())!= null){
				sb.append(line+"\n");
			}
			fileData = sb.toString();
			System.out.println("Reading compleated.");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		
		return fileData;
	}
	
	public void moveLeftOutcassess(int index){
		String folderName = "moves";
		String fileStr = null;
		JSONArray idsList = null;
		JSONObject caseDocs = null;
		JSONObject reportDoc = null;
		String eappId = null;
		String appType = "Life";
		for (int i = index; i <= 16; i++) {
			fileStr = readFile(folderName,"move"+i+".json");			
			if(null != fileStr && !fileStr.isEmpty()){
				try {
					idsList =(JSONArray)new JSONParser().parse(fileStr);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				if(null != idsList && !idsList.isEmpty()){					
					for (int j = 0; j < idsList.size(); j++) {
						eappId = (String) idsList.get(j);
						System.out.println(eappId + "-- Processing:" );
						caseDocs = getDocument(eappId);
						if(null != caseDocs && !caseDocs.isEmpty()){
							boolean isCasemoved = false;
							String eapp_Status = safeGet(caseDocs, "eappStatus");
							appType = safeGet(caseDocs, "appType");
							if (!appType.equalsIgnoreCase("wealth")) {
								appType = "life";
							}
							reportDoc = getFormattedReport(getDocument(eappId), appType);
							reportDoc = getFormattedReport(reportDoc, "oldApps");		
							if (eapp_Status.equals("Deleted")) {
								// Moving Deleted Cases Case Data to oracle
								 isCasemoved = moveCaseAudiToDB(eappId, true);
							} else {						
								isCasemoved = moveCaseAudiToDB(eappId, false);
							}
							System.out.println(eappId + " isMoved:" + isCasemoved);
							boolean ismoved = saveReports(eappId, reportDoc);
							if(ismoved){
								client.delete(eappId.replace("COOPTrans", "Reports"));
							}
						}
					}
				}
			}
			try {
				Thread.sleep(2000);				
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
			
		}
		
	}
	
	/**
	 * 
	 * 
	 */
	public void moveDataToOracle() {
		
		JSONObject repDoc = null;		
		String appType = "life";
		int pcnt = 0;
		JSONObject remainigCases = getDocument("RemainingCases");
		// query.setLimit(100);
		int docsPerPage = 200;
		try {
			if (remainigCases!=null && remainigCases.isEmpty() ) {
				String listStr = safeGet(remainigCases, "data");
				if(!listStr.isEmpty()){
					JSONArray changesList = null;
					try {
						changesList = (JSONArray) new JSONParser().parse(listStr);
					} catch (Exception e) {
						System.out.println("Exception while parcing data array in AgentsChangesDoc");
						e.printStackTrace();
					}
					
					if(null != changesList && !changesList.isEmpty()){
						String docName ="";
						JSONObject caseData = null;
						for(int i=0;i<changesList.size();i++){
							try {
								docName = (String) changesList.get(i);
								if(null != docName && !docName.isEmpty()){
									caseData = getDocument(docName);
									if(null != caseData && !caseData.isEmpty()){
										boolean isCasemoved = false;
										String eapp_Status = safeGet(caseData, "eappStatus");
										appType = safeGet(caseData, "appType");
										if (!appType.equalsIgnoreCase("wealth")) {
											appType = "life";
										}
										if (eapp_Status.equals("Deleted")) {
											// Moving Deleted Cases Case Data to oracle
											repDoc = getFormattedReport(getDocument(docName), appType);
											repDoc = getFormattedReport(repDoc, "oldApps");		
											 isCasemoved = moveCaseAudiToDB(docName, true);
										} else {						
											isCasemoved = moveCaseAudiToDB(docName, false);
										}
										System.out.println(docName + " isMoved:" + isCasemoved);
										boolean ismoved = saveReports(docName, repDoc);
										if(ismoved){
											client.delete(docName.replace("COOPTrans", "Reports"));
										}
									}
								}
								if (docsPerPage!=0){
									docsPerPage = docsPerPage-1;									
								} else {
									try {
										Thread.sleep(2000);
										docsPerPage = 200;
									} catch (InterruptedException ex) {
										Thread.currentThread().interrupt();
									}
								}
							} catch (Exception e) {
								System.out.println("Exception while processing document of:"+docName);
								e.printStackTrace();
							}
						}
					}
					
					
				}else{
					System.out.println("Cannot Find data array AgentsChangesDoc");
				}
			}
				
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * move reports docs to oracle db and clean up
	 * 
	 */
	public void moveReportsToOracle() {		
		JSONObject repDoc = null;		
		JSONObject formatedrepDoc = null;
		String appType = "life";
		int pcnt = 0;
		String eappId = null;
		IEbixView view = client.getView_("advisor", "by_dateForAudit1");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);
		int docsPerPage = 100;
		try {
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
			while (pages.hasNext()) {
				System.out.println("Please Waite.. Processing Page:" + pcnt++);
				IEbixViewResponse response = pages.next();
				try {
					for (IEbixViewRow row : response) {
						String eid = row.getId();
						try {
							System.out.println("Report Id -"+eid);
							repDoc = getDocument(eid);
							String eapp_Status = safeGet(repDoc, "ST");
							eappId = safeGet(repDoc, "EID");
							if (eapp_Status.equals("Deleted")) {
								// Moving Deleted Cases Case Data to oracle
								JSONObject eappCaseData = getDocument(eappId);
								appType = safeGet(eappCaseData, "appType");
								if (!appType.equalsIgnoreCase("wealth")) {
									appType = "life";
								}
								repDoc = getFormattedReport(eappCaseData, appType);								
								boolean ismoved = moveCaseAudiToDB(eappId, true);
								System.out.println(eid + " isMoved:" + ismoved);
							}		
							formatedrepDoc = getFormattedReport(repDoc, "oldApps");
							boolean ismoved = saveReports(eid, formatedrepDoc);
							if(ismoved){
								client.delete(eid);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
			}
	
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * 
	 */
	public void updateOldReportDocuments() {

		
		JSONObject eappData = new JSONObject();
		JSONObject repDoc = new JSONObject();
		String appType = "life";
		int pcnt = 0;
		IEbixView view = client.getView_("advisor", "by_ApplicationType");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);
		int docsPerPage = 50;
		try {
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
			while (pages.hasNext()) {
				System.out.println("Please Waite.. Processing Page:" + pcnt++);
				IEbixViewResponse response = pages.next();
				try {
					for (IEbixViewRow row : response) {
						String eid = row.getId();
						try {
							if (null != eid && !eid.isEmpty() && eid.startsWith("COOPTrans-")) {
								eappData = getDocument(eid);
								appType = safeGet(eappData, "appType");
								if (!appType.equalsIgnoreCase("wealth")) {
									appType = "life";
								}
								repDoc = getFormattedReport(eappData, appType);
								client.set(eid.replace("COOPTrans", "Reports"), repDoc.toString());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
			}
//			client.shutdown();
		
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * Here this api for one time job.
	 * We have identified some know issues with old existing cases
	 * 
	 * 1 	BeneModels' missing ,Getting Null pointer exception while uploaded Time ---- 	Life/GC/GIO ---- 	Locked --	Data Fix 	"BeneModels": {}
	 * 
	 * 2  	Old Bene data populate rows issue , while opening in Edit mode 	-----Wealth 	---Locked 	---Data Fix 	---requiredMandatoryElems=[] need add in Primary Bene,Contigent Bene records
	 * 
	 * 3 	Old Bene data - unable bind the edit bene record in Grid level --------- 	Wealth ------ 	Unlocked ---	Data Fix ---	Create Copy of old Bene data with new application
	 * 
	 * 
	 */
	public void dataUpgradeOfOldPendingCases() {
		try {

			JSONObject eappData = new JSONObject();
			JSONParser objJSONParser = new JSONParser();
			JSONObject formattedDocumentIds = new JSONObject();

			String appType = null;

			IEbixView view = client.getView_("advisor", "by_ApplicationType");
			IEbixQuery query = client.getQueryInstance_();
			
			int pcnt = 0;

			int docsPerPage = 100;
			IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
			while (pages.hasNext()) {
				System.out.println("Please Waite.. Processing Page:" + pcnt++);
				IEbixViewResponse response = pages.next();
				for (IEbixViewRow row : response) {
					String eid = row.getId();

					if (null != eid && !eid.isEmpty() && eid.startsWith("COOPTrans-")) {
						eappData = getDocument(eid);
						boolean isUploadedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Uploaded") ? true
								: false;
						boolean isAdvisoruploaded = safeGet(eappData, "advisorCode").equalsIgnoreCase("Uploaded") ? true
								: false;
						boolean isDeletedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Deleted") ? true
								: false;
						appType = safeGet(eappData, "appType");
						if (isUploadedCase || isAdvisoruploaded || isDeletedCase) {

						} else {
							// back up old case data
							formattedDocumentIds.put(eid, appType);

							// modifying Type and advisor
							JSONObject old_eappData = (JSONObject) objJSONParser.parse(eappData.toString());

							old_eappData.put("type", "OldRecord");
							old_eappData.put("oldadvisorCode", safeGet(eappData, "advisorCode"));
							old_eappData.remove("advisorCode");
							old_eappData.put("oldadvisor", safeGet(eappData, "advisor"));
							old_eappData.remove("advisor");

							client.set("old_" + eid, old_eappData.toString());

							// adding BeneModels with empty json
							if (appType.equalsIgnoreCase("Life") || appType.equalsIgnoreCase("GC")
									|| appType.equalsIgnoreCase("GIO")) {
								eappData.put("BeneModels", new JSONObject());
								if (safeGet(eappData, "clone1_AddContingentBeneficiaries0_dataObj").isEmpty()) {
									eappData.put("clone1_AddContingentBeneficiaries0_dataObj", new JSONArray());
								}
								if (safeGet(eappData, "clone1_AddPrimaryBeneficiaries0_dataObj").isEmpty()) {
									eappData.put("clone1_AddPrimaryBeneficiaries0_dataObj", new JSONArray());
								}
							}
							// for wealth cases 98 Card failure senario
							if (appType.equalsIgnoreCase("Wealth")) {
								//For 98 Card changes
								JSONObject BeneRelationshipMapping = new JSONObject();
								JSONObject SpecifiedPersonListforBene = new JSONObject();
								JSONObject CompanyListforBene = new JSONObject();
								
								// In Case Bene Data is available
								if (!safeGet(eappData, "AddPrimaryBeneficiary0_dataObj").isEmpty()) {
									JSONArray primaryBeneArray = (JSONArray) objJSONParser
											.parse(safeGet(eappData, "AddPrimaryBeneficiary0_dataObj"));
									JSONArray final_objAddPrimBenejsonArray = new JSONArray();
									/**
									 * This block only for 103 mapping id set
									 * for parent records
									 * 
									 * Iterating the Primary Bene Objects 
									 */
									for (int i = 0; i < primaryBeneArray.size(); i++) {//----------1 

										JSONObject primaryRecordObject = (JSONObject) objJSONParser
												.parse(primaryBeneArray.get(i).toString());

										JSONArray requiredMandatoryElems = new JSONArray();										
										
										//adding benfId for record identification -each record
										primaryRecordObject.put("benfId",Math.random());	
										
										if (!safeGet(primaryRecordObject,"addPrimBnfrySlect").isEmpty() ){//------------2
										
											if(safeGet(primaryRecordObject,"addPrimBnfrySlect").toString().equals("Company")){//-----------3
												BeneRelationshipMapping.put("Company"+safeGet(primaryRecordObject,"benfId"), new JSONArray());
												
												requiredMandatoryElems.add("addPrimBnfrySlect");
												requiredMandatoryElems.add("addPrimBenfryType");
												requiredMandatoryElems.add("addPrimBenfryCompany");
												requiredMandatoryElems.add("addPrimBenfryRecive");
												
																								
												JSONObject objBeneModel = new JSONObject();
												if (!safeGet(primaryRecordObject,"addPrimBenfryRecive").isEmpty()) {
													objBeneModel.put("BeneficiaryRecieve", safeGet(primaryRecordObject,"addPrimBenfryRecive"));
													if (safeGet(primaryRecordObject,"addPrimBenfryRecive").equals("sb")) {
														requiredMandatoryElems.add("addPrimBenfryRecivetxt");
													}
												}
												objBeneModel.put("BeneficiaryRecieveTxt", safeGet(primaryRecordObject,"addPrimBenfryRecivetxt"));
												
												objBeneModel.put("CompanyName", safeGet(primaryRecordObject,"addPrimBenfryCompany"));
												
												if (!safeGet(primaryRecordObject,"addPrimBenfryType").isEmpty()) {
													objBeneModel.put("Type", safeGet(primaryRecordObject,"addPrimBenfryType"));
													if (safeGet(primaryRecordObject,"addPrimBenfryType").equals("Irrevocable")){
														requiredMandatoryElems.add("AddPrimBenIrr");
													}
													
												}
												
												objBeneModel.put("bene", "Primary");
												
												objBeneModel.put("benfId",safeGet(primaryRecordObject,"benfId"));
												
												CompanyListforBene.put("Company"+safeGet(primaryRecordObject,"benfId"), objBeneModel);
												
												primaryRecordObject.put("requiredMandatoryElems", requiredMandatoryElems);
												
											} else if(safeGet(primaryRecordObject,"addPrimBnfrySlect").toString().equals("Person Specified Below")) {
												BeneRelationshipMapping.put("Person"+safeGet(primaryRecordObject,"benfId"), new JSONArray());
												
												
												requiredMandatoryElems.add("addPrimBnfrySlect");
												requiredMandatoryElems.add("addPrimBenfryType");
												requiredMandatoryElems.add("addPrimBenfry_firstName");
												requiredMandatoryElems.add("addPrimBenfry_lastName");
												requiredMandatoryElems.add("addPrimBenfryRelshp");												
												requiredMandatoryElems.add("addPrimBenfryRecive");
												requiredMandatoryElems.add("addPrimBenfryTte");
												
												
												JSONObject objBeneModel = new JSONObject();
												if (!safeGet(primaryRecordObject,"addPrimBenfryRecive").isEmpty()) {
													objBeneModel.put("BeneficiaryRecieve", safeGet(primaryRecordObject,"addPrimBenfryRecive"));
													if (safeGet(primaryRecordObject,"addPrimBenfryRecive").equals("sb")) {
														requiredMandatoryElems.add("addPrimBenfryRecivetxt");
													}
												}
												objBeneModel.put("BeneficiaryRecieveTxt", safeGet(primaryRecordObject,"addPrimBenfryRecivetxt"));
												
												objBeneModel.put("FName", safeGet(primaryRecordObject,"addPrimBenfry_firstName"));
												
												objBeneModel.put("Initial", safeGet(primaryRecordObject,"addPrimBenfry_initialName"));
												
												if (!safeGet(primaryRecordObject,"AddPrimBenIrr").isEmpty())
												objBeneModel.put("IrrivocableDesignation", safeGet(primaryRecordObject,"AddPrimBenIrr"));
												
												objBeneModel.put("LName", safeGet(primaryRecordObject,"addPrimBenfry_lastName"));
												
												objBeneModel.put("MM", safeGet(primaryRecordObject,"addPrimBenfryDob_MM"));
												
												objBeneModel.put("DD", safeGet(primaryRecordObject,"addPrimBenfryDob_DD"));
												
												objBeneModel.put("YYYY", safeGet(primaryRecordObject,"addPrimBenfryDob_YYYY"));
												
												objBeneModel.put("Relationship", safeGet(primaryRecordObject,"addPrimBenfryRelshp"));
												
												objBeneModel.put("Suffix", safeGet(primaryRecordObject,"addPrimBenfrysfx"));
												
												objBeneModel.put("Title", safeGet(primaryRecordObject,"addPrimBenfryTitle"));
												
												if (!safeGet(primaryRecordObject,"addPrimBenfryTte").isEmpty())
												objBeneModel.put("Trustee", safeGet(primaryRecordObject,"addPrimBenfryTte"));											

												if (!safeGet(primaryRecordObject,"addPrimBenfryType").isEmpty()) {
												objBeneModel.put("Type", safeGet(primaryRecordObject,"addPrimBenfryType"));
												if (safeGet(primaryRecordObject,"addPrimBenfryType").equals("Irrevocable")){
													requiredMandatoryElems.add("AddPrimBenIrr");
												}
												
												}
												primaryRecordObject.put("requiredMandatoryElems", requiredMandatoryElems);
												objBeneModel.put("bene", "Primary");
												
												objBeneModel.put("benfId",safeGet(primaryRecordObject,"benfId"));
												
												SpecifiedPersonListforBene.put("Person"+safeGet(primaryRecordObject,"benfId"), objBeneModel);
											}
										
											
										

										if (!safeGet(primaryRecordObject, "Trustees").isEmpty()) {
											JSONArray trusteesArry = (JSONArray) objJSONParser
													.parse(primaryRecordObject.get("Trustees").toString());
											JSONArray final_objAddPrimBeneTrusteejsonArray = new JSONArray();
											for (int j = 0; j < trusteesArry.size(); j++) {
												Object tObj = trusteesArry.get(j);
												JSONObject listJson = (JSONObject) objJSONParser.parse(tObj.toString());
												JSONArray trunstrequiredMandatoryElems =  new JSONArray();
												//adding trusteeId for record identification
												listJson.put("trusteeId",Math.random());											
												
												
												if(safeGet(listJson,"addTrstPrimBenSel").toString().equals("Company")){
													
													BeneRelationshipMapping.put("Company"+safeGet(listJson,"trusteeId"), new JSONArray());
													
													trunstrequiredMandatoryElems.add("addTrstPrimBenSel");
													trunstrequiredMandatoryElems.add("addTrstPrimBenSelCompany");
													trunstrequiredMandatoryElems.add("addTrstPrimBenTrstAge");
													
													JSONObject objBeneModel = new JSONObject();
																			
													objBeneModel.put("CompanyName", safeGet(listJson,"addTrstPrimBenSelCompany"));
													if(!safeGet(listJson,"addTrstPrimBenTrstAge").isEmpty()){
														objBeneModel.put("addTrstBenTrstAge", safeGet(listJson,"addTrstPrimBenTrstAge"));
														if(safeGet(listJson,"addTrstPrimBenTrstAge").equals("ta")){
															trunstrequiredMandatoryElems.add("addTrstPrimBenTrstAge1txt");
														}
													}
													
													listJson.put("requiredMandatoryElems", trunstrequiredMandatoryElems);
													
													objBeneModel.put("addTrstBenTrstAge1txt", safeGet(listJson,"addTrstPrimBenTrstAge1txt"));
													
													objBeneModel.put("benfId",safeGet(primaryRecordObject,"benfId"));
													
													objBeneModel.put("trusteeId",safeGet(listJson,"trusteeId"));
													
													CompanyListforBene.put("Company"+safeGet(listJson,"trusteeId"), objBeneModel);
													
													
												} else if(safeGet(listJson,"addTrstPrimBenSel").toString().equals("PersonSpecifiedBelow")) {
													
													BeneRelationshipMapping.put("Person"+safeGet(listJson,"trusteeId"), new JSONArray());
													
													trunstrequiredMandatoryElems.add("addTrstPrimBenSel");
													trunstrequiredMandatoryElems.add("addTrstPrimBenNme_firstName");
													trunstrequiredMandatoryElems.add("addTrstPrimBenNme_lastName");
													trunstrequiredMandatoryElems.add("addTrstPrimBenRel");
													trunstrequiredMandatoryElems.add("addTrstPrimBenTrstAge");
																						
													JSONObject objBeneModel = new JSONObject();
		
													
													objBeneModel.put("FName", safeGet(listJson,"addTrstPrimBenNme_firstName"));
													
													objBeneModel.put("Initial", safeGet(listJson,"addTrstPrimBenNme_initialName"));						
													
													objBeneModel.put("LName", safeGet(listJson,"addTrstPrimBenNme_lastName"));
													
													objBeneModel.put("MM", safeGet(listJson,"addTrstPrimBenDob_MM"));
													
													objBeneModel.put("DD", safeGet(listJson,"addTrstPrimBenDob_DD"));
													
													objBeneModel.put("YYYY", safeGet(listJson,"addTrstPrimBenDob_YYYY"));
													
													objBeneModel.put("Relationship", safeGet(listJson,"addTrstPrimBenRel"));
													
													objBeneModel.put("Suffix", safeGet(listJson,"addTrstPrimBenSfx"));
													
													objBeneModel.put("Title", safeGet(listJson,"addTrstPrimBenTle"));																																
													
													if(!safeGet(listJson,"addTrstPrimBenTrstAge").isEmpty()){
														objBeneModel.put("addTrstBenTrstAge", safeGet(listJson,"addTrstPrimBenTrstAge"));
														if (safeGet(listJson,"addTrstPrimBenTrstAge").equals("ta")) {
															trunstrequiredMandatoryElems.add("addTrstPrimBenTrstAge1txt");
														}
													}
													
													listJson.put("requiredMandatoryElems", trunstrequiredMandatoryElems);
													
													objBeneModel.put("addTrstBenTrstAge1txt", safeGet(listJson,"addTrstPrimBenTrstAge1txt"));
													
													objBeneModel.put("benfId",safeGet(primaryRecordObject,"benfId"));
													
													objBeneModel.put("trusteeId",safeGet(listJson,"trusteeId"));
													
													
													SpecifiedPersonListforBene.put("Person"+safeGet(listJson,"trusteeId"), objBeneModel);
													
												}
												final_objAddPrimBeneTrusteejsonArray.add(listJson.toJSONString());
											}
											primaryRecordObject.put("Trustees", final_objAddPrimBeneTrusteejsonArray);
										}

										final_objAddPrimBenejsonArray.add(primaryRecordObject.toJSONString());

									}
									}
									eappData.put("AddPrimaryBeneficiary0_dataObj", final_objAddPrimBenejsonArray);
									final_objAddPrimBenejsonArray = new JSONArray();

									/**
									 * contigent Bene
									 */
									JSONArray contBeneArray = (JSONArray) objJSONParser
											.parse(safeGet(eappData, "AddacontingentBenificiaries0_dataObj"));
									JSONArray final_objAddContBenejsonArray = new JSONArray();
									for (int i = 0; i < contBeneArray.size(); i++) {

										JSONObject contRecordObject = (JSONObject) objJSONParser
												.parse(contBeneArray.get(i).toString());
										JSONArray requiredMandatoryElems = new JSONArray();
										//adding benfId for record identification
										contRecordObject.put("benfId",Math.random());
										
										if (!safeGet(contRecordObject,"addContBenSelContBen").isEmpty() ){
											
											if(safeGet(contRecordObject,"addContBenSelContBen").toString().equals("Company")){
												BeneRelationshipMapping.put("Company"+safeGet(contRecordObject,"benfId"), new JSONArray());
												
												requiredMandatoryElems.add("addContBenSelContBen");
												requiredMandatoryElems.add("addContBenCom");
												requiredMandatoryElems.add("addConBenRecv");
												
												JSONObject objBeneModel = new JSONObject();
												if (!safeGet(contRecordObject,"addConBenRecv").isEmpty()){
													objBeneModel.put("BeneficiaryRecieve", safeGet(contRecordObject,"addConBenRecv"));
													if (safeGet(contRecordObject,"addConBenRecv").equals("sb")){
														requiredMandatoryElems.add("addContBenSpec");
													}
												}
												
												objBeneModel.put("BeneficiaryRecieveTxt", safeGet(contRecordObject,"addContBenSpec"));
												
												objBeneModel.put("CompanyName", safeGet(contRecordObject,"addContBenCom"));																								
												
												objBeneModel.put("bene", "Contingent");
												
												objBeneModel.put("benfId",safeGet(contRecordObject,"benfId"));
												
												contRecordObject.put("requiredMandatoryElems", requiredMandatoryElems);
												
												CompanyListforBene.put("Company"+safeGet(contRecordObject,"benfId"), objBeneModel);
												
											} else if(safeGet(contRecordObject,"addContBenSelContBen").toString().equals("PersonSpecifiedBelow")) {
												BeneRelationshipMapping.put("Person"+safeGet(contRecordObject,"benfId"), new JSONArray());
												
												
												requiredMandatoryElems.add("addContBenSelContBen");
												requiredMandatoryElems.add("addContBenNme_firstName");
												requiredMandatoryElems.add("addContBenNme_lastName");
												requiredMandatoryElems.add("addContBenRel");
												requiredMandatoryElems.add("addConBenRecv");
												requiredMandatoryElems.add("addContBenTrstee");
												
												JSONObject objBeneModel = new JSONObject();
												if (!safeGet(contRecordObject,"addConBenRecv").isEmpty()){
													objBeneModel.put("BeneficiaryRecieve", safeGet(contRecordObject,"addConBenRecv"));
													if (safeGet(contRecordObject,"addConBenRecv").equals("sb")){
														requiredMandatoryElems.add("addContBenSpec");
													}
												}
												
												objBeneModel.put("BeneficiaryRecieveTxt", safeGet(contRecordObject,"addContBenSpec"));
												
												objBeneModel.put("FName", safeGet(contRecordObject,"addContBenNme_firstName"));
												
												objBeneModel.put("Initial", safeGet(contRecordObject,"addContBenNme_initialName"));												
																		
												objBeneModel.put("LName", safeGet(contRecordObject,"addContBenNme_lastName"));
												
												objBeneModel.put("MM", safeGet(contRecordObject,"addContBenDob_MM"));
												
												objBeneModel.put("DD", safeGet(contRecordObject,"addContBenDob_DD"));
												
												objBeneModel.put("YYYY", safeGet(contRecordObject,"addContBenDob_YYYY"));
												
												objBeneModel.put("Relationship", safeGet(contRecordObject,"addContBenRel"));
												
												objBeneModel.put("Suffix", safeGet(contRecordObject,"addContBenSux"));
												
												objBeneModel.put("Title", safeGet(contRecordObject,"addContBenTle"));
												
												if (!safeGet(contRecordObject,"addContBenTrstee").isEmpty()){
													objBeneModel.put("Trustee", safeGet(contRecordObject,"addContBenTrstee"));
												}
																					
												objBeneModel.put("bene", "Contingent");
												
												objBeneModel.put("benfId",safeGet(contRecordObject,"benfId"));
												
												contRecordObject.put("requiredMandatoryElems", requiredMandatoryElems);
												
												SpecifiedPersonListforBene.put("Person"+safeGet(contRecordObject,"benfId"), objBeneModel);
											}
											
										if (!safeGet(contRecordObject, "Trustees").isEmpty()) {

											JSONArray trusteesArry = (JSONArray) objJSONParser
													.parse(contRecordObject.get("Trustees").toString());
											JSONArray final_objAddContBeneTrusteejsonArray = new JSONArray();
											for (int j = 0; j < trusteesArry.size(); j++) {
												Object tObj = trusteesArry.get(j);
												JSONObject listJson = (JSONObject) objJSONParser.parse(tObj.toString());

												JSONArray trusteerequiredMandatoryElems = new JSONArray();
												//adding trusteeId for record identification
												listJson.put("trusteeId",Math.random());		
												
												final_objAddContBeneTrusteejsonArray.add(listJson.toJSONString());
												
												if(safeGet(listJson,"addTrstContBenSel").toString().equals("Company")){
													
													BeneRelationshipMapping.put("Company"+safeGet(listJson,"trusteeId"), new JSONArray());
													
													trusteerequiredMandatoryElems.add("addTrstContBenSel");
													trusteerequiredMandatoryElems.add("addTrstContBenCom");
													trusteerequiredMandatoryElems.add("addTrstContBenLable");
													
													JSONObject objBeneModel = new JSONObject();
																			
													objBeneModel.put("CompanyName", safeGet(listJson,"addTrstContBenCom"));
													if (!safeGet(listJson,"addTrstContBenLable").isEmpty()){
														objBeneModel.put("addTrstBenTrstAge", safeGet(listJson,"addTrstContBenLable"));
														if (safeGet(listJson,"addTrstContBenLable").equals("ta")){
															trusteerequiredMandatoryElems.add("addTrstContBenOption1Txt");
														}
													}
													
													objBeneModel.put("addTrstBenTrstAge1txt", safeGet(listJson,"addTrstContBenOption1Txt"));
													
													objBeneModel.put("benfId",safeGet(contRecordObject,"benfId"));
													
													objBeneModel.put("trusteeId",safeGet(listJson,"trusteeId"));
													
													listJson.put("requiredMandatoryElems", trusteerequiredMandatoryElems);
													
													CompanyListforBene.put("Company"+safeGet(listJson,"trusteeId"), objBeneModel);
													
													
												} else if(safeGet(listJson,"addTrstContBenSel").toString().equals("PersonSpecifiedBelow")) {
													
													BeneRelationshipMapping.put("Person"+safeGet(listJson,"trusteeId"), new JSONArray());
													
													JSONObject objBeneModel = new JSONObject();
		
													trusteerequiredMandatoryElems.add("addTrstContBenSel");
													trusteerequiredMandatoryElems.add("addTrstContBenNme_firstName");
													trusteerequiredMandatoryElems.add("addTrstContBenNme_lastName");
													trusteerequiredMandatoryElems.add("addTrstContBenRel");
													trusteerequiredMandatoryElems.add("addTrstContBenLable");
													
													
													objBeneModel.put("FName", safeGet(listJson,"addTrstContBenNme_firstName"));
													
													objBeneModel.put("Initial", safeGet(listJson,"addTrstContBenNme_initialName"));						
													
													objBeneModel.put("LName", safeGet(listJson,"addTrstContBenNme_lastName"));
													
													objBeneModel.put("MM", safeGet(listJson,"addTrstContBenDob_MM"));
													
													objBeneModel.put("DD", safeGet(listJson,"addTrstContBenDob_DD"));
													
													objBeneModel.put("YYYY", safeGet(listJson,"addTrstContBenDob_YYYY"));
													
													objBeneModel.put("Relationship", safeGet(listJson,"addTrstContBenRel"));
													
													objBeneModel.put("Suffix", safeGet(listJson,"addTrstContBenSfx"));
													
													objBeneModel.put("Title", safeGet(listJson,"addTrstContBenTitle"));	
													
													if (!safeGet(listJson,"addTrstContBenLable").isEmpty()){
														objBeneModel.put("addTrstBenTrstAge", safeGet(listJson,"addTrstContBenLable"));
														if (safeGet(listJson,"addTrstContBenLable").equals("ta")) {
															trusteerequiredMandatoryElems.add("addTrstContBenOption1Txt");
														}
													}
													objBeneModel.put("addTrstBenTrstAge1txt", safeGet(listJson,"addTrstContBenOption1Txt"));
													
													objBeneModel.put("benfId",safeGet(contRecordObject,"benfId"));
													
													objBeneModel.put("trusteeId",safeGet(listJson,"trusteeId"));
													
													listJson.put("requiredMandatoryElems", trusteerequiredMandatoryElems);
													
													SpecifiedPersonListforBene.put("Person"+safeGet(listJson,"trusteeId"), objBeneModel);
													
												}
												
											}
											contRecordObject.put("Trustees", final_objAddContBeneTrusteejsonArray);
										}
										
										final_objAddContBenejsonArray.add(contRecordObject.toJSONString());

									}
									eappData.put("AddacontingentBenificiaries0_dataObj", final_objAddContBenejsonArray);
									final_objAddContBenejsonArray = new JSONArray();

								}
							}
								eappData.put("BeneRelationshipMapping",BeneRelationshipMapping);
								eappData.put("SpecifiedPersonListforBene",SpecifiedPersonListforBene);
								eappData.put("CompanyListforBene",CompanyListforBene);
							}
							//Saving modified case Data
							client.set(eid, eappData.toString());
							client.set("formattedDocumentIds", formattedDocumentIds.toString());
						}

					}
				}

				try {
					System.out.println("Sleeeping a while before processing the next batch ...");
					Thread.sleep(10000);
					System.out.println("Processing the next page");
				} catch (InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param moveCasess
	 * @param moveAllCasess
	 * @param moveAllReports
	 * @param deleteDocs
	 */
	public void moveCasess(boolean moveCasess, boolean moveAllCasess, boolean moveAllReports, boolean deleteDocs){
		
		JSONObject eappData = new JSONObject();
		JSONObject repDoc = new JSONObject();
		JSONObject formattedRepDoc = new JSONObject();
		boolean isUploadedCase = false;
		boolean isAdvisoruploaded = false;
		boolean isDeletedCase = false;
		String appType = "life";
		

		int pcnt = 0;
		IEbixView view = client.getView_("advisor", "by_ApplicationType");
		IEbixQuery query = client.getQueryInstance_();
		// query.setLimit(100);

		int docsPerPage = 50;
		IEbixPaginator pages = client.paginatedQuery(view, query, docsPerPage);
		while (pages.hasNext()) {
			System.out.println("Please Waite.. Processing Page:" + pcnt++);
			IEbixViewResponse response = pages.next();
			for (IEbixViewRow row : response) {
				String eid = row.getId();
				try {
					if (null != eid && !eid.isEmpty() && eid.startsWith("COOPTrans-")) {
						eappData = getDocument(eid);
						isUploadedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Uploaded") ? true : false;
						isAdvisoruploaded = safeGet(eappData, "advisorCode").equalsIgnoreCase("Uploaded") ? true : false;
						isDeletedCase = safeGet(eappData, "eappStatus").equalsIgnoreCase("Deleted") ? true : false;
						if (moveCasess && moveAllCasess || (isDeletedCase || (isUploadedCase && isAdvisoruploaded))) {
							boolean ismoved = moveCaseAudiToDB(eid, deleteDocs);
							System.out.println(eid + " isMoved:" + ismoved);
						} 
						if (moveAllReports || ((isDeletedCase || (isUploadedCase && isAdvisoruploaded)))) {
							appType = safeGet(eappData, "appType");
							if(!appType.equalsIgnoreCase("wealth")){
								appType = "life";
							}
							repDoc = getFormattedReport(eappData, appType);
							formattedRepDoc = getFormattedReport(repDoc, "oldApps");
							boolean ismoved = saveReports(eid, formattedRepDoc);
							if(ismoved){
								client.delete(eid.replace("COOPTrans", "Reports"));
							}
							System.out.println(eid.replace("COOPTrans", "Reports") + " isMoved:" + ismoved);
						} 
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			try {
				Thread.sleep(2000);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}
	
	public static void selectOptions(){
		
	}

	public boolean moveCaseAudiToDB(String eappId, boolean needToDeleteOracleMovedDocs) {
		boolean deleteDocs = false;
		if (null != eappId && !eappId.isEmpty()) {
			try {
				List objs = (List) getAbstractDAO().findByCriteria(EappCaseAudit.class, "CASEID = '" + eappId + "'");
				if (objs != null && objs.size() != 0) {
					EappCaseAudit OldEappCaseData = (EappCaseAudit) objs.get(0);
					OldEappCaseData = bindEappCaseAudit(eappId, OldEappCaseData);
					try {
						getAbstractDAO().update(OldEappCaseData);
						deleteDocs = true;
					} catch (Exception e) {
						deleteDocs = false;
						e.printStackTrace();
					}
				} else {
					EappCaseAudit OldEappCaseData = new EappCaseAudit();
					OldEappCaseData = bindEappCaseAudit(eappId, OldEappCaseData);
					try {
						getAbstractDAO().save(OldEappCaseData);
						deleteDocs = true;
					} catch (Exception e) {
						deleteDocs = false;
						e.printStackTrace();
					}
				}

			} catch (DataAccessException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	
		if (!eappId.startsWith("Agent_Data_") && deleteDocs && needToDeleteOracleMovedDocs) {
			client.delete(eappId);
			client.delete(eappId + "AUDIT_AUDIT_LOG");
			client.delete(eappId + "AUDIT_SNAPSHOT");
			client.delete("eapp_pdf_" + eappId);
		}

		return deleteDocs;
	}
	
	public boolean saveReports(String eappId, JSONObject eappJSONObject) {
		boolean isReportSaved = false;
		try{
			List objs = (List) getAbstractDAO().findByCriteria(EappReports.class,
					"EAPPID = '" + eappId+"'");
			if (objs != null && objs.size() != 0) {
				EappReports OldEappReports =  (EappReports)objs.get(0);
				Long id = OldEappReports.getId();
				OldEappReports = prepareEappReportsFromJson(OldEappReports,eappJSONObject);
				OldEappReports.setId(id);
				getAbstractDAO().update(OldEappReports);
				isReportSaved = true;
			}else{
				EappReports OldEappRepoers = new EappReports();
				OldEappRepoers = prepareEappReportsFromJson(OldEappRepoers,eappJSONObject);
				getAbstractDAO().save(OldEappRepoers);
				isReportSaved = true;
			}
			
		}catch(Exception e){
			System.out.println("Report not saved for EappId:"+eappId+" :::Exception in saveReports: "+e);
			isReportSaved = false;
			e.printStackTrace();
		}
		return isReportSaved;
		
	}

	private EappCaseAudit bindEappCaseAudit(String eappId, EappCaseAudit OldEappCaseData) throws DataAccessException {
		// getting data from couchbase.
		String caseData = fetch(eappId);
		String auditLog = fetch(eappId + "AUDIT_AUDIT_LOG");
		String snapShort = fetch(eappId + "AUDIT_SNAPSHOT");
		String pdfData = fetch("eapp_pdf_" + eappId);

		Blob caseBlob = convertToBlob(caseData);
		Blob auditBlob = convertToBlob(auditLog);
		Blob snapShortBlob = convertToBlob(snapShort);
		Blob pdfDataBlob = convertToBlob(pdfData);

		OldEappCaseData.setCaseid(eappId);
		if (null != caseBlob) {
			OldEappCaseData.setCaseData(caseBlob);
		}
		if (null != auditBlob) {
			OldEappCaseData.setAuditdata(auditBlob);
		}
		if (null != snapShortBlob) {
			OldEappCaseData.setSnapShot(snapShortBlob);
		}
		if (null != pdfDataBlob) {
			OldEappCaseData.setPdfData(pdfDataBlob);
		}

		if (eappId.startsWith("COOPTrans-") && null != caseData) {
			JSONObject formated_Json_eappDoc = null;
			String carrierCode = null;
			String appType = null;
			try {
				formated_Json_eappDoc = (JSONObject) new JSONParser().parse(caseData);
				carrierCode = (String) formated_Json_eappDoc.get("carrierCode");
				appType = (String) formated_Json_eappDoc.get("appType");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			OldEappCaseData.setAppType(appType);
			if (null != carrierCode && carrierCode.equalsIgnoreCase("CUMIS")) {
				OldEappCaseData.setType("CUMIS");
			} else {
				OldEappCaseData.setType("CLIC");
			}
		} else if (eappId.startsWith("D2CTransId-")) {
			OldEappCaseData.setType("D2C");
		} else if (eappId.startsWith("Agent_Data_")) {
			OldEappCaseData.setType("AGENT");
		}

		return OldEappCaseData;
	}

	private Blob convertToBlob(String data) {
		Blob blob = null;
		if (null != data && !data.isEmpty()) {
			byte[] buff = data.getBytes();
			try {
				blob = new SerialBlob(buff);
			} catch (SerialException e) {
				System.out.println("Exception in converting to Blob ::: " + e);
				e.printStackTrace();
			} catch (SQLException e) {
				System.out.println("Exception in converting to Blob ::: " + e);
				e.printStackTrace();
			}
		}
		return blob;
	}

	private String fetch(String eappId) {
		String val = (String) client.get(eappId);
		return null != val ? val : "";
	}
	
	public JSONObject getDocument(String id) {
		JSONObject jsonobject = null;
		try {
			String data = fetch(id);
			if (null != data && !data.isEmpty()) {
				jsonobject = (JSONObject) new JSONParser().parse(data);					
			}

		} catch (Exception e) {
			System.out.println("Exception while getting document for:"+id);
			e.printStackTrace();
		}
		return jsonobject;
	}
	
	private String safeGet(JSONObject jso, String prop){
        Object propobj = null;
        try{
            propobj = jso.get(prop);
        }catch(Exception exprop){
        }
      return propobj==null?"":propobj.toString();
    }
	
	private void createMapperDocuments(){
        String mapperDoc = "{\"eappId\":\"EID\",\"policy\":\"No\",\"advisor\":\"A\",\"appType\":\"App\",\"modifiedDate\":\"date\",\"advisorCode\":\"AC\",\"sign\":\"sign\",\"carrierCode\":\"CC\",\"firstName\":\"FN\",\"lastName\":\"LN\",\"status\":\"ST\",\"product\":\"PR\",\"plan\":\"plan\",\"lives\":\"lives\",\"lwtk\":\"lwtk\",\"lastModifiedDate\":\"LMD\",\"deletedBy\":\"DB\",\"deletedDate\":\"DD\"}";
        String mapperDoc_life = "{\"EID\":\"eappId\",\"No\":\"ingeniumPolicyNumber\",\"A\":\"advisor\",\"App\":\"appType\",\"date\":\"dateMillis\",\"AC\":\"advisorCode\",\"sign\":\"SignType\",\"CC\":\"carrierCode\",\"FN\":\"GCCDFName_firstName\",\"LN\":\"GCCDFName_lastName\",\"ST\":\"eappStatus\",\"PR\":\"GCplaBase\",\"plan\":\"GCplaBasePlan\",\"lives\":\"GCplaNumbar\",\"lwtk\":\"lwtk\",\"LMD\":\"lastModifiedDate\",\"DB\":\"deleted_By\",\"DD\":\"deleted_date\",\"column_1\":\"\"}";
        String mapperDoc_welth = "{\"EID\":\"eappId\",\"No\":\"ingeniumPolicyNumber\",\"A\":\"advisor\",\"App\":\"appType\",\"date\":\"dateMillis\",\"AC\":\"advisorCode\",\"sign\":\"SignType\",\"CC\":\"carrierCode\",\"FN\":\"annPIName_firstName\",\"LN\":\"annPIName_lastName\",\"ST\":\"eappStatus\",\"PR\":\"wealth_product\",\"plan\":\"\",\"lives\":\"\",\"lwtk\":\"lwtk\",\"LMD\":\"lastModifiedDate\",\"DB\":\"deleted_By\",\"DD\":\"deleted_date\",\"column_1\":\"\"}";
        
        client.set("eappReportsMapper", mapperDoc);
        client.set("eappReportsMapper_life", mapperDoc_life);
        client.set("eappReportsMapper_wealth", mapperDoc_welth);
    }
	
	public JSONObject getFormattedReport(JSONObject eappJSONObject, String appType) {
		boolean isReportSaved = false;
		String resourcePath = null;
		JSONObject reportsMapper = null;
		JSONObject valObj = new JSONObject();
		
		if (null != appType && appType.equals("oldApps")) {
			reportsMapper = getMapperDocument("eappReportsMapper");
		}else if(null != appType && appType.equals("Wealth")) {
			reportsMapper = getMapperDocument("eappReportsMapper_wealth");
		}else{
			reportsMapper = getMapperDocument("eappReportsMapper_life");
		}
		if(null != reportsMapper){
			Iterator keys = reportsMapper.keySet().iterator();
			while(keys.hasNext()){
				String key = (String) keys.next();
				valObj.put(key, eappJSONObject.get(reportsMapper.get(key)));
			}
			if(null == valObj.get("carrierCode") || valObj.get("carrierCode").toString().isEmpty()){
				valObj.put("carrierCode","CLIC");
			}
		}else{
			System.out.println("Document Not Found:::: eappReportsMapper :::: in CouchBase for appType="+appType);
		}
		return valObj;
		
	}
	
	private EappReports prepareEappReportsFromJson(EappReports oldEappRepoers, JSONObject eappJSONObject){
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			oldEappRepoers = mapper.readValue(eappJSONObject.toJSONString(), EappReports.class);
		} catch (IOException e) {
			System.out.println("Error while parsing json to EappReports object :::: "+e.getMessage());
			e.printStackTrace();
		}
		
		return oldEappRepoers;
	}
	
	public JSONObject getMapperDocument(String id) {
		JSONObject obj = getDocument(id);
		if(null == obj || obj.isEmpty()){
			createMapperDocuments();
			obj = getDocument(id);
		}
		return obj;
	}
	

	public AbstractDAOImpl getAbstractDAO() {
		return abstractDAO;
	}

	public void setAbstractDAO(AbstractDAOImpl abstractDAO) {
		this.abstractDAO = abstractDAO;
	}

}